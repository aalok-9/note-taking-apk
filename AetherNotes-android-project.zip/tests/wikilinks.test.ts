﻿import { describe, it, expect } from 'vitest';
import { extractWikilinks, extractTags, computeBacklinks, generateGraphData } from '../src/domain/wikilinks';
import { Note } from '../src/types';

describe('Knowledge Graph & Wikilinks Engine', () => {
  const note1: Note = {
    id: 'n1',
    workspaceId: 'ws_1',
    title: 'Taxation of Companies',
    viewMode: 'editor',
    tags: ['Taxation'],
    createdAt: '2026-08-23T00:00:00.000Z',
    updatedAt: '2026-08-23T00:00:00.000Z',
    version: 1,
    blocks: [
      { id: 'b1', type: 'paragraph', content: 'As defined in [[Audit Evidence Framework]] and [[Capital Budgeting]]. Also note #CAInter' },
    ],
  };

  const note2: Note = {
    id: 'n2',
    workspaceId: 'ws_1',
    title: 'Audit Evidence Framework',
    viewMode: 'editor',
    tags: ['Audit'],
    createdAt: '2026-08-23T00:00:00.000Z',
    updatedAt: '2026-08-23T00:00:00.000Z',
    version: 1,
    blocks: [
      { id: 'b2', type: 'paragraph', content: 'Tax provisions must be cross-checked per [[Taxation of Companies]].' },
    ],
  };

  const note3: Note = {
    id: 'n3',
    workspaceId: 'ws_1',
    title: 'Capital Budgeting',
    viewMode: 'editor',
    tags: ['FM'],
    createdAt: '2026-08-23T00:00:00.000Z',
    updatedAt: '2026-08-23T00:00:00.000Z',
    version: 1,
    blocks: [
      { id: 'b3', type: 'paragraph', content: 'Evaluating projects for Taxation of Companies without brackets.' },
    ],
  };

  it('should extract outgoing wikilinks accurately', () => {
    const links = extractWikilinks(note1.blocks);
    expect(links).toEqual(['Audit Evidence Framework', 'Capital Budgeting']);
  });

  it('should extract inline tags from text blocks', () => {
    const tags = extractTags(note1);
    expect(tags).toContain('Taxation');
    expect(tags).toContain('CAInter');
  });

  it('should compute bidirectional backlinks and unlinked mentions', () => {
    const allNotes = [note1, note2, note3];
    const backlinks = computeBacklinks(note1, allNotes);

    // note2 has explicit [[Taxation of Companies]] link
    const linkedMention = backlinks.find((b) => b.noteId === 'n2');
    expect(linkedMention).toBeDefined();
    expect(linkedMention?.isLinked).toBe(true);

    // note3 has unlinked "Taxation of Companies" mention
    const unlinkedMention = backlinks.find((b) => b.noteId === 'n3');
    expect(unlinkedMention).toBeDefined();
    expect(unlinkedMention?.isLinked).toBe(false);
  });

  it('should generate 2D force graph nodes and links', () => {
    const allNotes = [note1, note2, note3];
    const graph = generateGraphData(allNotes);

    expect(graph.nodes.length).toBe(3);
    expect(graph.links.length).toBeGreaterThanOrEqual(2);
  });
});
