﻿import { describe, it, expect } from 'vitest';
import { SearchEngine } from '../src/services/search';
import { Note, Folder } from '../src/types';

describe('Search & Indexing Engine', () => {
  const folders: Folder[] = [
    { id: 'fld_1', workspaceId: 'ws_1', name: 'Taxation Law', order: 0, createdAt: '', updatedAt: '' },
    { id: 'fld_2', workspaceId: 'ws_1', name: 'Auditing', order: 1, createdAt: '', updatedAt: '' },
  ];

  const notes: Note[] = [
    {
      id: 'n1',
      workspaceId: 'ws_1',
      folderId: 'fld_1',
      title: 'Corporate Tax Rates Sec 115BAA',
      viewMode: 'editor',
      tags: ['Taxation', 'DirectTax'],
      createdAt: '2026-08-20T00:00:00.000Z',
      updatedAt: '2026-08-23T00:00:00.000Z',
      version: 1,
      blocks: [
        { id: '1', type: 'paragraph', content: 'Base tax rate is 22% with 10% surcharge and 4% cess.' },
      ],
    },
    {
      id: 'n2',
      workspaceId: 'ws_1',
      folderId: 'fld_2',
      title: 'Auditing Standards SA 200',
      viewMode: 'editor',
      tags: ['Audit', 'SA200'],
      createdAt: '2026-08-21T00:00:00.000Z',
      updatedAt: '2026-08-22T00:00:00.000Z',
      version: 1,
      blocks: [
        { id: '2', type: 'paragraph', content: 'Auditor must maintain professional skepticism throughout the audit.' },
      ],
    },
  ];

  it('should search note titles and return high scoring matches', () => {
    const results = SearchEngine.search(notes, folders, { query: 'Corporate Tax' });
    expect(results.length).toBe(1);
    expect(results[0].note.id).toBe('n1');
    expect(results[0].matchedField).toBe('title');
  });

  it('should search inside block content and extract snippet', () => {
    const results = SearchEngine.search(notes, folders, { query: 'skepticism' });
    expect(results.length).toBe(1);
    expect(results[0].note.id).toBe('n2');
    expect(results[0].snippets[0]).toContain('skepticism');
  });

  it('should filter by folder and tags', () => {
    const filtered = SearchEngine.search(notes, folders, { query: '', folderId: 'fld_2' });
    expect(filtered.length).toBe(1);
    expect(filtered[0].note.id).toBe('n2');
  });
});
