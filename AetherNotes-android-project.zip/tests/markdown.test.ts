﻿import { describe, it, expect } from 'vitest';
import { markdownToBlocks, blocksToMarkdown, noteToHtml } from '../src/domain/markdown';
import { Note } from '../src/types';

describe('Markdown & Block Converter Engine', () => {
  it('should parse headings, bullet lists, and checklists into blocks', () => {
    const md = `# Main Topic\n## Subtopic\n- Bullet item 1\n- [ ] Pending task\n- [x] Completed task`;
    const blocks = markdownToBlocks(md);

    expect(blocks.length).toBe(5);
    expect(blocks[0].type).toBe('heading-1');
    expect(blocks[0].content).toBe('Main Topic');
    expect(blocks[1].type).toBe('heading-2');
    expect(blocks[1].content).toBe('Subtopic');
    expect(blocks[2].type).toBe('bullet-list');
    expect(blocks[3].type).toBe('checklist');
    expect(blocks[3].checked).toBe(false);
    expect(blocks[4].type).toBe('checklist');
    expect(blocks[4].checked).toBe(true);
  });

  it('should parse code blocks and callouts', () => {
    const md = `\`\`\`python\ndef test():\n    return 42\n\`\`\`\n\n> [!TIP]\n> Remember to check tax deductions`;
    const blocks = markdownToBlocks(md);

    expect(blocks.length).toBe(2);
    expect(blocks[0].type).toBe('code');
    expect(blocks[0].data?.language).toBe('python');
    expect(blocks[0].data?.code).toContain('def test()');

    expect(blocks[1].type).toBe('callout');
    expect(blocks[1].data?.type).toBe('tip');
    expect(blocks[1].data?.text).toContain('Remember to check tax deductions');
  });

  it('should parse markdown tables into structured TableBlockData', () => {
    const md = `| Section | Rate | Effective |\n| --- | --- | --- |\n| 115BAA | 22% | 25.17% |\n| 115BAB | 15% | 17.16% |`;
    const blocks = markdownToBlocks(md);

    expect(blocks.length).toBe(1);
    expect(blocks[0].type).toBe('table');
    expect(blocks[0].data?.columns.length).toBe(3);
    expect(blocks[0].data?.rows.length).toBe(2);
    expect(blocks[0].data?.rows[0].cells['col_0']).toBe('115BAA');
  });

  it('should serialize Note blocks back into standard Markdown', () => {
    const note: Note = {
      id: 'test_note',
      workspaceId: 'ws_1',
      title: 'Tax Planning 2026',
      viewMode: 'editor',
      tags: ['Taxation', 'Audit'],
      createdAt: '2026-08-23T00:00:00.000Z',
      updatedAt: '2026-08-23T00:00:00.000Z',
      version: 1,
      blocks: [
        { id: '1', type: 'heading-1', content: 'Tax Planning 2026' },
        { id: '2', type: 'checklist', checked: true, content: 'Verify form 10-IC' },
        { id: '3', type: 'paragraph', content: 'See [[Audit Evidence]] for details.' },
      ],
    };

    const mdOutput = blocksToMarkdown(note);
    expect(mdOutput).toContain('title: "Tax Planning 2026"');
    expect(mdOutput).toContain('# Tax Planning 2026');
    expect(mdOutput).toContain('- [x] Verify form 10-IC');
    expect(mdOutput).toContain('[[Audit Evidence]]');
  });

  it('should generate standalone HTML for note printing and export', () => {
    const note: Note = {
      id: 'test_note_2',
      workspaceId: 'ws_1',
      title: 'CA Audit Standard SA 500',
      viewMode: 'editor',
      tags: ['Audit'],
      createdAt: '2026-08-23T00:00:00.000Z',
      updatedAt: '2026-08-23T00:00:00.000Z',
      version: 1,
      blocks: [
        { id: '1', type: 'heading-1', content: 'Audit Evidence Objectives' },
        { id: '2', type: 'quote', content: 'Sufficiency is the measure of quantity.' },
      ],
    };

    const html = noteToHtml(note);
    expect(html).toContain('<!DOCTYPE html>');
    expect(html).toContain('CA Audit Standard SA 500');
    expect(html).toContain('<blockquote>Sufficiency is the measure of quantity.</blockquote>');
  });
});
