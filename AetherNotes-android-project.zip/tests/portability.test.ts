﻿import { describe, it, expect } from 'vitest';
import { Workspace, Folder, Note, Notebook } from '../src/types';

describe('Portability & Format Specification', () => {
  const mockWorkspace: Workspace = {
    id: 'ws_test',
    name: 'CA Studies Workspace',
    description: 'Local workspace test',
    createdAt: '2026-08-23T00:00:00.000Z',
    updatedAt: '2026-08-23T00:00:00.000Z',
    formatVersion: 1,
  };

  const mockFolders: Folder[] = [
    { id: 'f1', workspaceId: 'ws_test', name: 'Taxation', order: 0, createdAt: '', updatedAt: '' },
    { id: 'f2', workspaceId: 'ws_test', name: 'Audit', order: 1, createdAt: '', updatedAt: '' },
  ];

  const mockNotes: Note[] = [
    {
      id: 'n1',
      workspaceId: 'ws_test',
      folderId: 'f1',
      title: 'Corporate Tax Regime',
      viewMode: 'editor',
      tags: ['Taxation', 'CAInter'],
      createdAt: '2026-08-23T00:00:00.000Z',
      updatedAt: '2026-08-23T00:00:00.000Z',
      version: 1,
      blocks: [
        { id: 'b1', type: 'heading-1', content: 'Corporate Tax Regime' },
        { id: 'b2', type: 'paragraph', content: 'Sec 115BAA concessional rate.' },
      ],
    },
  ];

  it('should conform to AetherWorkspace Manifest format version 1', () => {
    const manifest = {
      formatVersion: 1,
      appName: 'AetherNotes',
      appVersion: '1.0.0',
      exportedAt: new Date().toISOString(),
      workspace: mockWorkspace,
      counts: {
        notes: mockNotes.length,
        folders: mockFolders.length,
        notebooks: 0,
      },
    };

    expect(manifest.formatVersion).toBe(1);
    expect(manifest.appName).toBe('AetherNotes');
    expect(manifest.counts.notes).toBe(1);
    expect(manifest.counts.folders).toBe(2);
  });
});
