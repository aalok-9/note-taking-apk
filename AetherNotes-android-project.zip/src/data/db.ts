﻿import Dexie, { Table } from 'dexie';
import {
  Workspace,
  Folder,
  Notebook,
  Note,
  NoteRevision,
  Attachment,
  AppSettings
} from '../types';
import { generateId } from '../domain/markdown';

export class AetherDatabase extends Dexie {
  workspaces!: Table<Workspace, string>;
  folders!: Table<Folder, string>;
  notebooks!: Table<Notebook, string>;
  notes!: Table<Note, string>;
  revisions!: Table<NoteRevision, string>;
  attachments!: Table<Attachment, string>;
  settingsTable!: Table<{ key: string; value: any }, string>;

  constructor() {
    super('AetherNotesDB');
    this.version(1).stores({
      workspaces: 'id, name, updatedAt',
      folders: 'id, workspaceId, parentId, name, order',
      notebooks: 'id, workspaceId, folderId, name, order',
      notes: 'id, workspaceId, folderId, notebookId, title, viewMode, isFavorite, isPinned, isArchived, inTrash, createdAt, updatedAt',
      revisions: 'id, noteId, createdAt',
      attachments: 'id, noteId, name, type, createdAt',
      settingsTable: 'key'
    });
  }
}

export const db = new AetherDatabase();

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  accentColor: 'green',
  fontSize: 'normal',
  fontFamily: 'sans',
  density: 'normal',
  autoSaveInterval: 300,
  defaultViewMode: 'editor',
  defaultPaperTemplate: 'ruled',
  defaultPaperTint: 'light',
  soundEffects: true,
  spellCheck: true,
  graphPhysics: true,
  autoBackups: true,
  backupIntervalHours: 24
};

export const StorageService = {
  // Settings
  async getSettings(): Promise<AppSettings> {
    try {
      const record = await db.settingsTable.get('app_settings');
      return record ? { ...DEFAULT_SETTINGS, ...record.value } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  async saveSettings(settings: Partial<AppSettings>): Promise<AppSettings> {
    const current = await this.getSettings();
    const updated = { ...current, ...settings };
    await db.settingsTable.put({ key: 'app_settings', value: updated });
    return updated;
  },

  // Workspaces
  async getWorkspaces(): Promise<Workspace[]> {
    return await db.workspaces.toArray();
  },

  async getActiveWorkspace(): Promise<Workspace | undefined> {
    const workspaces = await db.workspaces.toArray();
    return workspaces[0];
  },

  async saveWorkspace(workspace: Workspace): Promise<void> {
    await db.workspaces.put(workspace);
  },

  // Folders
  async getFolders(workspaceId: string): Promise<Folder[]> {
    return await db.folders.where('workspaceId').equals(workspaceId).sortBy('order');
  },

  async saveFolder(folder: Folder): Promise<void> {
    await db.folders.put(folder);
  },

  async deleteFolder(folderId: string): Promise<void> {
    await db.transaction('rw', [db.folders, db.notes], async () => {
      await db.folders.delete(folderId);
      const notes = await db.notes.where('folderId').equals(folderId).toArray();
      for (const note of notes) {
        await db.notes.update(note.id, { folderId: undefined } as any);
      }
    });
  },

  // Notes
  async getNotes(workspaceId: string): Promise<Note[]> {
    return await db.notes.where('workspaceId').equals(workspaceId).toArray();
  },

  async getNoteById(id: string): Promise<Note | undefined> {
    return await db.notes.get(id);
  },

  async saveNote(note: Note, createRevision = false): Promise<Note> {
    const now = new Date().toISOString();
    const updatedNote: Note = {
      ...note,
      updatedAt: now,
      version: (note.version || 1) + 1
    };

    await db.transaction('rw', [db.notes, db.revisions], async () => {
      await db.notes.put(updatedNote);
      
      if (createRevision) {
        const revision: NoteRevision = {
          id: generateId(),
          noteId: note.id,
          title: note.title,
          blocks: JSON.parse(JSON.stringify(note.blocks)),
          canvasData: note.canvasData ? JSON.parse(JSON.stringify(note.canvasData)) : undefined,
          tags: [...note.tags],
          createdAt: now,
          description: `Auto-snapshot at ${new Date().toLocaleTimeString()}`
        };
        await db.revisions.put(revision);
        
        const noteRevisions = await db.revisions.where('noteId').equals(note.id).sortBy('createdAt');
        if (noteRevisions.length > 20) {
          const toDelete = noteRevisions.slice(0, noteRevisions.length - 20);
          for (const rev of toDelete) {
            await db.revisions.delete(rev.id);
          }
        }
      }
    });

    return updatedNote;
  },

  async deleteNote(noteId: string, permanent = false): Promise<void> {
    if (permanent) {
      await db.transaction('rw', [db.notes, db.revisions, db.attachments], async () => {
        await db.notes.delete(noteId);
        await db.revisions.where('noteId').equals(noteId).delete();
        await db.attachments.where('noteId').equals(noteId).delete();
      });
    } else {
      await db.notes.update(noteId, {
        inTrash: true,
        trashDate: new Date().toISOString()
      } as any);
    }
  },

  async restoreNote(noteId: string): Promise<void> {
    await db.notes.update(noteId, {
      inTrash: false,
      trashDate: undefined
    } as any);
  },

  async emptyTrash(workspaceId: string): Promise<void> {
    const trashNotes = await db.notes
      .where('workspaceId')
      .equals(workspaceId)
      .filter(n => !!n.inTrash)
      .toArray();

    await db.transaction('rw', [db.notes, db.revisions, db.attachments], async () => {
      for (const note of trashNotes) {
        await db.notes.delete(note.id);
        await db.revisions.where('noteId').equals(note.id).delete();
        await db.attachments.where('noteId').equals(note.id).delete();
      }
    });
  },

  async duplicateNote(noteId: string): Promise<Note | undefined> {
    const original = await db.notes.get(noteId);
    if (!original) return undefined;

    const newNote: Note = {
      ...JSON.parse(JSON.stringify(original)),
      id: generateId(),
      title: `${original.title} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1,
      inTrash: false,
      trashDate: undefined
    };

    if (newNote.blocks) {
      newNote.blocks = newNote.blocks.map(b => ({ ...b, id: generateId() }));
    }

    await db.notes.put(newNote);
    return newNote;
  },

  // Revisions
  async getRevisions(noteId: string): Promise<NoteRevision[]> {
    return await db.revisions.where('noteId').equals(noteId).reverse().sortBy('createdAt');
  },

  async restoreRevision(noteId: string, revisionId: string): Promise<Note | undefined> {
    const revision = await db.revisions.get(revisionId);
    const note = await db.notes.get(noteId);
    if (!revision || !note) return undefined;

    const restoredNote: Note = {
      ...note,
      title: revision.title,
      blocks: JSON.parse(JSON.stringify(revision.blocks)),
      canvasData: revision.canvasData ? JSON.parse(JSON.stringify(revision.canvasData)) : undefined,
      tags: [...revision.tags],
      updatedAt: new Date().toISOString(),
      version: note.version + 1
    };

    await this.saveNote(restoredNote, true);
    return restoredNote;
  },

  // Attachments
  async getAttachments(noteId: string): Promise<Attachment[]> {
    return await db.attachments.where('noteId').equals(noteId).toArray();
  },

  async saveAttachment(attachment: Attachment): Promise<void> {
    await db.attachments.put(attachment);
  },

  async deleteAttachment(id: string): Promise<void> {
    await db.attachments.delete(id);
  },

  // Full Database Reset
  async clearAllData(): Promise<void> {
    await db.transaction('rw', [db.workspaces, db.folders, db.notebooks, db.notes, db.revisions, db.attachments], async () => {
      await db.workspaces.clear();
      await db.folders.clear();
      await db.notebooks.clear();
      await db.notes.clear();
      await db.revisions.clear();
      await db.attachments.clear();
    });
  }
};
