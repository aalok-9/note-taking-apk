﻿import { Note, SearchResult, Folder } from '../types';
import { getAllBlockText } from '../domain/wikilinks';

export interface SearchFilters {
  query: string;
  folderId?: string;
  tag?: string;
  viewMode?: string;
  isFavorite?: boolean;
  dateRange?: 'today' | 'week' | 'month' | 'all';
}

export class SearchEngine {
  private static recentSearches: string[] = [
    'Taxation',
    'Auditing Standards',
    'Capital Budgeting',
    '#CAInter'
  ];

  static getRecentSearches(): string[] {
    return this.recentSearches;
  }

  static addRecentSearch(query: string) {
    const q = query.trim();
    if (!q) return;
    this.recentSearches = [q, ...this.recentSearches.filter(s => s.toLowerCase() !== q.toLowerCase())].slice(0, 8);
  }

  static search(notes: Note[], folders: Folder[], filters: SearchFilters): SearchResult[] {
    const { query, folderId, tag, viewMode, isFavorite, dateRange } = filters;
    const cleanQuery = (query || '').trim().toLowerCase();
    const folderMap = new Map(folders.map(f => [f.id, f.name]));

    const results: SearchResult[] = [];
    const now = new Date().getTime();

    for (const note of notes) {
      if (note.inTrash) continue;

      // Filter: Folder
      if (folderId && note.folderId !== folderId) continue;

      // Filter: Tag
      if (tag && !note.tags.map(t => t.toLowerCase()).includes(tag.toLowerCase())) continue;

      // Filter: View mode
      if (viewMode && note.viewMode !== viewMode) continue;

      // Filter: Favorite
      if (isFavorite && !note.isFavorite) continue;

      // Filter: Date Range
      if (dateRange && dateRange !== 'all') {
        const noteDate = new Date(note.updatedAt).getTime();
        const diffDays = (now - noteDate) / (1000 * 60 * 60 * 24);
        if (dateRange === 'today' && diffDays > 1) continue;
        if (dateRange === 'week' && diffDays > 7) continue;
        if (dateRange === 'month' && diffDays > 30) continue;
      }

      if (!cleanQuery) {
        // Return without text filtering
        results.push({
          note,
          score: 1,
          matchedField: 'title',
          snippets: [note.title || 'Untitled']
        });
        continue;
      }

      let score = 0;
      let matchedField: 'title' | 'content' | 'tags' | 'folder' = 'content';
      const snippets: string[] = [];

      const titleLower = (note.title || '').toLowerCase();
      const contentLower = getAllBlockText(note.blocks).toLowerCase();
      const folderName = note.folderId ? folderMap.get(note.folderId) || '' : '';
      const folderLower = folderName.toLowerCase();
      const tagsString = (note.tags || []).join(' ').toLowerCase();

      // Title exact or fuzzy match (highest score)
      if (titleLower === cleanQuery) {
        score += 100;
        matchedField = 'title';
        snippets.push(note.title);
      } else if (titleLower.includes(cleanQuery)) {
        score += 50;
        matchedField = 'title';
        snippets.push(note.title);
      }

      // Tag match
      if (tagsString.includes(cleanQuery)) {
        score += 35;
        if (score < 50) matchedField = 'tags';
        snippets.push(note.tags.filter(t => t.toLowerCase().includes(cleanQuery)).map(t => `#${t}`).join(', '));
      }

      // Folder match
      if (folderLower.includes(cleanQuery)) {
        score += 20;
        if (score < 35) matchedField = 'folder';
        snippets.push(`Folder: ${folderName}`);
      }

      // Content match
      if (contentLower.includes(cleanQuery)) {
        score += 15;
        if (score < 20) matchedField = 'content';
        
        // Find matching paragraph snippet
        const allText = getAllBlockText(note.blocks);
        const lines = allText.split('\n');
        for (const line of lines) {
          if (line.toLowerCase().includes(cleanQuery)) {
            const idx = line.toLowerCase().indexOf(cleanQuery);
            const start = Math.max(0, idx - 40);
            const end = Math.min(line.length, idx + cleanQuery.length + 50);
            snippets.push((start > 0 ? '...' : '') + line.substring(start, end).trim() + (end < line.length ? '...' : ''));
            if (snippets.length >= 2) break;
          }
        }
      }

      if (score > 0) {
        results.push({
          note,
          score,
          matchedField,
          snippets: snippets.slice(0, 2)
        });
      }
    }

    // Sort by score descending then by updatedAt descending
    return results.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return new Date(b.note.updatedAt).getTime() - new Date(a.note.updatedAt).getTime();
    });
  }
}
