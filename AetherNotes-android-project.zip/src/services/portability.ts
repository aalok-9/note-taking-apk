﻿import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { Note, Folder, Notebook, Workspace, AppSettings } from '../types';
import { blocksToMarkdown, noteToHtml, markdownToBlocks, generateId } from '../domain/markdown';
import { StorageService, db } from '../data/db';

export interface WorkspaceExportManifest {
  formatVersion: number;
  appName: string;
  appVersion: string;
  exportedAt: string;
  workspace: Workspace;
  counts: {
    notes: number;
    folders: number;
    notebooks: number;
  };
}

export const PortabilityService = {
  /**
   * Export single note in selected format
   */
  async exportSingleNote(note: Note, format: 'markdown' | 'html' | 'txt' | 'json') {
    const filename = (note.title.trim() || 'Untitled_Note').replace(/[/\\?%*:|"<>]/g, '_');

    switch (format) {
      case 'markdown': {
        const content = blocksToMarkdown(note);
        const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
        saveAs(blob, `${filename}.md`);
        break;
      }
      case 'html': {
        const content = noteToHtml(note);
        const blob = new Blob([content], { type: 'text/html;charset=utf-8' });
        saveAs(blob, `${filename}.html`);
        break;
      }
      case 'txt': {
        const content = `${note.title}\n\n` + note.blocks.map(b => b.content).join('\n\n');
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        saveAs(blob, `${filename}.txt`);
        break;
      }
      case 'json': {
        const content = JSON.stringify(note, null, 2);
        const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
        saveAs(blob, `${filename}.json`);
        break;
      }
    }
  },

  /**
   * Trigger browser print dialog for Note (Save to PDF)
   */
  printNote(note: Note) {
    const htmlContent = noteToHtml(note);
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
      }, 350);
    }
  },

  /**
   * Export Entire Workspace to a portable ZIP package
   */
  async exportWorkspaceZip(workspace: Workspace, folders: Folder[], notebooks: Notebook[], notes: Note[]): Promise<void> {
    const zip = new JSZip();

    const manifest: WorkspaceExportManifest = {
      formatVersion: 1,
      appName: 'AetherNotes',
      appVersion: '1.0.0',
      exportedAt: new Date().toISOString(),
      workspace,
      counts: {
        notes: notes.length,
        folders: folders.length,
        notebooks: notebooks.length
      }
    };

    zip.file('manifest.json', JSON.stringify(manifest, null, 2));
    zip.file('folders.json', JSON.stringify(folders, null, 2));
    zip.file('notebooks.json', JSON.stringify(notebooks, null, 2));
    
    // Notes JSON folder
    const notesFolder = zip.folder('notes');
    if (notesFolder) {
      for (const note of notes) {
        notesFolder.file(`${note.id}.json`, JSON.stringify(note, null, 2));
      }
    }

    // Markdown readable mirror folder
    const mdFolder = zip.folder('markdown');
    if (mdFolder) {
      for (const note of notes) {
        const safeTitle = (note.title.trim() || 'Untitled').replace(/[/\\?%*:|"<>]/g, '_');
        mdFolder.file(`${safeTitle}_${note.id.slice(-6)}.md`, blocksToMarkdown(note));
      }
    }

    const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
    const dateStr = new Date().toISOString().slice(0, 10);
    const workspaceName = workspace.name.replace(/[/\\?%*:|"<>]/g, '_');
    saveAs(zipBlob, `${workspaceName}_Backup_${dateStr}.zip`);
  },

  /**
   * Import Workspace from ZIP package
   */
  async importWorkspaceZip(file: File): Promise<{ success: boolean; message: string; count: number }> {
    try {
      const zip = await JSZip.loadAsync(file);
      
      const manifestFile = zip.file('manifest.json');
      if (!manifestFile) {
        throw new Error('Invalid AetherNotes package: manifest.json missing.');
      }

      const manifestText = await manifestFile.async('string');
      const manifest: WorkspaceExportManifest = JSON.parse(manifestText);

      // Extract Folders
      const foldersFile = zip.file('folders.json');
      if (foldersFile) {
        const folders: Folder[] = JSON.parse(await foldersFile.async('string'));
        for (const f of folders) {
          await StorageService.saveFolder(f);
        }
      }

      // Extract Notebooks
      const notebooksFile = zip.file('notebooks.json');
      if (notebooksFile) {
        const notebooks: Notebook[] = JSON.parse(await notebooksFile.async('string'));
        for (const nb of notebooks) {
          await db.notebooks.put(nb);
        }
      }

      // Extract Notes
      let noteCount = 0;
      const notesFolder = zip.folder('notes');
      if (notesFolder) {
        const noteFiles = Object.keys(zip.files).filter(path => path.startsWith('notes/') && path.endsWith('.json'));
        for (const path of noteFiles) {
          const content = await zip.file(path)?.async('string');
          if (content) {
            const note: Note = JSON.parse(content);
            await StorageService.saveNote(note, false);
            noteCount++;
          }
        }
      }

      // Save Workspace
      if (manifest.workspace) {
        await StorageService.saveWorkspace(manifest.workspace);
      }

      return {
        success: true,
        message: `Successfully imported workspace "${manifest.workspace?.name || 'Workspace'}" with ${noteCount} notes.`,
        count: noteCount
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Import failed: ${err.message || 'Corrupt archive'}`,
        count: 0
      };
    }
  },

  /**
   * Import Markdown / TXT file as a new Note
   */
  async importMarkdownFile(file: File, workspaceId: string, folderId?: string): Promise<Note> {
    const text = await file.text();
    const filenameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
    
    let title = filenameWithoutExt;
    let contentMarkdown = text;
    let extractedTags: string[] = [];

    if (text.startsWith('---')) {
      const match = text.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
      if (match) {
        const frontmatter = match[1];
        contentMarkdown = match[2];

        const titleMatch = frontmatter.match(/title:\s*["']?([^"'\n]+)["']?/);
        if (titleMatch) title = titleMatch[1].trim();

        const tagsMatch = frontmatter.match(/tags:\s*\[(.*?)\]/);
        if (tagsMatch) {
          extractedTags = tagsMatch[1].split(',').map(t => t.replace(/["'\s]/g, '')).filter(Boolean);
        }
      }
    }

    const blocks = markdownToBlocks(contentMarkdown);

    const newNote: Note = {
      id: generateId(),
      workspaceId,
      folderId,
      title,
      viewMode: 'editor',
      blocks,
      tags: extractedTags,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1
    };

    await StorageService.saveNote(newNote, true);
    return newNote;
  }
};
