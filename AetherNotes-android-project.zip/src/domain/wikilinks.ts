﻿import { Note, Block, BacklinkItem, GraphData, GraphNode, GraphLink } from '../types';

export const WIKILINK_REGEX = /\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g;
export const TAG_REGEX = /(?:^|\s)#([a-zA-Z0-9_\-\/]+)/g;
export const MENTION_REGEX = /(?:^|\s)@([a-zA-Z0-9_\-]+)/g;

/**
 * Extract all block texts recursively
 */
export function getAllBlockText(blocks: Block[]): string {
  let text = '';
  for (const block of blocks) {
    text += block.content + '\n';
    if (block.type === 'callout' && block.data?.text) {
      text += block.data.text + '\n';
    }
    if (block.type === 'table' && block.data?.rows) {
      for (const row of block.data.rows) {
        text += Object.values(row.cells).join(' ') + '\n';
      }
    }
    if (block.children && block.children.length > 0) {
      text += getAllBlockText(block.children);
    }
  }
  return text;
}

/**
 * Extract outgoing wikilink target titles from note blocks
 */
export function extractWikilinks(blocks: Block[]): string[] {
  const text = getAllBlockText(blocks);
  const links: string[] = [];
  let match: RegExpExecArray | null;
  const regex = new RegExp(WIKILINK_REGEX.source, 'g');
  
  while ((match = regex.exec(text)) !== null) {
    const targetTitle = match[1].trim();
    if (targetTitle && !links.includes(targetTitle)) {
      links.push(targetTitle);
    }
  }
  return links;
}

/**
 * Extract tags from note blocks and note's explicit tag list
 */
export function extractTags(note: Note): string[] {
  const tagSet = new Set<string>(note.tags || []);
  const text = getAllBlockText(note.blocks) + ' ' + note.title;
  let match: RegExpExecArray | null;
  const regex = new RegExp(TAG_REGEX.source, 'g');
  
  while ((match = regex.exec(text)) !== null) {
    const tag = match[1].trim();
    if (tag) {
      tagSet.add(tag);
    }
  }
  return Array.from(tagSet);
}

/**
 * Compute all backlinks (incoming links and unlinked mentions) for a target note
 */
export function computeBacklinks(targetNote: Note, allNotes: Note[]): BacklinkItem[] {
  const results: BacklinkItem[] = [];
  const targetTitleLower = targetNote.title.trim().toLowerCase();
  
  if (!targetTitleLower) return results;

  for (const note of allNotes) {
    if (note.id === targetNote.id || note.inTrash) continue;
    
    const noteText = getAllBlockText(note.blocks);
    const outgoingWikilinks = extractWikilinks(note.blocks);
    
    // 1. Explicit wikilink match
    const isExplicitlyLinked = outgoingWikilinks.some(
      link => link.toLowerCase() === targetTitleLower
    );
    
    if (isExplicitlyLinked) {
      // Find snippet around the link
      const preview = extractSnippet(noteText, targetNote.title, true);
      results.push({
        noteId: note.id,
        noteTitle: note.title,
        preview,
        isLinked: true
      });
    } else {
      // 2. Unlinked mention: exact title appears in text without [[ ]]
      const titleRegex = new RegExp(`\\b${escapeRegExp(targetNote.title)}\\b`, 'i');
      if (titleRegex.test(noteText)) {
        const preview = extractSnippet(noteText, targetNote.title, false);
        results.push({
          noteId: note.id,
          noteTitle: note.title,
          preview,
          isLinked: false
        });
      }
    }
  }

  return results;
}

function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function extractSnippet(text: string, keyword: string, isWikilink: boolean): string {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const lowerKeyword = keyword.toLowerCase();
  
  for (const line of lines) {
    if (isWikilink && line.toLowerCase().includes(`[[${lowerKeyword}`)) {
      return line;
    }
    if (!isWikilink && line.toLowerCase().includes(lowerKeyword)) {
      return line;
    }
  }
  return lines[0] || '';
}

/**
 * Generate 2D force graph data from notes
 */
export function generateGraphData(notes: Note[]): GraphData {
  const activeNotes = notes.filter(n => !n.inTrash);
  const noteTitleMap = new Map<string, Note>();
  const noteIdMap = new Map<string, Note>();
  
  for (const note of activeNotes) {
    noteTitleMap.set(note.title.trim().toLowerCase(), note);
    noteIdMap.set(note.id, note);
  }

  const nodes: GraphNode[] = [];
  const links: GraphLink[] = [];
  const connectionCounts = new Map<string, number>();

  // Initialize node count
  for (const note of activeNotes) {
    connectionCounts.set(note.id, 0);
  }

  // Build links
  for (const note of activeNotes) {
    const outgoing = extractWikilinks(note.blocks);
    for (const targetTitle of outgoing) {
      const targetNote = noteTitleMap.get(targetTitle.toLowerCase());
      if (targetNote && targetNote.id !== note.id) {
        links.push({
          source: note.id,
          target: targetNote.id
        });
        connectionCounts.set(note.id, (connectionCounts.get(note.id) || 0) + 1);
        connectionCounts.set(targetNote.id, (connectionCounts.get(targetNote.id) || 0) + 1);
      }
    }
  }

  // Create nodes with sizing based on connection degree
  for (const note of activeNotes) {
    const degree = connectionCounts.get(note.id) || 0;
    nodes.push({
      id: note.id,
      title: note.title || 'Untitled',
      folderId: note.folderId,
      tags: note.tags || [],
      val: Math.max(4, Math.min(18, 4 + degree * 2.5))
    });
  }

  return { nodes, links };
}
