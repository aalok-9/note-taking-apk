﻿import { Note, Block, BlockType, TableBlockData } from '../types';

/**
 * Generate a unique random ID
 */
export function generateId(): string {
  return 'id_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now().toString(36);
}

/**
 * Convert Markdown text into structured blocks
 */
export function markdownToBlocks(markdown: string): Block[] {
  const lines = markdown.split('\n');
  const blocks: Block[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      i++;
      continue;
    }

    // 1. Code Block
    if (trimmed.startsWith('```')) {
      const language = trimmed.slice(3).trim() || 'javascript';
      const codeLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        codeLines.push(lines[i]);
        i++;
      }
      blocks.push({
        id: generateId(),
        type: 'code',
        content: '',
        data: {
          code: codeLines.join('\n'),
          language
        }
      });
      i++; // skip closing ```
      continue;
    }

    // 2. Math block $$ ... $$
    if (trimmed.startsWith('$$')) {
      const mathLines: string[] = [];
      if (trimmed.endsWith('$$') && trimmed.length > 4) {
        mathLines.push(trimmed.slice(2, -2).trim());
      } else {
        i++;
        while (i < lines.length && !lines[i].trim().endsWith('$$')) {
          mathLines.push(lines[i]);
          i++;
        }
      }
      blocks.push({
        id: generateId(),
        type: 'equation',
        content: mathLines.join('\n')
      });
      i++;
      continue;
    }

    // 3. Headings
    if (trimmed.startsWith('### ')) {
      blocks.push({
        id: generateId(),
        type: 'heading-3',
        content: trimmed.slice(4).trim()
      });
      i++;
      continue;
    }
    if (trimmed.startsWith('## ')) {
      blocks.push({
        id: generateId(),
        type: 'heading-2',
        content: trimmed.slice(3).trim()
      });
      i++;
      continue;
    }
    if (trimmed.startsWith('# ')) {
      blocks.push({
        id: generateId(),
        type: 'heading-1',
        content: trimmed.slice(2).trim()
      });
      i++;
      continue;
    }

    // 4. Checklist: - [ ] or - [x]
    const checklistMatch = trimmed.match(/^[-*]\s*\[([ xX])\]\s*(.*)$/);
    if (checklistMatch) {
      blocks.push({
        id: generateId(),
        type: 'checklist',
        checked: checklistMatch[1].toLowerCase() === 'x',
        content: checklistMatch[2].trim()
      });
      i++;
      continue;
    }

    // 5. Bullet List: - item or * item
    const bulletMatch = trimmed.match(/^[-*]\s+(.*)$/);
    if (bulletMatch) {
      blocks.push({
        id: generateId(),
        type: 'bullet-list',
        content: bulletMatch[1].trim()
      });
      i++;
      continue;
    }

    // 6. Numbered List: 1. item
    const numberMatch = trimmed.match(/^\d+\.\s+(.*)$/);
    if (numberMatch) {
      blocks.push({
        id: generateId(),
        type: 'numbered-list',
        content: numberMatch[1].trim()
      });
      i++;
      continue;
    }

    // 7. Callout or Quote: gather consecutive lines starting with >
    if (trimmed.startsWith('>')) {
      const quoteLines: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith('>')) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, ''));
        i++;
      }

      const fullQuoteText = quoteLines.join('\n');
      const firstLine = quoteLines[0] || '';
      const calloutMatch = firstLine.match(/^\[!(NOTE|INFO|WARNING|TIP|SUCCESS)\]\s*(.*)$/i);

      if (calloutMatch) {
        const type = calloutMatch[1].toLowerCase() as any;
        const restLines = [calloutMatch[2], ...quoteLines.slice(1)].filter(Boolean);
        blocks.push({
          id: generateId(),
          type: 'callout',
          content: '',
          data: {
            icon: type === 'warning' ? '⚠️' : type === 'tip' ? '💡' : type === 'success' ? '✅' : 'ℹ️',
            type,
            text: restLines.join('\n').trim()
          }
        });
      } else {
        blocks.push({
          id: generateId(),
          type: 'quote',
          content: fullQuoteText
        });
      }
      continue;
    }

    // 8. Divider: --- or ***
    if (/^[-*_]{3,}$/.test(trimmed)) {
      blocks.push({
        id: generateId(),
        type: 'divider',
        content: ''
      });
      i++;
      continue;
    }

    // 9. Markdown Table: | col 1 | col 2 |
    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      const tableLines: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith('|') && lines[i].trim().endsWith('|')) {
        tableLines.push(lines[i].trim());
        i++;
      }
      const parsedTable = parseMarkdownTable(tableLines);
      if (parsedTable) {
        blocks.push({
          id: generateId(),
          type: 'table',
          content: '',
          data: parsedTable
        });
        continue;
      }
    }

    // 10. Default: Paragraph
    blocks.push({
      id: generateId(),
      type: 'paragraph',
      content: trimmed
    });
    i++;
  }

  return blocks.length > 0 ? blocks : [{ id: generateId(), type: 'paragraph', content: '' }];
}

function parseMarkdownTable(lines: string[]): TableBlockData | null {
  if (lines.length < 2) return null;
  
  const parseRow = (line: string) => line.slice(1, -1).split('|').map(c => c.trim());
  const headerCols = parseRow(lines[0]);
  
  const separatorLine = lines[1];
  const isSeparator = /^\|(\s*[-:]+\s*\|)+$/.test(separatorLine);
  
  const dataStart = isSeparator ? 2 : 1;
  const columns = headerCols.map((col, idx) => ({
    id: 'col_' + idx,
    title: col || `Column ${idx + 1}`,
    type: 'text' as const,
    width: 160
  }));

  const rows = [];
  for (let r = dataStart; r < lines.length; r++) {
    const rowValues = parseRow(lines[r]);
    const cells: Record<string, string> = {};
    columns.forEach((col, idx) => {
      cells[col.id] = rowValues[idx] || '';
    });
    rows.push({
      id: 'row_' + r,
      cells
    });
  }

  return { columns, rows, summaryType: 'count' };
}

/**
 * Convert structured note blocks into clean Markdown
 */
export function blocksToMarkdown(note: Note): string {
  const frontmatter = [
    '---',
    `title: "${note.title.replace(/"/g, '\\"')}"`,
    `id: ${note.id}`,
    `tags: [${note.tags.map(t => `"${t}"`).join(', ')}]`,
    `created: ${note.createdAt}`,
    `updated: ${note.updatedAt}`,
    '---\n'
  ].join('\n');

  const contentParts: string[] = [];

  for (const block of note.blocks) {
    switch (block.type) {
      case 'heading-1':
        contentParts.push(`# ${block.content}`);
        break;
      case 'heading-2':
        contentParts.push(`## ${block.content}`);
        break;
      case 'heading-3':
        contentParts.push(`### ${block.content}`);
        break;
      case 'bullet-list':
        contentParts.push(`- ${block.content}`);
        break;
      case 'numbered-list':
        contentParts.push(`1. ${block.content}`);
        break;
      case 'checklist':
        contentParts.push(`- [${block.checked ? 'x' : ' '}] ${block.content}`);
        break;
      case 'quote':
        contentParts.push(`> ${block.content}`);
        break;
      case 'callout': {
        const calloutType = (block.data?.type || 'NOTE').toUpperCase();
        contentParts.push(`> [!${calloutType}]\n> ${block.data?.text || block.content}`);
        break;
      }
      case 'code':
        contentParts.push(`\`\`\`${block.data?.language || ''}\n${block.data?.code || block.content}\n\`\`\``);
        break;
      case 'equation':
        contentParts.push(`$$\n${block.content}\n$$`);
        break;
      case 'divider':
        contentParts.push('---');
        break;
      case 'table': {
        const table = block.data as TableBlockData;
        if (table && table.columns && table.columns.length > 0) {
          const header = '| ' + table.columns.map(c => c.title).join(' | ') + ' |';
          const sep = '| ' + table.columns.map(() => '---').join(' | ') + ' |';
          const dataRows = (table.rows || []).map(r => {
            return '| ' + table.columns.map(c => (r.cells[c.id] ?? '').toString()).join(' | ') + ' |';
          });
          contentParts.push([header, sep, ...dataRows].join('\n'));
        }
        break;
      }
      default:
        contentParts.push(block.content || '');
    }
  }

  return frontmatter + contentParts.join('\n\n');
}

/**
 * Export Note to Standalone, Beautiful HTML Document
 */
export function noteToHtml(note: Note): string {
  let bodyHtml = `<h1>${escapeHtml(note.title)}</h1>\n`;
  if (note.tags && note.tags.length > 0) {
    bodyHtml += `<div class="tags">${note.tags.map(t => `<span class="tag">#${escapeHtml(t)}</span>`).join(' ')}</div>\n`;
  }

  for (const block of note.blocks) {
    switch (block.type) {
      case 'heading-1':
        bodyHtml += `<h1>${escapeHtml(block.content)}</h1>\n`;
        break;
      case 'heading-2':
        bodyHtml += `<h2>${escapeHtml(block.content)}</h2>\n`;
        break;
      case 'heading-3':
        bodyHtml += `<h3>${escapeHtml(block.content)}</h3>\n`;
        break;
      case 'bullet-list':
        bodyHtml += `<ul><li>${formatRichText(block.content)}</li></ul>\n`;
        break;
      case 'numbered-list':
        bodyHtml += `<ol><li>${formatRichText(block.content)}</li></ol>\n`;
        break;
      case 'checklist':
        bodyHtml += `<div class="checklist"><input type="checkbox" ${block.checked ? 'checked' : ''} disabled /> <span>${formatRichText(block.content)}</span></div>\n`;
        break;
      case 'quote':
        bodyHtml += `<blockquote>${formatRichText(block.content)}</blockquote>\n`;
        break;
      case 'callout':
        bodyHtml += `<div class="callout callout-${block.data?.type || 'info'}"><strong>${block.data?.icon || 'ℹ️'}</strong> ${formatRichText(block.data?.text || block.content)}</div>\n`;
        break;
      case 'code':
        bodyHtml += `<pre><code>${escapeHtml(block.data?.code || block.content)}</code></pre>\n`;
        break;
      case 'divider':
        bodyHtml += `<hr />\n`;
        break;
      case 'table': {
        const table = block.data as TableBlockData;
        if (table && table.columns) {
          let tbl = '<table class="styled-table"><thead><tr>';
          for (const col of table.columns) {
            tbl += `<th>${escapeHtml(col.title)}</th>`;
          }
          tbl += '</tr></thead><tbody>';
          for (const row of table.rows || []) {
            tbl += '<tr>';
            for (const col of table.columns) {
              tbl += `<td>${escapeHtml((row.cells[col.id] ?? '').toString())}</td>`;
            }
            tbl += '</tr>';
          }
          tbl += '</tbody></table>\n';
          bodyHtml += tbl;
        }
        break;
      }
      default:
        if (block.content.trim()) {
          bodyHtml += `<p>${formatRichText(block.content)}</p>\n`;
        }
    }
  }

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${escapeHtml(note.title)}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #1e293b; max-width: 800px; margin: 40px auto; padding: 0 20px; }
    h1 { font-size: 2.2rem; margin-bottom: 0.5rem; color: #0f172a; }
    h2 { font-size: 1.6rem; margin-top: 1.8rem; margin-bottom: 0.4rem; color: #1e293b; }
    h3 { font-size: 1.25rem; margin-top: 1.4rem; margin-bottom: 0.3rem; color: #334155; }
    p { margin: 0.8rem 0; }
    .tags { margin-bottom: 1.5rem; }
    .tag { display: inline-block; background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 9999px; font-size: 0.85rem; margin-right: 6px; }
    blockquote { border-left: 4px solid #94a3b8; padding-left: 1rem; color: #475569; margin: 1rem 0; font-style: italic; }
    .callout { padding: 12px 16px; border-radius: 8px; margin: 1rem 0; background: #f8fafc; border: 1px solid #e2e8f0; }
    .callout-warning { background: #fffbeb; border-color: #fde68a; }
    .callout-success { background: #f0fdf4; border-color: #bbf7d0; }
    .callout-tip { background: #faf5ff; border-color: #e9d5ff; }
    pre { background: #0f172a; color: #f8fafc; padding: 14px; border-radius: 8px; overflow-x: auto; }
    code { font-family: 'JetBrains Mono', monospace; font-size: 0.9em; }
    .styled-table { width: 100%; border-collapse: collapse; margin: 1.5rem 0; font-size: 0.95rem; }
    .styled-table th, .styled-table td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
    .styled-table th { background: #f1f5f9; font-weight: 600; }
    .checklist { display: flex; align-items: center; gap: 8px; margin: 4px 0; }
    hr { border: none; border-top: 1px solid #e2e8f0; margin: 2rem 0; }
    .wikilink { color: #2563eb; text-decoration: none; font-weight: 500; }
  </style>
</head>
<body>
  ${bodyHtml}
</body>
</html>`;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatRichText(text: string): string {
  let res = escapeHtml(text);
  res = res.replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g, '<a class="wikilink" href="#">$1</a>');
  res = res.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  res = res.replace(/\*(.*?)\*/g, '<em>$1</em>');
  res = res.replace(/`([^`]+)`/g, '<code>$1</code>');
  return res;
}
