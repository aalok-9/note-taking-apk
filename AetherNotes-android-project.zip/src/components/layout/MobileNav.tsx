﻿import React from 'react';
import { FileText, Share2, CheckSquare, Sparkles, Settings, Menu } from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';

interface MobileNavProps {
  onToggleSidebar: () => void;
  onOpenQuickCapture: () => void;
  onOpenSettings: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  onToggleSidebar,
  onOpenQuickCapture,
  onOpenSettings,
}) => {
  const { mainView, setMainView } = useWorkspace();

  return (
    <div className="md:hidden h-14 border-t border-zinc-200/80 dark:border-zinc-800/80 bg-white dark:bg-zinc-950 px-4 flex items-center justify-around shrink-0 z-30 select-none">
      <button
        onClick={onToggleSidebar}
        className="flex flex-col items-center justify-center text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
      >
        <Menu className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">Menu</span>
      </button>

      <button
        onClick={() => setMainView('note')}
        className={`flex flex-col items-center justify-center transition ${
          mainView === 'note'
            ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
            : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
        }`}
      >
        <FileText className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">Notes</span>
      </button>

      {/* Floating Center Quick Capture */}
      <button
        onClick={onOpenQuickCapture}
        className="w-10 h-10 -mt-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg hover:scale-105 transition"
      >
        <Sparkles className="w-5 h-5" />
      </button>

      <button
        onClick={() => setMainView('graph')}
        className={`flex flex-col items-center justify-center transition ${
          mainView === 'graph'
            ? 'text-purple-600 dark:text-purple-400 font-semibold'
            : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
        }`}
      >
        <Share2 className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">Graph</span>
      </button>

      <button
        onClick={onOpenSettings}
        className="flex flex-col items-center justify-center text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
      >
        <Settings className="w-5 h-5" />
        <span className="text-[10px] mt-0.5">Settings</span>
      </button>
    </div>
  );
};
