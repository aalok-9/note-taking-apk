﻿import React, { useState } from 'react';
import {
  FolderPlus,
  Folder,
  FolderOpen,
  Tag,
  Star,
  Trash2,
  Share2,
  CheckSquare,
  Search,
  Settings,
  Plus,
  Moon,
  Sun,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Command,
  FileText,
  PenTool,
  MoreVertical
} from 'lucide-react';
import { useWorkspace, MainViewType } from '../../hooks/useWorkspace';
import { extractTags } from '../../domain/wikilinks';

interface SidebarProps {
  onOpenSettings: () => void;
  onOpenCommandPalette: () => void;
  onOpenSearch: () => void;
  onOpenQuickCapture: () => void;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onOpenSettings,
  onOpenCommandPalette,
  onOpenSearch,
  onOpenQuickCapture,
  isMobileOpen,
  onCloseMobile,
}) => {
  const {
    workspace,
    folders,
    notes,
    selectedFolderId,
    setSelectedFolderId,
    selectedTag,
    setSelectedTag,
    filterFavorites,
    setFilterFavorites,
    mainView,
    setMainView,
    createNote,
    createFolder,
    deleteFolder,
  } = useWorkspace();

  const [isFoldersOpen, setIsFoldersOpen] = useState(true);
  const [isTagsOpen, setIsTagsOpen] = useState(true);
  const [newFolderName, setNewFolderName] = useState('');
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [activeFolderMenuId, setActiveFolderMenuId] = useState<string | null>(null);

  // Compute all unique tags
  const allTagsMap = new Map<string, number>();
  for (const note of notes) {
    if (!note.inTrash) {
      const tags = extractTags(note);
      for (const t of tags) {
        allTagsMap.set(t, (allTagsMap.get(t) || 0) + 1);
      }
    }
  }

  const activeNotesCount = notes.filter((n) => !n.inTrash).length;
  const favoriteNotesCount = notes.filter((n) => !n.inTrash && n.isFavorite).length;
  const trashNotesCount = notes.filter((n) => !!n.inTrash).length;

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newFolderName.trim()) {
      await createFolder(newFolderName.trim());
      setNewFolderName('');
      setIsCreatingFolder(false);
    }
  };

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 w-64 bg-zinc-50 dark:bg-zinc-950 border-r border-zinc-200/80 dark:border-zinc-800/80 flex flex-col transition-transform duration-300 md:relative md:translate-x-0 ${
        isMobileOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      {/* App Header & Brand */}
      <div className="p-4 border-b border-zinc-200/80 dark:border-zinc-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-sm font-bold text-base">
            ✦
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
              AetherNotes
              <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300">
                Local
              </span>
            </h1>
            <p className="text-[11px] text-zinc-400 truncate max-w-[130px]">
              {workspace.name}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="p-3 space-y-1.5">
        <button
          onClick={() => createNote({ title: 'Untitled Note' })}
          className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs shadow-sm transition group"
        >
          <span className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            New Note
          </span>
          <span className="text-[10px] bg-emerald-700/60 px-1.5 py-0.5 rounded text-emerald-100 font-mono">
            Ctrl+N
          </span>
        </button>

        <div className="grid grid-cols-2 gap-1.5 pt-1">
          <button
            onClick={onOpenSearch}
            className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200/80 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-medium transition"
          >
            <Search className="w-3.5 h-3.5" />
            Search
          </button>
          <button
            onClick={onOpenCommandPalette}
            className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200/80 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-medium transition"
          >
            <Command className="w-3.5 h-3.5" />
            Palette
          </button>
        </div>
      </div>

      {/* Scrollable Navigation Area */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-4 text-xs font-medium text-zinc-600 dark:text-zinc-400 custom-scrollbar">
        {/* Core Views */}
        <div className="space-y-0.5">
          <button
            onClick={() => {
              setMainView('note');
              setSelectedFolderId(null);
              setSelectedTag(null);
              setFilterFavorites(false);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl transition ${
              mainView === 'note' && !selectedFolderId && !selectedTag && !filterFavorites
                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <FileText className="w-4 h-4 text-emerald-600" />
              All Notes
            </span>
            <span className="text-[11px] text-zinc-400">{activeNotesCount}</span>
          </button>

          <button
            onClick={() => {
              setMainView('note');
              setSelectedFolderId(null);
              setSelectedTag(null);
              setFilterFavorites(true);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl transition ${
              filterFavorites
                ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500/30" />
              Favorites
            </span>
            <span className="text-[11px] text-zinc-400">{favoriteNotesCount}</span>
          </button>

          <button
            onClick={() => {
              setMainView('tasks');
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl transition ${
              mainView === 'tasks'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <CheckSquare className="w-4 h-4 text-blue-500" />
              Tasks & To-Dos
            </span>
          </button>

          <button
            onClick={() => {
              setMainView('graph');
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl transition ${
              mainView === 'graph'
                ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Share2 className="w-4 h-4 text-purple-500" />
              Knowledge Graph
            </span>
          </button>
        </div>

        {/* Folders Section */}
        <div className="pt-2">
          <div className="flex items-center justify-between px-1 mb-1 text-[11px] font-semibold tracking-wider text-zinc-400 uppercase">
            <button
              onClick={() => setIsFoldersOpen(!isFoldersOpen)}
              className="flex items-center gap-1 hover:text-zinc-600 dark:hover:text-zinc-200 transition"
            >
              {isFoldersOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              Folders
            </button>
            <button
              onClick={() => setIsCreatingFolder(true)}
              className="p-0.5 rounded hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
              title="Add Folder"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {isCreatingFolder && (
            <form onSubmit={handleCreateFolder} className="p-1 mb-2">
              <input
                type="text"
                autoFocus
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="Folder name..."
                onBlur={() => !newFolderName && setIsCreatingFolder(false)}
                className="w-full px-2.5 py-1 text-xs rounded-lg border border-emerald-500 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 outline-none shadow-sm"
              />
            </form>
          )}

          {isFoldersOpen && (
            <div className="space-y-0.5 pl-1">
              {folders.map((folder) => {
                const count = notes.filter((n) => !n.inTrash && n.folderId === folder.id).length;
                const isSelected = mainView === 'note' && selectedFolderId === folder.id;
                return (
                  <div
                    key={folder.id}
                    className={`group relative flex items-center justify-between px-2.5 py-1.5 rounded-xl cursor-pointer transition ${
                      isSelected
                        ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 font-semibold'
                        : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300'
                    }`}
                    onClick={() => {
                      setMainView('note');
                      setSelectedFolderId(folder.id);
                      setSelectedTag(null);
                      setFilterFavorites(false);
                    }}
                  >
                    <span className="flex items-center gap-2 truncate">
                      {isSelected ? (
                        <FolderOpen className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      ) : (
                        <Folder className="w-3.5 h-3.5 text-zinc-400 shrink-0 group-hover:text-zinc-600 dark:group-hover:text-zinc-300" />
                      )}
                      <span className="truncate">{folder.name}</span>
                    </span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-zinc-400">{count}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Tags Section */}
        <div className="pt-2">
          <div className="flex items-center justify-between px-1 mb-1 text-[11px] font-semibold tracking-wider text-zinc-400 uppercase">
            <button
              onClick={() => setIsTagsOpen(!isTagsOpen)}
              className="flex items-center gap-1 hover:text-zinc-600 dark:hover:text-zinc-200 transition"
            >
              {isTagsOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              Tags
            </button>
          </div>

          {isTagsOpen && (
            <div className="flex flex-wrap gap-1 pl-1 pt-1">
              {Array.from(allTagsMap.entries()).map(([tag, count]) => {
                const isSelected = selectedTag === tag;
                return (
                  <button
                    key={tag}
                    onClick={() => {
                      setMainView('note');
                      setSelectedTag(isSelected ? null : tag);
                      setSelectedFolderId(null);
                      setFilterFavorites(false);
                    }}
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] transition ${
                      isSelected
                        ? 'bg-emerald-500 text-white font-medium shadow-sm'
                        : 'bg-zinc-200/70 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300'
                    }`}
                  >
                    #{tag}
                    <span className="text-[9px] opacity-75">{count}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Trash */}
        <div className="pt-4 border-t border-zinc-200/80 dark:border-zinc-800/80">
          <button
            onClick={() => setMainView('trash')}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl transition ${
              mainView === 'trash'
                ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Trash2 className="w-4 h-4 text-zinc-400 group-hover:text-rose-500" />
              Trash
            </span>
            <span className="text-[11px] text-zinc-400">{trashNotesCount}</span>
          </button>
        </div>
      </div>

      {/* Footer Settings & Quick Capture */}
      <div className="p-3 border-t border-zinc-200/80 dark:border-zinc-800/80 flex items-center justify-between bg-zinc-100/50 dark:bg-zinc-900/50">
        <button
          onClick={onOpenSettings}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-zinc-200/70 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300 text-xs font-medium transition"
        >
          <Settings className="w-4 h-4" />
          Settings
        </button>

        <button
          onClick={onOpenQuickCapture}
          className="p-2 rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 hover:scale-105 transition shadow-2xs"
          title="Quick Capture (Ctrl+Shift+N)"
        >
          <Sparkles className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
