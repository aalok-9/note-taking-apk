﻿import React from 'react';
import { Trash2, RotateCcw, AlertTriangle, FileText, Calendar } from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';
import { getAllBlockText } from '../../domain/wikilinks';

export const TrashView: React.FC = () => {
  const { notes, restoreNote, deleteNote, emptyTrash } = useWorkspace();

  const trashNotes = notes.filter((n) => !!n.inTrash);

  const handleEmptyTrash = () => {
    if (
      window.confirm(
        'Are you sure you want to permanently delete all notes in Trash? This action cannot be undone.'
      )
    ) {
      emptyTrash();
    }
  };

  return (
    <div className="max-w-4xl mx-auto w-full px-8 py-10 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-zinc-200 dark:border-zinc-800">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
            <Trash2 className="w-6 h-6 text-rose-500" />
            Trash
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Notes in trash are safely preserved until permanently emptied.
          </p>
        </div>

        {trashNotes.length > 0 && (
          <button
            onClick={handleEmptyTrash}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold shadow-xs transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Empty Trash ({trashNotes.length})
          </button>
        )}
      </div>

      {/* Trash list */}
      {trashNotes.length === 0 ? (
        <div className="py-16 text-center text-zinc-400 space-y-2">
          <Trash2 className="w-12 h-12 mx-auto stroke-1 text-zinc-300 dark:text-zinc-700" />
          <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Trash is empty</p>
          <p className="text-xs text-zinc-400">Deleted notes will appear here.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {trashNotes.map((note) => {
            const preview = getAllBlockText(note.blocks).trim().slice(0, 100) || 'Empty note...';
            return (
              <div
                key={note.id}
                className="p-4 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 bg-white dark:bg-zinc-900 flex items-start justify-between gap-4 shadow-xs"
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-500 shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-xs text-zinc-900 dark:text-zinc-100 truncate">
                      {note.title || 'Untitled Note'}
                    </h3>
                    <p className="text-[11px] text-zinc-500 line-clamp-2 mt-0.5 leading-relaxed">
                      {preview}
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-[10px] text-zinc-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Deleted on {new Date(note.trashDate || note.updatedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => restoreNote(note.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 font-semibold text-xs transition"
                    title="Restore Note"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Restore
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm(`Permanently delete "${note.title || 'Untitled'}"?`)) {
                        deleteNote(note.id, true);
                      }
                    }}
                    className="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-zinc-400 hover:text-rose-600 transition"
                    title="Delete Permanently"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
