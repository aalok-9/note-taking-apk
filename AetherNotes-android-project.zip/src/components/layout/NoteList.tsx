﻿import React, { useState } from 'react';
import {
  Search,
  Plus,
  Star,
  Pin,
  FileText,
  PenTool,
  Calendar,
  MoreVertical,
  Trash2,
  Copy,
  ArrowUpDown,
  Download
} from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';
import { getAllBlockText } from '../../domain/wikilinks';
import { PortabilityService } from '../../services/portability';
import { showToast } from '../common/Toast';

export const NoteList: React.FC = () => {
  const {
    notes,
    folders,
    activeNoteId,
    setActiveNoteId,
    selectedFolderId,
    selectedTag,
    filterFavorites,
    createNote,
    deleteNote,
    duplicateNote,
    toggleFavorite,
    togglePin,
  } = useWorkspace();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'editor' | 'canvas' | 'pdf'>('all');
  const [sortBy, setSortBy] = useState<'updated' | 'created' | 'title'>('updated');
  const [activeMenuNoteId, setActiveMenuNoteId] = useState<string | null>(null);

  const currentFolder = folders.find((f) => f.id === selectedFolderId);

  // Filter notes
  let filteredNotes = notes.filter((note) => {
    if (note.inTrash) return false;
    if (selectedFolderId && note.folderId !== selectedFolderId) return false;
    if (selectedTag && !note.tags.map((t) => t.toLowerCase()).includes(selectedTag.toLowerCase())) return false;
    if (filterFavorites && !note.isFavorite) return false;
    if (filterMode !== 'all' && note.viewMode !== filterMode) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const titleMatch = (note.title || '').toLowerCase().includes(q);
      const contentMatch = getAllBlockText(note.blocks).toLowerCase().includes(q);
      const tagMatch = (note.tags || []).some((t) => t.toLowerCase().includes(q));
      if (!titleMatch && !contentMatch && !tagMatch) return false;
    }

    return true;
  });

  // Sort notes
  filteredNotes.sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;

    if (sortBy === 'title') {
      return (a.title || 'Untitled').localeCompare(b.title || 'Untitled');
    }
    if (sortBy === 'created') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  const getHeaderTitle = () => {
    if (filterFavorites) return 'Favorites';
    if (selectedTag) return `#${selectedTag}`;
    if (currentFolder) return currentFolder.name;
    return 'All Notes';
  };

  return (
    <div className="w-80 h-full border-r border-zinc-200/80 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/60 flex flex-col shrink-0 select-none">
      {/* Header */}
      <div className="p-3.5 border-b border-zinc-200/80 dark:border-zinc-800/80 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 truncate">
            <h2 className="font-bold text-sm text-zinc-900 dark:text-zinc-100 truncate">
              {getHeaderTitle()}
            </h2>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 font-mono">
              {filteredNotes.length}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() =>
                setSortBy((prev) => (prev === 'updated' ? 'created' : prev === 'created' ? 'title' : 'updated'))
              }
              className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition"
              title={`Sorted by: ${sortBy}`}
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => createNote({ folderId: selectedFolderId || undefined })}
              className="p-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white shadow-xs transition"
              title="Create Note (Ctrl+N)"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search inside note list */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter notes..."
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl bg-zinc-100 dark:bg-zinc-800/80 border-none text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 outline-none focus:ring-2 focus:ring-emerald-500/40"
          />
        </div>

        {/* View Mode Filter Tabs */}
        <div className="flex gap-1 p-0.5 rounded-xl bg-zinc-100 dark:bg-zinc-800/80 text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
          {(['all', 'editor', 'canvas'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setFilterMode(mode)}
              className={`flex-1 py-1 rounded-lg text-center capitalize transition ${
                filterMode === mode
                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                  : 'hover:text-zinc-900 dark:hover:text-zinc-200'
              }`}
            >
              {mode === 'all' ? 'All' : mode === 'editor' ? 'Docs' : 'Canvas'}
            </button>
          ))}
        </div>
      </div>

      {/* Notes Cards Scrollable List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1.5 custom-scrollbar">
        {filteredNotes.length === 0 ? (
          <div className="py-12 text-center text-zinc-400 space-y-2">
            <FileText className="w-8 h-8 mx-auto stroke-1 text-zinc-300 dark:text-zinc-600" />
            <p className="text-xs">No notes in this view</p>
            <button
              onClick={() => createNote({ folderId: selectedFolderId || undefined })}
              className="text-xs font-semibold text-emerald-600 hover:underline inline-flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              Create a note
            </button>
          </div>
        ) : (
          filteredNotes.map((note) => {
            const isActive = activeNoteId === note.id;
            const previewText = getAllBlockText(note.blocks).trim().slice(0, 90) || 'Empty note...';
            const dateStr = new Date(note.updatedAt).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={note.id}
                onClick={() => setActiveNoteId(note.id)}
                className={`group relative p-3 rounded-2xl cursor-pointer border transition-all duration-150 ${
                  isActive
                    ? 'bg-emerald-50/80 dark:bg-emerald-950/25 border-emerald-500/50 shadow-xs'
                    : 'bg-white dark:bg-zinc-900/40 border-zinc-200/60 dark:border-zinc-800/60 hover:border-zinc-300 dark:hover:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
                }`}
              >
                {/* Title & Icons */}
                <div className="flex items-start justify-between gap-2 mb-1">
                  <div className="flex items-center gap-1.5 truncate">
                    {note.isPinned && (
                      <Pin className="w-3 h-3 text-emerald-600 fill-emerald-600 shrink-0" />
                    )}
                    {note.viewMode === 'canvas' ? (
                      <PenTool className="w-3.5 h-3.5 text-purple-500 shrink-0" />
                    ) : (
                      <FileText className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                    )}
                    <h3 className="font-semibold text-xs text-zinc-900 dark:text-zinc-100 truncate">
                      {note.title || 'Untitled Note'}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(note.id);
                      }}
                      className="p-0.5 text-zinc-400 hover:text-amber-500"
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          note.isFavorite ? 'text-amber-500 fill-amber-500' : ''
                        }`}
                      />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMenuNoteId(activeMenuNoteId === note.id ? null : note.id);
                      }}
                      className="p-0.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                    >
                      <MoreVertical className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Snippet Preview */}
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed mb-2 font-normal">
                  {note.viewMode === 'canvas' ? '🎨 Digital Canvas Document' : previewText}
                </p>

                {/* Meta footer: Date & Tag pills */}
                <div className="flex items-center justify-between text-[10px] text-zinc-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-2.5 h-2.5" />
                    {dateStr}
                  </span>

                  <div className="flex items-center gap-1 overflow-hidden max-w-[130px]">
                    {note.tags.slice(0, 2).map((tag) => (
                      <span
                        key={tag}
                        className="px-1.5 py-0.2 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 truncate font-medium"
                      >
                        #{tag}
                      </span>
                    ))}
                    {note.tags.length > 2 && (
                      <span className="text-[9px] text-zinc-400">+{note.tags.length - 2}</span>
                    )}
                  </div>
                </div>

                {/* Context Menu Dropdown */}
                {activeMenuNoteId === note.id && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="absolute right-2 top-8 z-30 w-40 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-2xl shadow-2xl p-1.5 text-xs space-y-0.5 animate-in fade-in zoom-in-95"
                  >
                    <button
                      onClick={() => {
                        togglePin(note.id);
                        setActiveMenuNoteId(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300"
                    >
                      <Pin className="w-3.5 h-3.5" />
                      {note.isPinned ? 'Unpin' : 'Pin to Top'}
                    </button>
                    <button
                      onClick={() => {
                        duplicateNote(note.id);
                        setActiveMenuNoteId(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Duplicate
                    </button>
                    <button
                      onClick={() => {
                        PortabilityService.exportSingleNote(note, 'markdown');
                        setActiveMenuNoteId(null);
                        showToast('Exported note as .md', 'success');
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Export Markdown
                    </button>
                    <div className="border-t border-zinc-100 dark:border-zinc-700 my-1" />
                    <button
                      onClick={() => {
                        deleteNote(note.id, false);
                        setActiveMenuNoteId(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Move to Trash
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
