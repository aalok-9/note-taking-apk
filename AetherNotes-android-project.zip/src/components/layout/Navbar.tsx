﻿import React, { useState } from 'react';
import {
  FileText,
  PenTool,
  FileCode,
  Star,
  Clock,
  Download,
  Printer,
  PanelRightClose,
  PanelRightOpen,
  PanelLeftClose,
  PanelLeftOpen,
  Menu,
  Moon,
  Sun,
  CheckCircle,
  Loader2,
  ChevronDown,
  Tablet,
  Laptop
} from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';
import { useTheme } from '../../hooks/useTheme';
import { PortabilityService } from '../../services/portability';
import { ViewMode } from '../../types';
import { showToast } from '../common/Toast';

interface NavbarProps {
  onToggleMobileSidebar: () => void;
  isInspectorOpen: boolean;
  onToggleInspector: () => void;
  onOpenHistory: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleMobileSidebar,
  isInspectorOpen,
  onToggleInspector,
  onOpenHistory,
}) => {
  const {
    activeNote,
    folders,
    saveStatus,
    updateActiveNote,
    toggleFavorite,
    isTabletMode,
    setIsTabletMode,
    isNoteListOpen,
    setIsNoteListOpen,
    mainView,
  } = useWorkspace();

  const { settings, updateSettings } = useTheme();
  const [isExportOpen, setIsExportOpen] = useState(false);

  const folder = folders.find((f) => f.id === activeNote?.folderId);

  const handleExport = (format: 'markdown' | 'html' | 'txt' | 'json') => {
    if (!activeNote) return;
    PortabilityService.exportSingleNote(activeNote, format);
    setIsExportOpen(false);
    showToast(`Exported note as .${format}`, 'success');
  };

  const handlePrint = () => {
    if (!activeNote) return;
    PortabilityService.printNote(activeNote);
    setIsExportOpen(false);
  };

  const handleViewModeChange = (mode: ViewMode) => {
    if (!activeNote) return;
    if (mode === 'canvas' && !activeNote.canvasData) {
      updateActiveNote(
        {
          viewMode: mode,
          canvasData: {
            strokes: [],
            shapes: [],
            texts: [],
            images: [],
            paperConfig: {
              template: settings.defaultPaperTemplate || 'ruled',
              tint: settings.defaultPaperTint || 'light',
              lineSpacing: 28,
              gridSize: 24,
              showMargin: true,
              orientation: 'portrait',
            },
            viewport: { zoom: 1, panX: 0, panY: 0 },
          },
        },
        true
      );
    } else {
      updateActiveNote({ viewMode: mode }, true);
    }
  };

  return (
    <header className="h-14 border-b border-zinc-200/80 dark:border-zinc-800/80 bg-white dark:bg-zinc-950 px-4 flex items-center justify-between shrink-0 select-none z-20">
      {/* Left: Hamburger, Toggle Note List & Breadcrumbs */}
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleMobileSidebar}
          className="md:hidden p-2 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300"
          title="Open Navigation Drawer"
        >
          <Menu className="w-5 h-5" />
        </button>

        {mainView === 'note' && (
          <button
            onClick={() => setIsNoteListOpen((prev) => !prev)}
            className="hidden md:flex p-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition"
            title={isNoteListOpen ? 'Collapse Note List' : 'Expand Note List'}
          >
            {isNoteListOpen ? (
              <PanelLeftClose className="w-4 h-4" />
            ) : (
              <PanelLeftOpen className="w-4 h-4" />
            )}
          </button>
        )}

        <div className="flex items-center gap-2 text-xs text-zinc-500 font-medium pl-1">
          {folder && (
            <>
              <span className="hidden sm:flex items-center gap-1 text-zinc-600 dark:text-zinc-400">
                📁 {folder.name}
              </span>
              <span className="hidden sm:inline text-zinc-300 dark:text-zinc-700">/</span>
            </>
          )}
          <span className="text-zinc-800 dark:text-zinc-200 font-bold truncate max-w-[180px] sm:max-w-[240px]">
            {activeNote?.title || (mainView === 'graph' ? 'Knowledge Graph' : mainView === 'tasks' ? 'Tasks' : 'Trash')}
          </span>
        </div>
      </div>

      {/* Center: Mode switcher (Docs / Canvas) */}
      {mainView === 'note' && activeNote && (
        <div className="flex items-center bg-zinc-100 dark:bg-zinc-900 p-0.5 rounded-xl border border-zinc-200/60 dark:border-zinc-800/60 shadow-2xs">
          <button
            onClick={() => handleViewModeChange('editor')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeNote.viewMode === 'editor'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Document</span>
          </button>
          <button
            onClick={() => handleViewModeChange('canvas')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeNote.viewMode === 'canvas'
                ? 'bg-white dark:bg-zinc-800 text-purple-600 dark:text-purple-400 font-semibold shadow-xs'
                : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Digital Paper</span>
          </button>
        </div>
      )}

      {/* Right: Actions & Tools */}
      <div className="flex items-center gap-1">
        {/* Autosave badge */}
        <div className="hidden lg:flex items-center gap-1.5 mr-2 text-[11px] text-zinc-400">
          {saveStatus === 'saved' && (
            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
              <CheckCircle className="w-3 h-3" />
              Saved
            </span>
          )}
          {saveStatus === 'saving' && (
            <span className="flex items-center gap-1 text-amber-500 font-medium">
              <Loader2 className="w-3 h-3 animate-spin" />
              Saving...
            </span>
          )}
          {saveStatus === 'unsaved' && <span className="text-zinc-400">Unsaved</span>}
        </div>

        {/* Tablet Mode Toggle */}
        <button
          onClick={() => {
            setIsTabletMode((prev) => {
              const next = !prev;
              showToast(next ? 'Tablet / Touch Studio Mode Enabled' : 'Desktop Layout Mode Enabled', 'info');
              return next;
            });
          }}
          className={`p-1.5 rounded-xl transition ${
            isTabletMode
              ? 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-semibold'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
          title={isTabletMode ? 'Switch to Desktop Mode' : 'Switch to Tablet / Touch Studio Mode'}
        >
          {isTabletMode ? <Tablet className="w-4 h-4" /> : <Laptop className="w-4 h-4" />}
        </button>

        {/* Favorite */}
        {mainView === 'note' && activeNote && (
          <button
            onClick={() => toggleFavorite(activeNote.id)}
            className="p-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-amber-500 transition"
            title="Toggle Favorite"
          >
            <Star
              className={`w-4 h-4 ${
                activeNote.isFavorite ? 'text-amber-500 fill-amber-500' : ''
              }`}
            />
          </button>
        )}

        {/* History snapshots */}
        {mainView === 'note' && activeNote && (
          <button
            onClick={onOpenHistory}
            className="p-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition"
            title="Version Snapshots"
          >
            <Clock className="w-4 h-4" />
          </button>
        )}

        {/* Export dropdown */}
        {mainView === 'note' && activeNote && (
          <div className="relative">
            <button
              onClick={() => setIsExportOpen(!isExportOpen)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300 text-xs font-medium transition"
              title="Export Note"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export</span>
              <ChevronDown className="w-3 h-3 text-zinc-400" />
            </button>

            {isExportOpen && (
              <div
                onClick={() => setIsExportOpen(false)}
                className="absolute right-0 top-9 z-50 w-44 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-2xl shadow-2xl p-1 text-xs space-y-0.5 animate-in fade-in zoom-in-95"
              >
                <button
                  onClick={() => handleExport('markdown')}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-500" />
                  Markdown (.md)
                </button>
                <button
                  onClick={() => handleExport('html')}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                >
                  <FileCode className="w-3.5 h-3.5 text-orange-500" />
                  HTML Document (.html)
                </button>
                <button
                  onClick={() => handleExport('txt')}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                >
                  <FileText className="w-3.5 h-3.5 text-zinc-400" />
                  Plain Text (.txt)
                </button>
                <div className="border-t border-zinc-100 dark:border-zinc-700 my-1" />
                <button
                  onClick={handlePrint}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 font-medium"
                >
                  <Printer className="w-3.5 h-3.5 text-purple-500" />
                  Print / Save to PDF
                </button>
              </div>
            )}
          </div>
        )}

        {/* Theme quick toggle */}
        <button
          onClick={() =>
            updateSettings({
              theme: settings.theme === 'dark' ? 'light' : 'dark',
            })
          }
          className="p-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition"
          title="Toggle Dark / Light Theme"
        >
          {settings.theme === 'dark' ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4" />
          )}
        </button>

        {/* Toggle Right Inspector */}
        {mainView === 'note' && (
          <button
            onClick={onToggleInspector}
            className={`p-1.5 rounded-xl transition ${
              isInspectorOpen
                ? 'bg-zinc-100 dark:bg-zinc-800 text-emerald-600 dark:text-emerald-400'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
            title="Toggle Details & Backlinks"
          >
            {isInspectorOpen ? (
              <PanelRightClose className="w-4 h-4" />
            ) : (
              <PanelRightOpen className="w-4 h-4" />
            )}
          </button>
        )}
      </div>
    </header>
  );
};
