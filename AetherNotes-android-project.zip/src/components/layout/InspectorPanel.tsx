﻿import React, { useState } from 'react';
import {
  Link2,
  ListTree,
  Tag,
  Info,
  Calendar,
  FileText,
  Clock,
  Plus,
  X,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';
import { computeBacklinks, extractWikilinks, getAllBlockText } from '../../domain/wikilinks';

export const InspectorPanel: React.FC = () => {
  const { notes, activeNote, setActiveNoteId, updateActiveNote } = useWorkspace();
  const [activeTab, setActiveTab] = useState<'backlinks' | 'outline' | 'tags' | 'info'>('backlinks');
  const [newTagInput, setNewTagInput] = useState('');

  if (!activeNote) return null;

  const backlinks = computeBacklinks(activeNote, notes);
  const outgoingLinks = extractWikilinks(activeNote.blocks);

  // Outline generation from headings
  const headings = activeNote.blocks
    .filter((b) => ['heading-1', 'heading-2', 'heading-3'].includes(b.type))
    .map((b) => ({
      id: b.id,
      text: b.content || 'Untitled Heading',
      level: b.type === 'heading-1' ? 1 : b.type === 'heading-2' ? 2 : 3,
    }));

  // Stats calculation
  const allText = getAllBlockText(activeNote.blocks);
  const wordCount = allText.trim() ? allText.trim().split(/\s+/).length : 0;
  const charCount = allText.length;
  const readingTimeMin = Math.max(1, Math.ceil(wordCount / 200));

  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    const tag = newTagInput.trim().replace(/^#/, '');
    if (tag && !activeNote.tags.includes(tag)) {
      updateActiveNote({ tags: [...activeNote.tags, tag] }, true);
      setNewTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    updateActiveNote({ tags: activeNote.tags.filter((t) => t !== tagToRemove) }, true);
  };

  const scrollToBlock = (blockId: string) => {
    const el = document.getElementById(`block-${blockId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <aside className="w-72 h-full border-l border-zinc-200/80 dark:border-zinc-800/80 bg-zinc-50/60 dark:bg-zinc-950 flex flex-col shrink-0 select-none">
      {/* Tab bar */}
      <div className="flex items-center border-b border-zinc-200/80 dark:border-zinc-800/80 p-1 bg-zinc-100/50 dark:bg-zinc-900/50 text-xs font-medium">
        <button
          onClick={() => setActiveTab('backlinks')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition ${
            activeTab === 'backlinks'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
              : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
          title="Backlinks & Linked Mentions"
        >
          <Link2 className="w-3.5 h-3.5" />
          <span>Links ({backlinks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('outline')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition ${
            activeTab === 'outline'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
              : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
          title="Document Outline"
        >
          <ListTree className="w-3.5 h-3.5" />
          <span>Outline</span>
        </button>

        <button
          onClick={() => setActiveTab('tags')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition ${
            activeTab === 'tags'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
              : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
          title="Tags & Properties"
        >
          <Tag className="w-3.5 h-3.5" />
          <span>Tags</span>
        </button>

        <button
          onClick={() => setActiveTab('info')}
          className={`py-1.5 px-2 rounded-lg flex items-center justify-center transition ${
            activeTab === 'info'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
              : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
          }`}
          title="Document Statistics & Metadata"
        >
          <Info className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Tab contents */}
      <div className="flex-1 overflow-y-auto p-3 text-xs custom-scrollbar">
        {/* BACKLINKS TAB */}
        {activeTab === 'backlinks' && (
          <div className="space-y-4">
            <div>
              <h4 className="font-bold text-zinc-800 dark:text-zinc-200 mb-2 flex items-center justify-between">
                <span>Incoming Backlinks</span>
                <span className="text-[10px] font-normal text-zinc-400">
                  {backlinks.length} {backlinks.length === 1 ? 'mention' : 'mentions'}
                </span>
              </h4>

              {backlinks.length === 0 ? (
                <div className="p-4 rounded-xl bg-zinc-100/60 dark:bg-zinc-900/60 text-center text-zinc-400 text-xs">
                  No backlinks to this note yet. Reference this note with{' '}
                  <code className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    [[{activeNote.title || 'Note'}]]
                  </code>
                </div>
              ) : (
                <div className="space-y-2">
                  {backlinks.map((bl, i) => (
                    <div
                      key={i}
                      onClick={() => setActiveNoteId(bl.noteId)}
                      className="p-2.5 rounded-xl border border-zinc-200/80 dark:border-zinc-800 bg-white dark:bg-zinc-900 hover:border-emerald-500/50 hover:bg-emerald-50/30 dark:hover:bg-emerald-950/20 cursor-pointer transition"
                    >
                      <div className="flex items-center justify-between mb-1 font-semibold text-zinc-800 dark:text-zinc-200">
                        <span className="truncate">{bl.noteTitle}</span>
                        <ExternalLink className="w-3 h-3 text-zinc-400 shrink-0" />
                      </div>
                      <p className="text-[11px] text-zinc-500 line-clamp-2 leading-relaxed italic">
                        "{bl.preview}"
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Outgoing links */}
            {outgoingLinks.length > 0 && (
              <div className="pt-2 border-t border-zinc-200/80 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-800 dark:text-zinc-200 mb-2">
                  Outgoing Links ({outgoingLinks.length})
                </h4>
                <div className="space-y-1">
                  {outgoingLinks.map((targetTitle, i) => {
                    const matchedNote = notes.find(
                      (n) => n.title.toLowerCase() === targetTitle.toLowerCase() && !n.inTrash
                    );
                    return (
                      <div
                        key={i}
                        onClick={() => matchedNote && setActiveNoteId(matchedNote.id)}
                        className={`flex items-center justify-between p-2 rounded-lg transition ${
                          matchedNote
                            ? 'bg-zinc-100 dark:bg-zinc-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 cursor-pointer'
                            : 'bg-zinc-100/50 dark:bg-zinc-900/50 text-zinc-400'
                        }`}
                      >
                        <span className="truncate font-medium">[[{targetTitle}]]</span>
                        {matchedNote ? (
                          <ChevronRight className="w-3 h-3" />
                        ) : (
                          <span className="text-[10px] text-zinc-400">Uncreated</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* OUTLINE TAB */}
        {activeTab === 'outline' && (
          <div>
            <h4 className="font-bold text-zinc-800 dark:text-zinc-200 mb-2">
              Document Outline
            </h4>
            {headings.length === 0 ? (
              <div className="p-4 rounded-xl bg-zinc-100/60 dark:bg-zinc-900/60 text-center text-zinc-400 text-xs">
                No headings found. Add H1, H2, or H3 headings to populate the outline.
              </div>
            ) : (
              <div className="space-y-1">
                {headings.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => scrollToBlock(h.id)}
                    style={{ paddingLeft: `${(h.level - 1) * 12 + 8}px` }}
                    className="w-full text-left py-1.5 pr-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 transition truncate text-xs flex items-center gap-1.5"
                  >
                    <span className="text-emerald-600 font-bold text-[10px]">
                      H{h.level}
                    </span>
                    <span className="truncate">{h.text}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAGS TAB */}
        {activeTab === 'tags' && (
          <div className="space-y-3">
            <h4 className="font-bold text-zinc-800 dark:text-zinc-200">
              Note Tags
            </h4>

            <form onSubmit={handleAddTag} className="flex gap-1.5">
              <input
                type="text"
                value={newTagInput}
                onChange={(e) => setNewTagInput(e.target.value)}
                placeholder="Add tag (e.g. Audit)..."
                className="flex-1 px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 text-xs outline-none focus:ring-1 focus:ring-emerald-500"
              />
              <button
                type="submit"
                className="p-1.5 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 transition"
              >
                <Plus className="w-4 h-4" />
              </button>
            </form>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {activeNote.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 font-medium text-xs shadow-2xs"
                >
                  #{tag}
                  <button
                    onClick={() => handleRemoveTag(tag)}
                    className="p-0.5 hover:bg-emerald-200 dark:hover:bg-emerald-800 rounded-full"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
              {activeNote.tags.length === 0 && (
                <p className="text-zinc-400 text-xs italic">No tags attached</p>
              )}
            </div>
          </div>
        )}

        {/* INFO TAB */}
        {activeTab === 'info' && (
          <div className="space-y-4">
            <h4 className="font-bold text-zinc-800 dark:text-zinc-200">
              Document Statistics
            </h4>

            <div className="grid grid-cols-2 gap-2">
              <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[10px] text-zinc-400 uppercase font-semibold">
                  Words
                </span>
                <p className="text-base font-bold text-zinc-800 dark:text-zinc-100 mt-0.5">
                  {wordCount.toLocaleString()}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[10px] text-zinc-400 uppercase font-semibold">
                  Characters
                </span>
                <p className="text-base font-bold text-zinc-800 dark:text-zinc-100 mt-0.5">
                  {charCount.toLocaleString()}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[10px] text-zinc-400 uppercase font-semibold">
                  Reading Time
                </span>
                <p className="text-base font-bold text-zinc-800 dark:text-zinc-100 mt-0.5">
                  ~{readingTimeMin} min
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[10px] text-zinc-400 uppercase font-semibold">
                  Version
                </span>
                <p className="text-base font-bold text-zinc-800 dark:text-zinc-100 mt-0.5">
                  v{activeNote.version || 1}
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-zinc-100/60 dark:bg-zinc-900/60 space-y-2 text-zinc-500 dark:text-zinc-400 text-[11px]">
              <div className="flex items-center justify-between">
                <span>Created</span>
                <span className="font-medium text-zinc-700 dark:text-zinc-300">
                  {new Date(activeNote.createdAt).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Last Updated</span>
                <span className="font-medium text-zinc-700 dark:text-zinc-300">
                  {new Date(activeNote.updatedAt).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Note ID</span>
                <span className="font-mono text-[10px] text-zinc-400">
                  {activeNote.id}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
