﻿import React, { useState } from 'react';
import {
  FileText,
  Highlighter,
  Pen,
  Type,
  MessageSquare,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Note, PdfData, PdfAnnotation } from '../../types';
import { generateId } from '../../domain/markdown';

interface PdfAnnotatorProps {
  note: Note;
  onUpdate: (fields: Partial<Note>, immediate?: boolean) => void;
}

export const PdfAnnotator: React.FC<PdfAnnotatorProps> = ({
  note,
  onUpdate,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [zoom, setZoom] = useState(1.0);
  const [activeTool, setActiveTool] = useState<'highlight' | 'stroke' | 'text' | 'comment'>('highlight');
  const [color, setColor] = useState('#fbbf24');

  const pdfData: PdfData = note.pdfData || {
    filename: 'Sample_Study_Document.pdf',
    totalPages: 5,
    annotations: [
      {
        id: 'ann_1',
        page: 1,
        type: 'highlight',
        color: '#fde047',
        rect: { x: 120, y: 180, width: 450, height: 24 },
        createdAt: new Date().toISOString(),
      },
      {
        id: 'ann_2',
        page: 1,
        type: 'comment',
        color: '#3b82f6',
        rect: { x: 590, y: 175, width: 24, height: 24 },
        comment: 'High probability question for upcoming exam. Revise Section 115BAA calculations.',
        author: 'Student',
        createdAt: new Date().toISOString(),
      },
    ],
  };

  const handleAddAnnotation = (rect: { x: number; y: number; width: number; height: number }) => {
    const newAnn: PdfAnnotation = {
      id: generateId(),
      page: currentPage,
      type: activeTool,
      color,
      rect,
      createdAt: new Date().toISOString(),
    };

    onUpdate({
      pdfData: {
        ...pdfData,
        annotations: [...pdfData.annotations, newAnn],
      },
    });
  };

  const pageAnnotations = pdfData.annotations.filter((a) => a.page === currentPage);

  return (
    <div className="relative w-full h-full flex flex-col bg-zinc-200/70 dark:bg-zinc-950 select-none overflow-hidden">
      {/* Top PDF Controls Bar */}
      <div className="h-12 border-b border-zinc-300 dark:border-zinc-800 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md px-4 flex items-center justify-between z-20">
        <div className="flex items-center gap-3">
          <FileText className="w-4 h-4 text-rose-500" />
          <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200 truncate max-w-[200px]">
            {pdfData.filename}
          </span>
          <span className="text-[11px] text-zinc-400">
            Page {currentPage} of {pdfData.totalPages}
          </span>
        </div>

        {/* Annotation tools */}
        <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl">
          <button
            onClick={() => {
              setActiveTool('highlight');
              setColor('#fbbf24');
            }}
            className={`p-1.5 rounded-lg text-xs font-medium transition ${
              activeTool === 'highlight'
                ? 'bg-amber-400 text-amber-950 font-bold shadow-xs'
                : 'text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
            }`}
            title="Text Highlighter"
          >
            <Highlighter className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setActiveTool('stroke');
              setColor('#ef4444');
            }}
            className={`p-1.5 rounded-lg text-xs font-medium transition ${
              activeTool === 'stroke'
                ? 'bg-rose-500 text-white font-bold shadow-xs'
                : 'text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
            }`}
            title="Pen Annotator"
          >
            <Pen className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setActiveTool('comment');
              setColor('#3b82f6');
            }}
            className={`p-1.5 rounded-lg text-xs font-medium transition ${
              activeTool === 'comment'
                ? 'bg-blue-500 text-white font-bold shadow-xs'
                : 'text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
            }`}
            title="Sticky Comment"
          >
            <MessageSquare className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Page Nav & Zoom */}
        <div className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-300">
          <button
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            disabled={currentPage >= pdfData.totalPages}
            onClick={() => setCurrentPage((p) => Math.min(pdfData.totalPages, p + 1))}
            className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-30"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="w-[1px] h-4 bg-zinc-300 dark:bg-zinc-700 mx-1" />

          <button
            onClick={() => setZoom((z) => Math.max(0.6, z - 0.1))}
            className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono text-[11px] w-10 text-center font-semibold">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom((z) => Math.min(2.0, z + 0.1))}
            className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main PDF Page Viewport */}
      <div className="flex-1 overflow-auto p-8 flex justify-center custom-scrollbar">
        <div
          style={{
            width: `${750 * zoom}px`,
            minHeight: `${1050 * zoom}px`,
          }}
          className="relative bg-white text-zinc-900 shadow-2xl rounded-lg p-10 select-text transition-all duration-75 border border-zinc-300"
        >
          <div className="space-y-4 text-xs font-serif leading-relaxed text-zinc-800">
            <h2 className="font-sans font-bold text-base text-zinc-900 border-b pb-2">
              CHAPTER 4: TAXATION OF CORPORATIONS & STATUTORY AUDIT
            </h2>
            <p>
              Under the Indian Income Tax Act, 1961, Section 115BAA provides an option for domestic
              companies to pay income tax at a concessional rate of 22% plus applicable surcharge (10%)
              and Health & Education Cess (4%), bringing the effective tax rate to 25.168%.
            </p>
            <p>
              To avail of this special regime, the company must not claim specified tax incentives or
              exemptions, including deduction under Section 10AA for SEZ units, additional depreciation
              under Section 32(1)(iia), or deductions under Chapter VI-A under the heading "C.—Deductions
              in respect of certain incomes" other than Section 80M.
            </p>
            <div className="p-4 bg-zinc-50 border rounded text-[11px] font-sans">
              <strong>Audit Verification Point (SA 250):</strong> The auditor must verify whether the
              option was exercised in Form 10-IC on or before the due date specified under section 139(1)
              for furnishing the first of the returns of income for any previous year.
            </div>
            <p>
              Furthermore, standard auditing procedures require reconciling the provision for taxation
              with computed tax liabilities and assessing any deferred tax assets or liabilities (IND AS 12).
            </p>
          </div>

          {pageAnnotations.map((ann) => {
            if (ann.type === 'highlight' && ann.rect) {
              return (
                <div
                  key={ann.id}
                  style={{
                    left: `${ann.rect.x * zoom}px`,
                    top: `${ann.rect.y * zoom}px`,
                    width: `${ann.rect.width * zoom}px`,
                    height: `${ann.rect.height * zoom}px`,
                    backgroundColor: ann.color,
                  }}
                  className="absolute opacity-40 rounded pointer-events-none mix-blend-multiply"
                />
              );
            }
            if (ann.type === 'comment' && ann.rect) {
              return (
                <div
                  key={ann.id}
                  style={{
                    left: `${ann.rect.x * zoom}px`,
                    top: `${ann.rect.y * zoom}px`,
                  }}
                  className="absolute group z-10 cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center shadow-lg animate-bounce">
                    <MessageSquare className="w-3.5 h-3.5" />
                  </div>
                  {ann.comment && (
                    <div className="hidden group-hover:block absolute left-8 top-0 w-64 p-2.5 rounded-xl bg-zinc-900 text-white text-xs shadow-2xl z-30 font-sans leading-normal">
                      <div className="font-bold text-blue-400 text-[10px] uppercase mb-1">
                        {ann.author || 'Annotation Note'}
                      </div>
                      {ann.comment}
                    </div>
                  )}
                </div>
              );
            }
            return null;
          })}
        </div>
      </div>
    </div>
  );
};
