﻿import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3-force';
import { Search, ZoomIn, ZoomOut, RotateCcw, Filter, Sparkles, Folder } from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';
import { generateGraphData } from '../../domain/wikilinks';
import { GraphNode, GraphLink } from '../../types';

export const GraphView: React.FC = () => {
  const { notes, folders, setActiveNoteId, setMainView } = useWorkspace();
  const svgRef = useRef<SVGSVGElement | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null);
  const [zoomLevel, setZoomLevel] = useState(1);

  // Generate graph dataset from notes
  const graphData = generateGraphData(notes);

  // Folder color map
  const folderColorMap = new Map<string, string>();
  folders.forEach((f) => folderColorMap.set(f.id, f.color || '#10b981'));

  // Filtered nodes
  const filteredNodes = graphData.nodes.filter((node) => {
    if (selectedFolderId && node.folderId !== selectedFolderId) return false;
    if (searchQuery.trim() && !node.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const nodeIds = new Set(filteredNodes.map((n) => n.id));
  const filteredLinks = graphData.links.filter((link) => {
    const sId = typeof link.source === 'object' ? (link.source as any).id : link.source;
    const tId = typeof link.target === 'object' ? (link.target as any).id : link.target;
    return nodeIds.has(sId) && nodeIds.has(tId);
  });

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;

    const width = svg.clientWidth || 800;
    const height = svg.clientHeight || 600;

    const simNodes: GraphNode[] = filteredNodes.map((d) => ({ ...d }));
    const simLinks: GraphLink[] = filteredLinks.map((d) => ({ ...d }));

    const simulation = d3
      .forceSimulation(simNodes as any)
      .force(
        'link',
        d3
          .forceLink(simLinks as any)
          .id((d: any) => d.id)
          .distance(110)
      )
      .force('charge', d3.forceManyBody().strength(-240))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collide', d3.forceCollide().radius(30));

    const g = svg.querySelector('#graph-container');
    if (!g) return;

    simulation.on('tick', () => {
      const linkElements = g.querySelectorAll('.graph-link');
      linkElements.forEach((el: any, i) => {
        const link = simLinks[i] as any;
        if (link && link.source && link.target) {
          el.setAttribute('x1', link.source.x);
          el.setAttribute('y1', link.source.y);
          el.setAttribute('x2', link.target.x);
          el.setAttribute('y2', link.target.y);
        }
      });

      const nodeElements = g.querySelectorAll('.graph-node-group');
      nodeElements.forEach((el: any, i) => {
        const node = simNodes[i];
        if (node && node.x !== undefined && node.y !== undefined) {
          el.setAttribute('transform', `translate(${node.x}, ${node.y})`);
        }
      });
    });

    return () => {
      simulation.stop();
    };
  }, [filteredNodes.length, filteredLinks.length]);

  return (
    <div className="relative w-full h-full bg-zinc-950 text-white flex flex-col overflow-hidden select-none">
      {/* Top Search & Filter Bar */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 p-2 rounded-2xl bg-zinc-900/90 border border-zinc-800 backdrop-blur-md shadow-2xl">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search graph nodes..."
            className="pl-8 pr-3 py-1.5 text-xs rounded-xl bg-zinc-800 border-none text-zinc-100 placeholder-zinc-400 outline-none w-48 focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        <select
          value={selectedFolderId || ''}
          onChange={(e) => setSelectedFolderId(e.target.value || null)}
          className="bg-zinc-800 rounded-xl px-2.5 py-1.5 text-xs font-medium text-zinc-300 outline-none border-none cursor-pointer"
        >
          <option value="">All Folders</option>
          {folders.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
      </div>

      {/* Graph Info HUD */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-3 p-2.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 backdrop-blur-md text-xs text-zinc-400 shadow-2xl">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <span>{filteredNodes.length} Notes</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
          <span>{filteredLinks.length} Connections</span>
        </div>
      </div>

      {/* Main SVG Graph */}
      <svg ref={svgRef} className="w-full h-full cursor-grab active:cursor-grabbing">
        <g id="graph-container">
          {/* Links */}
          <g className="links">
            {filteredLinks.map((link, i) => (
              <line
                key={i}
                className="graph-link"
                stroke="#3f3f46"
                strokeWidth="1.5"
                strokeOpacity="0.6"
              />
            ))}
          </g>

          {/* Nodes */}
          <g className="nodes">
            {filteredNodes.map((node) => {
              const nodeColor = node.folderId
                ? folderColorMap.get(node.folderId) || '#10b981'
                : '#10b981';

              const isMatch = searchQuery.trim() && node.title.toLowerCase().includes(searchQuery.toLowerCase());

              return (
                <g
                  key={node.id}
                  className="graph-node-group cursor-pointer transition-transform"
                  onClick={() => {
                    setActiveNoteId(node.id);
                    setMainView('note');
                  }}
                  onMouseEnter={() => setHoveredNode(node)}
                  onMouseLeave={() => setHoveredNode(null)}
                >
                  <circle
                    r={node.val || 7}
                    fill={nodeColor}
                    fillOpacity="0.9"
                    stroke={isMatch ? '#38bdf8' : '#ffffff'}
                    strokeWidth={isMatch ? 3 : 1.5}
                    className="hover:scale-125 transition-transform"
                  />
                  <text
                    dy={-12}
                    textAnchor="middle"
                    fill="#e4e4e7"
                    fontSize="11"
                    fontWeight="600"
                    className="pointer-events-none drop-shadow-md select-none"
                  >
                    {node.title}
                  </text>
                </g>
              );
            })}
          </g>
        </g>
      </svg>

      {/* Hovered Node Tooltip HUD */}
      {hoveredNode && (
        <div className="absolute bottom-6 left-6 z-30 p-3.5 rounded-2xl bg-zinc-900/95 border border-zinc-800 shadow-2xl backdrop-blur-md max-w-xs animate-in fade-in zoom-in-95">
          <h4 className="font-bold text-xs text-zinc-100 flex items-center gap-1.5 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            {hoveredNode.title}
          </h4>
          <div className="flex flex-wrap gap-1 mt-1.5">
            {hoveredNode.tags.map((t) => (
              <span
                key={t}
                className="px-2 py-0.5 rounded-full bg-zinc-800 text-[10px] text-emerald-400 font-medium"
              >
                #{t}
              </span>
            ))}
          </div>
          <p className="text-[10px] text-zinc-400 mt-2">
            Click node to jump into note document
          </p>
        </div>
      )}
    </div>
  );
};
