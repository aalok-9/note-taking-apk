﻿import React, { useState } from 'react';
import {
  CheckSquare,
  Square,
  Calendar,
  AlertCircle,
  Clock,
  ExternalLink,
  Plus,
  Filter,
  CheckCircle2,
  Trash2
} from 'lucide-react';
import { useWorkspace } from '../../hooks/useWorkspace';
import { StorageService } from '../../data/db';
import { TaskItem, Note, Block } from '../../types';
import { generateId } from '../../domain/markdown';
import { showToast } from '../common/Toast';

export const TaskPlanner: React.FC = () => {
  const { notes, setActiveNoteId, setMainView, refreshData } = useWorkspace();
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'high'>('pending');
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newTaskDueDate, setNewTaskDueDate] = useState('');
  const [isAddingTask, setIsAddingTask] = useState(false);

  // Extract all checklist tasks across all active notes
  const tasks: TaskItem[] = [];

  for (const note of notes) {
    if (note.inTrash) continue;
    for (const block of note.blocks) {
      if (block.type === 'checklist') {
        tasks.push({
          id: block.id,
          noteId: note.id,
          noteTitle: note.title || 'Untitled Note',
          text: block.content || 'Untitled task',
          checked: !!block.checked,
          dueDate: block.meta?.dueDate,
          priority: block.meta?.priority,
          completedAt: block.meta?.completedAt,
          blockId: block.id,
        });
      }
    }
  }

  const handleToggleTask = async (task: TaskItem) => {
    const note = notes.find((n) => n.id === task.noteId);
    if (!note) return;

    const newBlocks = note.blocks.map((b) => {
      if (b.id === task.blockId) {
        return {
          ...b,
          checked: !b.checked,
          meta: {
            ...b.meta,
            completedAt: !b.checked ? new Date().toISOString() : undefined,
          },
        };
      }
      return b;
    });

    await StorageService.saveNote({ ...note, blocks: newBlocks });
    await refreshData();
  };

  const handleAddNewTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    // Find first active note or create a tasks note
    let targetNote = notes.find((n) => !n.inTrash && (n.title.toLowerCase().includes('task') || n.title.toLowerCase().includes('todo')));
    if (!targetNote) {
      targetNote = notes.find((n) => !n.inTrash);
    }

    if (!targetNote) {
      targetNote = {
        id: generateId(),
        workspaceId: 'ws_ca_studies',
        title: 'Daily Tasks & Action Items',
        viewMode: 'editor',
        blocks: [],
        tags: ['Tasks'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        version: 1,
      };
    }

    const newBlock: Block = {
      id: generateId(),
      type: 'checklist',
      content: newTaskText.trim(),
      checked: false,
      meta: {
        priority: newTaskPriority,
        dueDate: newTaskDueDate || undefined,
      },
    };

    targetNote.blocks = [...targetNote.blocks, newBlock];
    await StorageService.saveNote(targetNote);
    await refreshData();

    setNewTaskText('');
    setNewTaskDueDate('');
    setIsAddingTask(false);
    showToast('Task added to checklist', 'success');
  };

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'pending') return !t.checked;
    if (filter === 'completed') return t.checked;
    if (filter === 'high') return t.priority === 'high' && !t.checked;
    return true;
  });

  const pendingCount = tasks.filter((t) => !t.checked).length;
  const completedCount = tasks.filter((t) => t.checked).length;
  const highPriorityCount = tasks.filter((t) => !t.checked && t.priority === 'high').length;

  return (
    <div className="max-w-4xl mx-auto w-full px-8 py-10 select-none">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-zinc-200 dark:border-zinc-800">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-emerald-600" />
            Task Planner & Action Items
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Aggregated checklist tasks across your notes with bidirectional status syncing
          </p>
        </div>

        <button
          onClick={() => setIsAddingTask(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold shadow-xs transition"
        >
          <Plus className="w-4 h-4" />
          Add Task
        </button>
      </div>

      {/* Quick Add Task Form */}
      {isAddingTask && (
        <form onSubmit={handleAddNewTask} className="p-4 mb-6 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3 animate-in fade-in zoom-in-95">
          <input
            type="text"
            autoFocus
            value={newTaskText}
            onChange={(e) => setNewTaskText(e.target.value)}
            placeholder="What needs to be done?..."
            className="w-full px-3 py-2 text-xs font-medium rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/40"
          />

          <div className="flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <select
                value={newTaskPriority}
                onChange={(e) => setNewTaskPriority(e.target.value as any)}
                className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 outline-none"
              >
                <option value="low">Low Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="high">High Priority 🔴</option>
              </select>

              <input
                type="date"
                value={newTaskDueDate}
                onChange={(e) => setNewTaskDueDate(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 outline-none"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsAddingTask(false)}
                className="px-3 py-1.5 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-emerald-500 text-white font-semibold hover:bg-emerald-600 transition shadow-2xs"
              >
                Save Task
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-1 p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/80 text-xs font-medium text-zinc-600 dark:text-zinc-400">
          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1.5 rounded-lg transition ${
              filter === 'pending'
                ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                : 'hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            Pending ({pendingCount})
          </button>
          <button
            onClick={() => setFilter('high')}
            className={`px-3 py-1.5 rounded-lg transition ${
              filter === 'high'
                ? 'bg-rose-500 text-white font-semibold shadow-xs'
                : 'hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            High Priority ({highPriorityCount})
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-lg transition ${
              filter === 'completed'
                ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                : 'hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            Completed ({completedCount})
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition ${
              filter === 'all'
                ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                : 'hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            All ({tasks.length})
          </button>
        </div>
      </div>

      {/* Task List */}
      {filteredTasks.length === 0 ? (
        <div className="py-16 text-center text-zinc-400 space-y-2">
          <CheckCircle2 className="w-12 h-12 mx-auto stroke-1 text-emerald-500/50" />
          <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">
            No tasks in this view
          </p>
          <p className="text-xs text-zinc-400">
            Create tasks by typing <code className="text-emerald-500 font-semibold">- [ ]</code> in any note.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                task.checked
                  ? 'bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/60 dark:border-zinc-800/60 opacity-60'
                  : 'bg-white dark:bg-zinc-900 border-zinc-200/80 dark:border-zinc-800 hover:border-emerald-500/50 shadow-xs'
              }`}
            >
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <button
                  type="button"
                  onClick={() => handleToggleTask(task)}
                  className="mt-0.5 text-zinc-400 hover:text-emerald-600 transition shrink-0"
                >
                  {task.checked ? (
                    <CheckSquare className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <Square className="w-5 h-5" />
                  )}
                </button>

                <div className="flex-1 min-w-0">
                  <p
                    className={`text-xs font-medium leading-relaxed ${
                      task.checked
                        ? 'line-through text-zinc-400 dark:text-zinc-500'
                        : 'text-zinc-800 dark:text-zinc-200'
                    }`}
                  >
                    {task.text}
                  </p>

                  <div className="flex items-center gap-2 mt-1.5 text-[10px] text-zinc-400">
                    <button
                      onClick={() => {
                        setActiveNoteId(task.noteId);
                        setMainView('note');
                      }}
                      className="hover:text-emerald-600 dark:hover:text-emerald-400 font-medium flex items-center gap-1 truncate"
                    >
                      <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                      <span className="truncate">{task.noteTitle}</span>
                    </button>

                    {task.dueDate && (
                      <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                        <Calendar className="w-2.5 h-2.5" />
                        {new Date(task.dueDate).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {task.priority && (
                <span
                  className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full shrink-0 ${
                    task.priority === 'high'
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                      : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                  }`}
                >
                  {task.priority}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
