﻿import React, { useState, useEffect } from 'react';
import { Clock, RotateCcw, FileText, Calendar, CheckCircle2 } from 'lucide-react';
import { Modal } from '../common/Modal';
import { useWorkspace } from '../../hooks/useWorkspace';
import { NoteRevision } from '../../types';
import { StorageService } from '../../data/db';
import { getAllBlockText } from '../../domain/wikilinks';
import { showToast } from '../common/Toast';

interface VersionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { activeNote, updateActiveNote } = useWorkspace();
  const [revisions, setRevisions] = useState<NoteRevision[]>([]);
  const [selectedRevision, setSelectedRevision] = useState<NoteRevision | null>(null);

  useEffect(() => {
    if (isOpen && activeNote) {
      StorageService.getRevisions(activeNote.id).then((revs) => {
        setRevisions(revs);
        if (revs.length > 0) setSelectedRevision(revs[0]);
      });
    }
  }, [isOpen, activeNote]);

  const handleRestore = async (revision: NoteRevision) => {
    if (!activeNote) return;
    if (
      window.confirm(
        `Restore note back to revision from ${new Date(revision.createdAt).toLocaleString()}?`
      )
    ) {
      await StorageService.restoreRevision(activeNote.id, revision.id);
      updateActiveNote(
        {
          title: revision.title,
          blocks: revision.blocks,
          canvasData: revision.canvasData,
          tags: revision.tags,
        },
        true
      );
      showToast('Restored version successfully', 'success');
      onClose();
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      maxWidth="3xl"
      title={
        <span className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-emerald-500" />
          Version History & Snapshots
        </span>
      }
    >
      <div className="grid grid-cols-3 gap-4 h-96 select-none">
        {/* Revision timeline list */}
        <div className="col-span-1 border-r border-zinc-200 dark:border-zinc-800 pr-3 overflow-y-auto space-y-1.5 custom-scrollbar text-xs">
          <div className="text-[10px] font-bold uppercase text-zinc-400 mb-2">
            Local Snapshots ({revisions.length})
          </div>

          {revisions.length === 0 ? (
            <p className="text-zinc-400 text-xs italic">No previous snapshots recorded yet.</p>
          ) : (
            revisions.map((rev) => {
              const isSelected = selectedRevision?.id === rev.id;
              return (
                <div
                  key={rev.id}
                  onClick={() => setSelectedRevision(rev)}
                  className={`p-2.5 rounded-xl cursor-pointer transition ${
                    isSelected
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/40 text-emerald-900 dark:text-emerald-200'
                      : 'hover:bg-zinc-100 dark:hover:bg-zinc-800/60 text-zinc-700 dark:text-zinc-300'
                  }`}
                >
                  <div className="font-semibold truncate">{rev.title || 'Untitled'}</div>
                  <div className="flex items-center gap-1 text-[10px] text-zinc-400 mt-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(rev.createdAt).toLocaleTimeString()}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Snapshot Preview Pane */}
        <div className="col-span-2 flex flex-col justify-between overflow-hidden">
          {selectedRevision ? (
            <>
              <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3">
                <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                  <h3 className="font-bold text-sm text-zinc-900 dark:text-zinc-100">
                    {selectedRevision.title}
                  </h3>
                  <span className="text-[10px] text-zinc-400">
                    {new Date(selectedRevision.createdAt).toLocaleString()}
                  </span>
                </div>

                <div className="space-y-2 text-xs text-zinc-700 dark:text-zinc-300">
                  {selectedRevision.blocks.map((b, i) => (
                    <div
                      key={i}
                      className="p-2 rounded-lg bg-zinc-50 dark:bg-zinc-800/40 font-mono text-[11px]"
                    >
                      <span className="text-emerald-600 font-bold uppercase text-[9px] block">
                        {b.type}
                      </span>
                      <p>{b.content || b.data?.text || b.data?.code || '(empty)'}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 flex justify-end">
                <button
                  type="button"
                  onClick={() => handleRestore(selectedRevision)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold shadow-xs transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Restore This Snapshot
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-zinc-400 text-xs">
              Select a snapshot to preview
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};
