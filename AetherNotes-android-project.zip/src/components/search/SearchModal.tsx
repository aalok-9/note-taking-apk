﻿import React, { useState, useEffect } from 'react';
import { Search, FileText, Tag, Folder, Calendar, ArrowRight, X } from 'lucide-react';
import { Modal } from '../common/Modal';
import { useWorkspace } from '../../hooks/useWorkspace';
import { SearchEngine, SearchFilters } from '../../services/search';
import { SearchResult } from '../../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const { notes, folders, setActiveNoteId, setMainView } = useWorkspace();
  const [query, setQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | undefined>();
  const [selectedFolder, setSelectedFolder] = useState<string | undefined>();
  const [selectedIndex, setSelectedIndex] = useState(0);

  const filters: SearchFilters = {
    query,
    tag: selectedTag,
    folderId: selectedFolder,
  };

  const results = SearchEngine.search(notes, folders, filters);
  const recentSearches = SearchEngine.getRecentSearches();

  useEffect(() => {
    setSelectedIndex(0);
  }, [query, selectedTag, selectedFolder]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, results.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + results.length) % Math.max(1, results.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (results[selectedIndex]) {
          handleSelectNote(results[selectedIndex].note.id);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, results]);

  const handleSelectNote = (noteId: string) => {
    if (query.trim()) {
      SearchEngine.addRecentSearch(query.trim());
    }
    setActiveNoteId(noteId);
    setMainView('note');
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} maxWidth="2xl" showCloseButton={false}>
      <div className="space-y-4">
        {/* Search Input */}
        <div className="relative flex items-center border-b border-zinc-200 dark:border-zinc-800 pb-3">
          <Search className="w-5 h-5 text-zinc-400 absolute left-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search notes, text, tags, tables, formulas..."
            className="w-full pl-8 pr-8 text-base bg-transparent text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 outline-none font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter tags / recent searches */}
        {!query && (
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">
              Recent Searches
            </span>
            <div className="flex flex-wrap gap-1.5">
              {recentSearches.map((term) => (
                <button
                  key={term}
                  onClick={() => setQuery(term)}
                  className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-xs text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto space-y-1.5 custom-scrollbar pr-1">
          {results.length === 0 ? (
            <div className="py-12 text-center text-zinc-400 text-xs">
              No notes matching your search query.
            </div>
          ) : (
            results.map((res, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={res.note.id}
                  onClick={() => handleSelectNote(res.note.id)}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`p-3 rounded-xl cursor-pointer transition flex items-start justify-between gap-3 ${
                    isSelected
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/40 shadow-xs'
                      : 'hover:bg-zinc-100/70 dark:hover:bg-zinc-800/40 border border-transparent'
                  }`}
                >
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className="p-2 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 shrink-0 mt-0.5">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-xs text-zinc-900 dark:text-zinc-100 truncate">
                        {res.note.title || 'Untitled Note'}
                      </h4>
                      {res.snippets.length > 0 && (
                        <p className="text-[11px] text-zinc-500 line-clamp-1 mt-0.5">
                          {res.snippets[0]}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mt-1.5 text-[10px] text-zinc-400">
                        <span>{new Date(res.note.updatedAt).toLocaleDateString()}</span>
                        {res.note.tags.map((t) => (
                          <span key={t} className="text-emerald-600 dark:text-emerald-400">
                            #{t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-zinc-400 shrink-0 my-auto" />
                </div>
              );
            })
          )}
        </div>
      </div>
    </Modal>
  );
};
