﻿import React, { useState, useEffect } from 'react';
import {
  Command,
  FileText,
  PenTool,
  Share2,
  CheckSquare,
  Trash2,
  Settings,
  Download,
  Upload,
  Sun,
  Moon,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { Modal } from '../common/Modal';
import { useWorkspace } from '../../hooks/useWorkspace';
import { useTheme } from '../../hooks/useTheme';
import { PortabilityService } from '../../services/portability';
import { showToast } from '../common/Toast';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
}

interface PaletteAction {
  id: string;
  title: string;
  category: 'Navigation' | 'Actions' | 'Templates' | 'Preferences';
  icon: React.ReactNode;
  shortcut?: string;
  run: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onOpenSettings,
}) => {
  const {
    workspace,
    folders,
    notebooks,
    notes,
    createNote,
    setMainView,
    emptyTrash,
  } = useWorkspace();

  const { settings, updateSettings } = useTheme();
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const actions: PaletteAction[] = [
    {
      id: 'new_note',
      title: 'New Document Note',
      category: 'Actions',
      icon: <FileText className="w-4 h-4 text-emerald-500" />,
      shortcut: 'Ctrl+N',
      run: () => {
        createNote({ title: 'Untitled Note', viewMode: 'editor' });
        onClose();
      },
    },
    {
      id: 'new_canvas',
      title: 'New Digital Paper Canvas',
      category: 'Actions',
      icon: <PenTool className="w-4 h-4 text-purple-500" />,
      run: () => {
        createNote({ title: 'Untitled Canvas', viewMode: 'canvas' });
        onClose();
      },
    },
    {
      id: 'open_graph',
      title: 'Open Interactive Knowledge Graph',
      category: 'Navigation',
      icon: <Share2 className="w-4 h-4 text-purple-500" />,
      run: () => {
        setMainView('graph');
        onClose();
      },
    },
    {
      id: 'open_tasks',
      title: 'Open Tasks & To-Dos Planner',
      category: 'Navigation',
      icon: <CheckSquare className="w-4 h-4 text-blue-500" />,
      run: () => {
        setMainView('tasks');
        onClose();
      },
    },
    {
      id: 'export_backup',
      title: 'Export Full Workspace Backup (.zip)',
      category: 'Actions',
      icon: <Download className="w-4 h-4 text-emerald-600" />,
      run: async () => {
        await PortabilityService.exportWorkspaceZip(workspace, folders, notebooks, notes);
        showToast('Workspace backup exported successfully', 'success');
        onClose();
      },
    },
    {
      id: 'toggle_dark',
      title: 'Toggle Dark / Light Theme',
      category: 'Preferences',
      icon: <Moon className="w-4 h-4 text-amber-400" />,
      run: () => {
        updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' });
        onClose();
      },
    },
    {
      id: 'open_settings',
      title: 'Open App Settings',
      category: 'Preferences',
      icon: <Settings className="w-4 h-4 text-zinc-400" />,
      run: () => {
        onClose();
        onOpenSettings();
      },
    },
    {
      id: 'tpl_meeting',
      title: 'Template: Meeting & Study Notes',
      category: 'Templates',
      icon: <Sparkles className="w-4 h-4 text-amber-500" />,
      run: () => {
        createNote({
          title: `Study Session — ${new Date().toLocaleDateString()}`,
          initialBlocks: [
            { id: 'h1', type: 'heading-1', content: 'Study Session Objectives' },
            { id: 'cl1', type: 'checklist', content: 'Review chapter concepts and formulas' },
            { id: 'cl2', type: 'checklist', content: 'Solve practice numerical questions' },
            { id: 'h2', type: 'heading-2', content: 'Key Takeaways & Summary' },
            { id: 'p1', type: 'paragraph', content: 'Detailed conceptual insights...' },
          ],
        });
        onClose();
      },
    },
  ];

  const filtered = actions.filter((act) =>
    act.title.toLowerCase().includes(query.toLowerCase()) ||
    act.category.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, filtered.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filtered.length) % Math.max(1, filtered.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filtered[selectedIndex]) {
          filtered[selectedIndex].run();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, filtered]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} maxWidth="xl" showCloseButton={false}>
      <div className="space-y-3">
        {/* Command Input */}
        <div className="relative flex items-center border-b border-zinc-200 dark:border-zinc-800 pb-3">
          <Command className="w-5 h-5 text-zinc-400 absolute left-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command or jump to feature..."
            className="w-full pl-8 pr-4 text-sm font-medium bg-transparent text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 outline-none"
          />
        </div>

        {/* Command Items */}
        <div className="max-h-80 overflow-y-auto space-y-0.5 custom-scrollbar pr-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-zinc-400 text-xs">No matching commands.</div>
          ) : (
            filtered.map((act, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={act.id}
                  onClick={act.run}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`p-2.5 rounded-xl cursor-pointer transition flex items-center justify-between gap-3 text-xs ${
                    isSelected
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold'
                      : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 shrink-0">
                      {act.icon}
                    </div>
                    <span>{act.title}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-zinc-400 font-normal">{act.category}</span>
                    {act.shortcut && (
                      <span className="text-[10px] bg-zinc-200/80 dark:bg-zinc-700 px-1.5 py-0.5 rounded text-zinc-600 dark:text-zinc-300 font-mono">
                        {act.shortcut}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </Modal>
  );
};
