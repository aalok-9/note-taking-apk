﻿import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  ArrowUpDown,
  MoreHorizontal,
  Check,
  Calendar,
  Hash,
  Type,
  Link,
} from 'lucide-react';
import { TableBlockData, TableColumn, TableRow } from '../../types';
import { generateId } from '../../domain/markdown';

interface NotionTableProps {
  data: TableBlockData;
  onChange: (newData: TableBlockData) => void;
  isReadOnly?: boolean;
}

export const NotionTable: React.FC<NotionTableProps> = ({
  data,
  onChange,
  isReadOnly = false,
}) => {
  const [activeColMenu, setActiveColMenu] = useState<string | null>(null);
  const [filterText, setFilterText] = useState('');
  const [sortColId, setSortColId] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const columns = data?.columns || [
    { id: 'col_1', title: 'Item', type: 'text', width: 200 },
    { id: 'col_2', title: 'Value', type: 'number', width: 140 },
  ];
  const rows = data?.rows || [
    { id: 'row_1', cells: { col_1: 'Sample Row', col_2: 100 } },
  ];

  const handleCellChange = (rowId: string, colId: string, value: any) => {
    const newRows = rows.map((r) => {
      if (r.id === rowId) {
        return {
          ...r,
          cells: {
            ...r.cells,
            [colId]: value,
          },
        };
      }
      return r;
    });
    onChange({ ...data, columns, rows: newRows });
  };

  const handleAddRow = () => {
    const newRowId = generateId();
    const newCells: Record<string, any> = {};
    columns.forEach((c) => {
      newCells[c.id] = c.type === 'checkbox' ? false : c.type === 'number' ? 0 : '';
    });
    onChange({
      ...data,
      columns,
      rows: [...rows, { id: newRowId, cells: newCells }],
    });
  };

  const handleDeleteRow = (rowId: string) => {
    onChange({
      ...data,
      columns,
      rows: rows.filter((r) => r.id !== rowId),
    });
  };

  const handleAddColumn = (type: TableColumn['type'] = 'text') => {
    const newColId = generateId();
    const newCol: TableColumn = {
      id: newColId,
      title: `Column ${columns.length + 1}`,
      type,
      width: 150,
    };
    onChange({
      ...data,
      columns: [...columns, newCol],
      rows,
    });
  };

  const handleDeleteColumn = (colId: string) => {
    if (columns.length <= 1) return;
    const newColumns = columns.filter((c) => c.id !== colId);
    const newRows = rows.map((r) => {
      const copy = { ...r.cells };
      delete copy[colId];
      return { ...r, cells: copy };
    });
    onChange({ ...data, columns: newColumns, rows: newRows });
    setActiveColMenu(null);
  };

  const handleRenameColumn = (colId: string, newTitle: string) => {
    const newCols = columns.map((c) => (c.id === colId ? { ...c, title: newTitle } : c));
    onChange({ ...data, columns: newCols, rows });
  };

  const handleColumnTypeChange = (colId: string, newType: TableColumn['type']) => {
    const newCols = columns.map((c) => (c.id === colId ? { ...c, type: newType } : c));
    onChange({ ...data, columns: newCols, rows });
    setActiveColMenu(null);
  };

  // Sorting
  const sortedRows = [...rows].sort((a, b) => {
    if (!sortColId) return 0;
    const valA = a.cells[sortColId] ?? '';
    const valB = b.cells[sortColId] ?? '';
    if (typeof valA === 'number' && typeof valB === 'number') {
      return sortDirection === 'asc' ? valA - valB : valB - valA;
    }
    return sortDirection === 'asc'
      ? String(valA).localeCompare(String(valB))
      : String(valB).localeCompare(String(valA));
  });

  // Filtering
  const displayedRows = sortedRows.filter((r) => {
    if (!filterText.trim()) return true;
    return Object.values(r.cells).some((val) =>
      String(val).toLowerCase().includes(filterText.toLowerCase())
    );
  });

  // Calculations for summary footer
  const calculateSummary = (col: TableColumn) => {
    if (col.type === 'number') {
      const sum = rows.reduce((acc, r) => acc + (Number(r.cells[col.id]) || 0), 0);
      return `Sum: ${sum.toLocaleString()}`;
    }
    if (col.type === 'checkbox') {
      const checked = rows.filter((r) => !!r.cells[col.id]).length;
      return `${checked}/${rows.length} checked`;
    }
    return `Count: ${rows.length}`;
  };

  return (
    <div className="w-full my-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-xs overflow-hidden select-text">
      {/* Table Top Controls */}
      <div className="p-2 border-b border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between gap-2 bg-zinc-50/50 dark:bg-zinc-900/40 text-xs">
        <input
          type="text"
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          placeholder="Filter table rows..."
          className="px-2.5 py-1 rounded-lg bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 placeholder-zinc-400 outline-none text-xs w-48"
        />

        {!isReadOnly && (
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => handleAddColumn('text')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-medium text-xs transition"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Column
            </button>
            <button
              type="button"
              onClick={handleAddRow}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium text-xs transition shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              New Row
            </button>
          </div>
        )}
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-left text-xs border-collapse">
          {/* Header */}
          <thead>
            <tr className="bg-zinc-50 dark:bg-zinc-800/60 border-b border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 font-semibold">
              <th className="w-8 p-2 text-center text-zinc-400">#</th>
              {columns.map((col) => (
                <th
                  key={col.id}
                  style={{ width: `${col.width || 160}px` }}
                  className="p-2 border-r border-zinc-200/60 dark:border-zinc-800 relative group"
                >
                  <div className="flex items-center justify-between gap-1">
                    <input
                      type="text"
                      value={col.title}
                      disabled={isReadOnly}
                      onChange={(e) => handleRenameColumn(col.id, e.target.value)}
                      className="bg-transparent font-semibold text-zinc-800 dark:text-zinc-200 outline-none w-full truncate focus:bg-white dark:focus:bg-zinc-800 px-1 rounded"
                    />

                    {!isReadOnly && (
                      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={() => {
                            if (sortColId === col.id) {
                              setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
                            } else {
                              setSortColId(col.id);
                              setSortDirection('asc');
                            }
                          }}
                          className="p-1 rounded hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500"
                          title="Sort"
                        >
                          <ArrowUpDown className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setActiveColMenu(activeColMenu === col.id ? null : col.id)
                          }
                          className="p-1 rounded hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500"
                        >
                          <MoreHorizontal className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Column Menu Popup */}
                  {activeColMenu === col.id && (
                    <div className="absolute left-0 top-8 z-30 w-44 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl shadow-xl p-1 text-xs space-y-0.5 animate-in fade-in zoom-in-95">
                      <div className="px-2 py-1 text-[10px] font-bold uppercase text-zinc-400">
                        Column Type
                      </div>
                      <button
                        type="button"
                        onClick={() => handleColumnTypeChange(col.id, 'text')}
                        className="w-full flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                      >
                        <Type className="w-3.5 h-3.5" /> Text
                      </button>
                      <button
                        type="button"
                        onClick={() => handleColumnTypeChange(col.id, 'number')}
                        className="w-full flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                      >
                        <Hash className="w-3.5 h-3.5" /> Number
                      </button>
                      <button
                        type="button"
                        onClick={() => handleColumnTypeChange(col.id, 'checkbox')}
                        className="w-full flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                      >
                        <Check className="w-3.5 h-3.5" /> Checkbox
                      </button>
                      <button
                        type="button"
                        onClick={() => handleColumnTypeChange(col.id, 'date')}
                        className="w-full flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                      >
                        <Calendar className="w-3.5 h-3.5" /> Date
                      </button>
                      <button
                        type="button"
                        onClick={() => handleColumnTypeChange(col.id, 'url')}
                        className="w-full flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200"
                      >
                        <Link className="w-3.5 h-3.5" /> URL Link
                      </button>
                      <div className="border-t border-zinc-100 dark:border-zinc-700 my-1" />
                      <button
                        type="button"
                        onClick={() => handleDeleteColumn(col.id)}
                        className="w-full flex items-center gap-2 px-2 py-1 rounded hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Delete Column
                      </button>
                    </div>
                  )}
                </th>
              ))}
              {!isReadOnly && <th className="w-10 p-2"></th>}
            </tr>
          </thead>

          {/* Rows */}
          <tbody>
            {displayedRows.map((row, rowIdx) => (
              <tr
                key={row.id}
                className="border-b border-zinc-100 dark:border-zinc-800/60 hover:bg-zinc-50/80 dark:hover:bg-zinc-800/30 transition group"
              >
                <td className="p-2 text-center text-zinc-400 text-[11px] font-mono">
                  {rowIdx + 1}
                </td>
                {columns.map((col) => (
                  <td
                    key={col.id}
                    className="p-2 border-r border-zinc-100 dark:border-zinc-800/60"
                  >
                    {col.type === 'checkbox' ? (
                      <div className="flex items-center justify-center">
                        <input
                          type="checkbox"
                          checked={!!row.cells[col.id]}
                          disabled={isReadOnly}
                          onChange={(e) =>
                            handleCellChange(row.id, col.id, e.target.checked)
                          }
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                        />
                      </div>
                    ) : col.type === 'number' ? (
                      <input
                        type="number"
                        value={row.cells[col.id] !== undefined ? String(row.cells[col.id]) : ''}
                        disabled={isReadOnly}
                        onChange={(e) =>
                          handleCellChange(row.id, col.id, Number(e.target.value))
                        }
                        className="w-full bg-transparent text-right font-mono text-zinc-800 dark:text-zinc-200 outline-none focus:bg-white dark:focus:bg-zinc-800 px-1 rounded"
                      />
                    ) : (
                      <input
                        type="text"
                        value={row.cells[col.id] !== undefined ? String(row.cells[col.id]) : ''}
                        disabled={isReadOnly}
                        onChange={(e) =>
                          handleCellChange(row.id, col.id, e.target.value)
                        }
                        className="w-full bg-transparent text-zinc-800 dark:text-zinc-200 outline-none focus:bg-white dark:focus:bg-zinc-800 px-1 rounded"
                      />
                    )}
                  </td>
                ))}

                {!isReadOnly && (
                  <td className="p-2 text-center">
                    <button
                      type="button"
                      onClick={() => handleDeleteRow(row.id)}
                      className="p-1 rounded text-zinc-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition"
                      title="Delete Row"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>

          {/* Footer Summary Row */}
          <tfoot>
            <tr className="bg-zinc-50 dark:bg-zinc-800/40 text-[11px] font-semibold text-zinc-500 dark:text-zinc-400">
              <td className="p-2 text-center">Σ</td>
              {columns.map((col) => (
                <td key={col.id} className="p-2 border-r border-zinc-200/60 dark:border-zinc-800 font-mono">
                  {calculateSummary(col)}
                </td>
              ))}
              {!isReadOnly && <td className="p-2"></td>}
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};
