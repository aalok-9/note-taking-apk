﻿import React, { useState } from 'react';
import { Sparkles, Folder, Tag, Plus, Check } from 'lucide-react';
import { Modal } from '../common/Modal';
import { useWorkspace } from '../../hooks/useWorkspace';
import { generateId } from '../../domain/markdown';
import { showToast } from '../common/Toast';

interface QuickCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuickCaptureModal: React.FC<QuickCaptureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { folders, createNote, setActiveNoteId, setMainView } = useWorkspace();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedFolderId, setSelectedFolderId] = useState<string | undefined>();
  const [tagInput, setTagInput] = useState('QuickCapture');

  const handleCapture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) return;

    const tags = tagInput
      .split(',')
      .map((t) => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    const blocks = [
      { id: generateId(), type: 'heading-1' as const, content: title.trim() || 'Quick Note' },
      ...content
        .split('\n')
        .filter(Boolean)
        .map((line) => ({ id: generateId(), type: 'paragraph' as const, content: line })),
    ];

    const note = await createNote({
      title: title.trim() || 'Quick Note',
      folderId: selectedFolderId,
      initialBlocks: blocks,
      tags,
    });

    setTitle('');
    setContent('');
    onClose();
    showToast('Note captured successfully', 'success');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      maxWidth="lg"
      title={
        <span className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-500" />
          Quick Capture
        </span>
      }
    >
      <form onSubmit={handleCapture} className="space-y-3 select-none">
        <div>
          <input
            type="text"
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Note title / idea..."
            className="w-full px-3 py-2 text-base font-bold rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/40 placeholder-zinc-400"
          />
        </div>

        <div>
          <textarea
            rows={4}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Jot down your thoughts, tasks, formulas..."
            className="w-full px-3 py-2 text-xs rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/40 placeholder-zinc-400 resize-none leading-relaxed"
          />
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="text-[10px] font-bold text-zinc-400 uppercase mb-1 block">
              Folder
            </label>
            <select
              value={selectedFolderId || ''}
              onChange={(e) => setSelectedFolderId(e.target.value || undefined)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 outline-none"
            >
              <option value="">No Folder (Root)</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold text-zinc-400 uppercase mb-1 block">
              Tags (comma separated)
            </label>
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              placeholder="Tag1, Tag2"
              className="w-full px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 outline-none"
            />
          </div>
        </div>

        <div className="pt-2 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-xs font-medium"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold shadow-xs transition"
          >
            Save Note
          </button>
        </div>
      </form>
    </Modal>
  );
};
