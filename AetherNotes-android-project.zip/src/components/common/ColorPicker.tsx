﻿import React from 'react';

interface ColorPickerProps {
  selectedColor: string;
  onChange: (color: string) => void;
  presetColors?: string[];
}

export const PRESET_COLORS = [
  '#0f172a', // Slate dark
  '#dc2626', // Red
  '#ea580c', // Orange
  '#d97706', // Amber
  '#16a34a', // Green
  '#059669', // Emerald
  '#0284c7', // Sky
  '#2563eb', // Blue
  '#7c3aed', // Violet
  '#db2777', // Pink
  '#ffffff', // White
  '#64748b', // Gray
];

export const ColorPicker: React.FC<ColorPickerProps> = ({
  selectedColor,
  onChange,
  presetColors = PRESET_COLORS
}) => {
  return (
    <div className="flex items-center gap-1.5 flex-wrap p-1">
      {presetColors.map(color => (
        <button
          key={color}
          type="button"
          onClick={() => onChange(color)}
          style={{ backgroundColor: color }}
          className={`w-6 h-6 rounded-full border border-zinc-300 dark:border-zinc-700 transition-transform ${
            selectedColor.toLowerCase() === color.toLowerCase()
              ? 'scale-125 ring-2 ring-emerald-500 ring-offset-2 dark:ring-offset-zinc-900'
              : 'hover:scale-110'
          }`}
        />
      ))}
      <label className="relative cursor-pointer ml-1">
        <input
          type="color"
          value={selectedColor}
          onChange={(e) => onChange(e.target.value)}
          className="sr-only"
        />
        <div
          style={{ backgroundColor: selectedColor }}
          className="w-6 h-6 rounded-full border-2 border-dashed border-zinc-400 dark:border-zinc-500 flex items-center justify-center text-xs font-bold hover:scale-110 transition"
          title="Custom Color"
        >
          +
        </div>
      </label>
    </div>
  );
};
