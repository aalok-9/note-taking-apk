﻿import React, { useState, useEffect } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

let toastHandler: ((toast: Omit<ToastMessage, 'id'>) => void) | null = null;

export const showToast = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
  if (toastHandler) {
    toastHandler({ text, type });
  }
};

export const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    toastHandler = (toast) => {
      const id = Math.random().toString(36).substring(2, 9);
      setToasts(prev => [...prev, { ...toast, id }]);
      setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== id));
      }, 3500);
    };
    return () => {
      toastHandler = null;
    };
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => (
        <div
          key={t.id}
          className={`pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg border text-sm font-medium transition-all duration-200 animate-in slide-in-from-bottom-5 ${
            t.type === 'success'
              ? 'bg-emerald-500 text-white border-emerald-600'
              : t.type === 'error'
              ? 'bg-rose-500 text-white border-rose-600'
              : 'bg-zinc-900 text-white border-zinc-800 dark:bg-zinc-100 dark:text-zinc-900'
          }`}
        >
          {t.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
          {t.type === 'error' && <AlertCircle className="w-4 h-4 shrink-0" />}
          {t.type === 'info' && <Info className="w-4 h-4 shrink-0" />}
          <span>{t.text}</span>
          <button
            onClick={() => setToasts(prev => prev.filter(item => item.id !== t.id))}
            className="ml-2 p-0.5 hover:opacity-75"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
