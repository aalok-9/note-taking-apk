﻿import React, { useState, useEffect } from 'react';
import { FileText, Plus } from 'lucide-react';
import { Note } from '../../types';

interface WikilinkAutocompleteProps {
  isOpen: boolean;
  position: { top: number; left: number };
  query: string;
  notes: Note[];
  onSelect: (noteTitle: string) => void;
  onClose: () => void;
}

export const WikilinkAutocomplete: React.FC<WikilinkAutocompleteProps> = ({
  isOpen,
  position,
  query,
  notes,
  onSelect,
  onClose,
}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);

  const cleanQuery = query.toLowerCase().trim();
  const matchingNotes = notes.filter(
    (n) => !n.inTrash && (n.title || '').toLowerCase().includes(cleanQuery)
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, matchingNotes.length + 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + matchingNotes.length + 1) % (matchingNotes.length + 1));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (selectedIndex < matchingNotes.length) {
          onSelect(matchingNotes[selectedIndex].title);
        } else if (query.trim()) {
          onSelect(query.trim());
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, matchingNotes, query, onSelect, onClose]);

  if (!isOpen) return null;

  return (
    <div
      style={{
        top: `${position.top}px`,
        left: `${Math.min(position.left, window.innerWidth - 280)}px`,
      }}
      className="fixed z-50 w-64 max-h-64 overflow-y-auto bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl shadow-2xl p-1 custom-scrollbar animate-in fade-in zoom-in-95"
    >
      <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
        Link to note
      </div>

      <div className="space-y-0.5">
        {matchingNotes.map((note, idx) => {
          const isSelected = idx === selectedIndex;
          return (
            <button
              key={note.id}
              onClick={() => onSelect(note.title)}
              onMouseEnter={() => setSelectedIndex(idx)}
              className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left text-xs transition ${
                isSelected
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold'
                  : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">{note.title || 'Untitled Note'}</span>
            </button>
          );
        })}

        {query.trim() && !matchingNotes.some((n) => n.title.toLowerCase() === cleanQuery) && (
          <button
            onClick={() => onSelect(query.trim())}
            className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left text-xs transition ${
              selectedIndex === matchingNotes.length
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-emerald-600 dark:text-emerald-400'
            }`}
          >
            <Plus className="w-3.5 h-3.5 shrink-0" />
            <span>Create "[[{query.trim()}]]"</span>
          </button>
        )}
      </div>
    </div>
  );
};
