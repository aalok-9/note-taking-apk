﻿import React, { useState, useRef, useEffect } from 'react';
import {
  GripVertical,
  Plus,
  Trash2,
  ChevronRight,
  ChevronDown,
  Copy,
  Check,
  Mic,
  Calendar,
  AlertCircle,
  Binary,
  Image as ImageIcon,
  Upload,
  ExternalLink
} from 'lucide-react';
import katex from 'katex';
import { Block, BlockType } from '../../types';
import { NotionTable } from '../tables/NotionTable';
import { AudioRecorderService } from '../../services/audioRecorder';
import { generateId } from '../../domain/markdown';

interface BlockItemProps {
  block: Block;
  index: number;
  totalBlocks: number;
  onUpdate: (updatedBlock: Block) => void;
  onDelete: () => void;
  onInsertAfter: (type?: BlockType) => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement | HTMLInputElement>, block: Block) => void;
  onTriggerSlash: (position: { top: number; left: number }) => void;
  onTriggerWikilink: (position: { top: number; left: number }, query: string) => void;
  onNavigateToNote?: (title: string) => void;
  autoFocus?: boolean;
}

export const BlockItem: React.FC<BlockItemProps> = ({
  block,
  index,
  totalBlocks,
  onUpdate,
  onDelete,
  onInsertAfter,
  onMoveUp,
  onMoveDown,
  onKeyDown,
  onTriggerSlash,
  onTriggerWikilink,
  onNavigateToNote,
  autoFocus = false,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isEditingMath, setIsEditingMath] = useState(!block.content);
  const [copiedCode, setCopiedCode] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingVolume, setRecordingVolume] = useState(0);

  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const mathRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const audioRecorderRef = useRef<AudioRecorderService | null>(null);

  // Auto-resize textarea
  const adjustHeight = (el: HTMLTextAreaElement | null) => {
    if (el) {
      el.style.height = 'auto';
      el.style.height = `${Math.max(24, el.scrollHeight)}px`;
    }
  };

  useEffect(() => {
    if (inputRef.current) {
      adjustHeight(inputRef.current);
      if (autoFocus) {
        inputRef.current.focus();
      }
    }
  }, [block.content, autoFocus]);

  // Render KaTeX for equation block
  useEffect(() => {
    if (block.type === 'equation' && mathRef.current && block.content) {
      try {
        katex.render(block.content, mathRef.current, {
          displayMode: true,
          throwOnError: false,
        });
      } catch (err) {
        if (mathRef.current) {
          mathRef.current.innerText = block.content;
        }
      }
    }
  }, [block.type, block.content]);

  // Check for slash menu '/' and wikilink '[['
  const handleContentChange = (val: string, targetEl: HTMLElement) => {
    onUpdate({ ...block, content: val });

    if (val === '/') {
      const rect = targetEl.getBoundingClientRect();
      onTriggerSlash({ top: rect.bottom + window.scrollY, left: rect.left + window.scrollX });
    } else if (val.includes('[[')) {
      const lastIndex = val.lastIndexOf('[[');
      const afterLink = val.slice(lastIndex + 2);
      if (!afterLink.includes(']]')) {
        const rect = targetEl.getBoundingClientRect();
        onTriggerWikilink(
          { top: rect.bottom + window.scrollY, left: rect.left + window.scrollX },
          afterLink
        );
      }
    }
  };

  // Image file upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        onUpdate({
          ...block,
          data: {
            url: dataUrl,
            caption: file.name,
          },
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // Audio recording handlers
  const handleStartAudioRecord = async () => {
    const recorder = new AudioRecorderService();
    audioRecorderRef.current = recorder;
    const ok = await recorder.startRecording((vol) => setRecordingVolume(vol));
    if (ok) setIsRecording(true);
  };

  const handleStopAudioRecord = async () => {
    if (!audioRecorderRef.current) return;
    const res = await audioRecorderRef.current.stopRecording();
    setIsRecording(false);
    if (res) {
      onUpdate({
        ...block,
        data: {
          url: res.url,
          duration: res.duration,
          recordedAt: new Date().toISOString(),
          title: `Voice Note (${res.duration}s)`,
        },
      });
    }
  };

  return (
    <div
      id={`block-${block.id}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setIsMenuOpen(false);
      }}
      className="group relative flex items-start gap-1 py-0.5 px-2 -mx-2 rounded-xl hover:bg-zinc-50/70 dark:hover:bg-zinc-800/30 transition-colors"
    >
      {/* Left Gutter: Drag Handle & Quick Menu */}
      <div className="flex items-center gap-0.5 pt-1 opacity-0 group-hover:opacity-100 transition-opacity select-none shrink-0 w-12 justify-end mr-1">
        <button
          type="button"
          onClick={() => onInsertAfter('paragraph')}
          className="p-1 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition"
          title="Insert Block Below (Enter)"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="p-1 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition cursor-grab"
          title="Transform or Move Block"
        >
          <GripVertical className="w-3.5 h-3.5" />
        </button>

        {/* Block Options Menu */}
        {isMenuOpen && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute left-10 top-6 z-40 w-48 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-2xl shadow-2xl p-1.5 text-xs space-y-0.5 animate-in fade-in zoom-in-95 select-none"
          >
            <div className="px-2 py-1 text-[10px] font-bold uppercase text-zinc-400">
              Transform Block
            </div>
            {(['paragraph', 'heading-1', 'heading-2', 'heading-3', 'checklist', 'bullet-list', 'toggle', 'quote', 'callout', 'code', 'table', 'equation', 'image'] as BlockType[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  onUpdate({ ...block, type: t });
                  setIsMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-700 capitalize text-left ${
                  block.type === t ? 'font-bold text-emerald-600 dark:text-emerald-400' : 'text-zinc-700 dark:text-zinc-300'
                }`}
              >
                <span>{t.replace('-', ' ')}</span>
                {block.type === t && <Check className="w-3.5 h-3.5" />}
              </button>
            ))}
            <div className="border-t border-zinc-100 dark:border-zinc-700 my-1" />
            <button
              type="button"
              onClick={() => {
                onDelete();
                setIsMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400"
            >
              <Trash2 className="w-3.5 h-3.5" /> Delete Block
            </button>
          </div>
        )}
      </div>

      {/* Main Block Content */}
      <div className="flex-1 min-w-0">
        {/* HEADING 1 */}
        {block.type === 'heading-1' && (
          <textarea
            ref={inputRef}
            rows={1}
            value={block.content}
            onChange={(e) => handleContentChange(e.target.value, e.target)}
            onKeyDown={(e) => onKeyDown(e, block)}
            placeholder="Heading 1"
            className="w-full font-bold text-2xl tracking-tight text-zinc-900 dark:text-zinc-100 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700 py-1"
          />
        )}

        {/* HEADING 2 */}
        {block.type === 'heading-2' && (
          <textarea
            ref={inputRef}
            rows={1}
            value={block.content}
            onChange={(e) => handleContentChange(e.target.value, e.target)}
            onKeyDown={(e) => onKeyDown(e, block)}
            placeholder="Heading 2"
            className="w-full font-bold text-xl tracking-tight text-zinc-900 dark:text-zinc-100 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700 py-1"
          />
        )}

        {/* HEADING 3 */}
        {block.type === 'heading-3' && (
          <textarea
            ref={inputRef}
            rows={1}
            value={block.content}
            onChange={(e) => handleContentChange(e.target.value, e.target)}
            onKeyDown={(e) => onKeyDown(e, block)}
            placeholder="Heading 3"
            className="w-full font-semibold text-base text-zinc-800 dark:text-zinc-200 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700 py-0.5"
          />
        )}

        {/* PARAGRAPH */}
        {block.type === 'paragraph' && (
          <textarea
            ref={inputRef}
            rows={1}
            value={block.content}
            onChange={(e) => handleContentChange(e.target.value, e.target)}
            onKeyDown={(e) => onKeyDown(e, block)}
            placeholder="Type '/' for commands or '[[ ' to link note..."
            className="w-full text-sm leading-relaxed text-zinc-800 dark:text-zinc-200 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700 py-0.5"
          />
        )}

        {/* CHECKLIST */}
        {block.type === 'checklist' && (
          <div className="flex items-start gap-2.5 py-0.5">
            <input
              type="checkbox"
              checked={!!block.checked}
              onChange={(e) =>
                onUpdate({
                  ...block,
                  checked: e.target.checked,
                  meta: {
                    ...block.meta,
                    completedAt: e.target.checked ? new Date().toISOString() : undefined,
                  },
                })
              }
              className="mt-1 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
            />
            <textarea
              ref={inputRef}
              rows={1}
              value={block.content}
              onChange={(e) => handleContentChange(e.target.value, e.target)}
              onKeyDown={(e) => onKeyDown(e, block)}
              placeholder="To-do task..."
              className={`flex-1 text-sm bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700 ${
                block.checked ? 'line-through text-zinc-400 dark:text-zinc-500' : 'text-zinc-800 dark:text-zinc-200'
              }`}
            />
            {block.meta?.priority && (
              <span
                className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                  block.meta.priority === 'high'
                    ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                    : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                }`}
              >
                {block.meta.priority}
              </span>
            )}
          </div>
        )}

        {/* BULLET LIST */}
        {block.type === 'bullet-list' && (
          <div className="flex items-start gap-2 py-0.5">
            <span className="text-zinc-400 font-bold select-none text-base leading-none mt-1">•</span>
            <textarea
              ref={inputRef}
              rows={1}
              value={block.content}
              onChange={(e) => handleContentChange(e.target.value, e.target)}
              onKeyDown={(e) => onKeyDown(e, block)}
              placeholder="List item..."
              className="flex-1 text-sm text-zinc-800 dark:text-zinc-200 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700"
            />
          </div>
        )}

        {/* NUMBERED LIST */}
        {block.type === 'numbered-list' && (
          <div className="flex items-start gap-2 py-0.5">
            <span className="text-zinc-400 font-medium select-none text-sm font-mono mt-0.5">
              {index + 1}.
            </span>
            <textarea
              ref={inputRef}
              rows={1}
              value={block.content}
              onChange={(e) => handleContentChange(e.target.value, e.target)}
              onKeyDown={(e) => onKeyDown(e, block)}
              placeholder="List item..."
              className="flex-1 text-sm text-zinc-800 dark:text-zinc-200 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700"
            />
          </div>
        )}

        {/* TOGGLE ACCORDION */}
        {block.type === 'toggle' && (
          <div className="py-0.5">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onUpdate({ ...block, collapsed: !block.collapsed })}
                className="p-0.5 rounded hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500 transition"
              >
                {block.collapsed ? (
                  <ChevronRight className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </button>
              <textarea
                ref={inputRef}
                rows={1}
                value={block.content}
                onChange={(e) => handleContentChange(e.target.value, e.target)}
                onKeyDown={(e) => onKeyDown(e, block)}
                placeholder="Toggle header..."
                className="flex-1 font-semibold text-sm text-zinc-800 dark:text-zinc-200 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700"
              />
            </div>

            {!block.collapsed && (
              <div className="pl-6 pt-1 border-l-2 border-zinc-200 dark:border-zinc-800 ml-2 mt-1">
                <textarea
                  rows={2}
                  value={block.data?.nestedText || ''}
                  onChange={(e) =>
                    onUpdate({
                      ...block,
                      data: { ...block.data, nestedText: e.target.value },
                    })
                  }
                  placeholder="Details hidden inside toggle..."
                  className="w-full text-xs text-zinc-600 dark:text-zinc-400 bg-transparent border-none outline-none resize-none placeholder-zinc-400"
                />
              </div>
            )}
          </div>
        )}

        {/* QUOTE */}
        {block.type === 'quote' && (
          <div className="border-l-4 border-emerald-500 pl-3 py-1 my-1 italic">
            <textarea
              ref={inputRef}
              rows={1}
              value={block.content}
              onChange={(e) => handleContentChange(e.target.value, e.target)}
              onKeyDown={(e) => onKeyDown(e, block)}
              placeholder="Quote text..."
              className="w-full text-sm text-zinc-700 dark:text-zinc-300 bg-transparent border-none outline-none resize-none placeholder-zinc-300 dark:placeholder-zinc-700"
            />
          </div>
        )}

        {/* CALLOUT BOX */}
        {block.type === 'callout' && (
          <div
            className={`p-3.5 rounded-2xl border my-2 flex items-start gap-3 transition ${
              block.data?.type === 'warning'
                ? 'bg-amber-50/80 border-amber-200 dark:bg-amber-950/30 dark:border-amber-900/60'
                : block.data?.type === 'tip'
                ? 'bg-emerald-50/80 border-emerald-200 dark:bg-emerald-950/30 dark:border-emerald-900/60'
                : block.data?.type === 'success'
                ? 'bg-teal-50/80 border-teal-200 dark:bg-teal-950/30 dark:border-teal-900/60'
                : 'bg-zinc-100/80 border-zinc-200 dark:bg-zinc-900/80 dark:border-zinc-800'
            }`}
          >
            <span className="text-xl select-none shrink-0">{block.data?.icon || '💡'}</span>
            <div className="flex-1">
              <textarea
                ref={inputRef}
                rows={2}
                value={block.data?.text || block.content}
                onChange={(e) =>
                  onUpdate({
                    ...block,
                    content: '',
                    data: { ...block.data, text: e.target.value },
                  })
                }
                onKeyDown={(e) => onKeyDown(e, block)}
                placeholder="Callout description..."
                className="w-full text-xs leading-relaxed text-zinc-800 dark:text-zinc-200 bg-transparent border-none outline-none resize-none placeholder-zinc-400"
              />
            </div>
          </div>
        )}

        {/* CODE BLOCK */}
        {block.type === 'code' && (
          <div className="rounded-2xl bg-zinc-900 text-zinc-100 p-3.5 my-2 font-mono text-xs shadow-md border border-zinc-800">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800 text-[11px] text-zinc-400">
              <select
                value={block.data?.language || 'javascript'}
                onChange={(e) =>
                  onUpdate({
                    ...block,
                    data: { ...block.data, language: e.target.value },
                  })
                }
                className="bg-zinc-800 rounded-lg px-2.5 py-1 text-zinc-300 outline-none border-none cursor-pointer"
              >
                <option value="javascript">JavaScript</option>
                <option value="typescript">TypeScript</option>
                <option value="python">Python</option>
                <option value="sql">SQL</option>
                <option value="json">JSON</option>
                <option value="html">HTML</option>
                <option value="css">CSS</option>
                <option value="rust">Rust</option>
              </select>

              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(block.data?.code || block.content);
                  setCopiedCode(true);
                  setTimeout(() => setCopiedCode(false), 2000);
                }}
                className="flex items-center gap-1 hover:text-white transition px-2 py-0.5 rounded hover:bg-zinc-800"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <textarea
              ref={inputRef}
              rows={4}
              value={block.data?.code ?? block.content}
              onChange={(e) =>
                onUpdate({
                  ...block,
                  data: { ...block.data, code: e.target.value },
                })
              }
              onKeyDown={(e) => onKeyDown(e, block)}
              placeholder="Paste or write code here..."
              className="w-full bg-transparent text-zinc-200 outline-none resize-none font-mono text-xs leading-relaxed"
            />
          </div>
        )}

        {/* MATH EQUATION */}
        {block.type === 'equation' && (
          <div className="my-2 p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-center">
            {isEditingMath ? (
              <div className="space-y-2">
                <input
                  type="text"
                  value={block.content}
                  autoFocus
                  onChange={(e) => onUpdate({ ...block, content: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') setIsEditingMath(false);
                  }}
                  onBlur={() => setIsEditingMath(false)}
                  placeholder="LaTeX equation e.g. \\sum_{i=1}^n x_i"
                  className="w-full px-3 py-2 text-center text-xs font-mono rounded-xl bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 outline-none"
                />
                <span className="text-[10px] text-zinc-400 block">Press Enter to render KaTeX</span>
              </div>
            ) : (
              <div
                onClick={() => setIsEditingMath(true)}
                className="cursor-pointer hover:opacity-80 py-2"
                title="Click to edit LaTeX formula"
              >
                <div ref={mathRef} className="text-base overflow-x-auto custom-scrollbar" />
              </div>
            )}
          </div>
        )}

        {/* IMAGE BLOCK */}
        {block.type === 'image' && (
          <div className="my-3 p-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50">
            {block.data?.url ? (
              <div className="space-y-2">
                <img
                  src={block.data.url}
                  alt={block.data.caption || 'Embedded Image'}
                  className="max-h-96 rounded-xl mx-auto object-contain shadow-md"
                />
                <input
                  type="text"
                  value={block.data.caption || ''}
                  onChange={(e) =>
                    onUpdate({
                      ...block,
                      data: { ...block.data, caption: e.target.value },
                    })
                  }
                  placeholder="Add image caption..."
                  className="w-full text-center text-xs text-zinc-400 bg-transparent outline-none border-none"
                />
              </div>
            ) : (
              <div className="text-center py-6">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-semibold transition"
                >
                  <Upload className="w-4 h-4" /> Upload Image
                </button>
              </div>
            )}
          </div>
        )}

        {/* AUDIO NOTE */}
        {block.type === 'audio' && (
          <div className="my-2 p-3.5 rounded-2xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-xs">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-xs text-zinc-800 dark:text-zinc-200">
                  {block.data?.title || 'Voice Note'}
                </p>
                <p className="text-[10px] text-zinc-400">
                  {block.data?.duration ? `${block.data.duration}s recording` : 'Audio Clip'}
                </p>
              </div>
            </div>

            {block.data?.url ? (
              <audio controls src={block.data.url} className="h-8 max-w-[240px]" />
            ) : isRecording ? (
              <div className="flex items-center gap-2">
                <div className="w-20 h-2 bg-zinc-200 dark:bg-zinc-700 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${recordingVolume}%` }}
                    className="h-full bg-rose-500 transition-all duration-75"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleStopAudioRecord}
                  className="px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700 transition"
                >
                  Stop Recording
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleStartAudioRecord}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-500 text-white text-xs font-semibold hover:bg-rose-600 transition shadow-2xs"
              >
                <Mic className="w-4 h-4" /> Start Recording
              </button>
            )}
          </div>
        )}

        {/* DATABASE TABLE */}
        {block.type === 'table' && (
          <NotionTable
            data={block.data}
            onChange={(newData) => onUpdate({ ...block, data: newData })}
          />
        )}

        {/* DIVIDER */}
        {block.type === 'divider' && (
          <div className="py-3">
            <hr className="border-t border-zinc-200 dark:border-zinc-800" />
          </div>
        )}
      </div>
    </div>
  );
};
