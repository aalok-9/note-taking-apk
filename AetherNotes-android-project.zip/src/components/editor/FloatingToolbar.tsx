﻿import React from 'react';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Code,
  Link,
  Highlighter,
  Binary
} from 'lucide-react';

interface FloatingToolbarProps {
  isVisible: boolean;
  position: { top: number; left: number };
  onFormat: (wrapper: string, closingWrapper?: string) => void;
  onLink: () => void;
}

export const FloatingToolbar: React.FC<FloatingToolbarProps> = ({
  isVisible,
  position,
  onFormat,
  onLink,
}) => {
  if (!isVisible) return null;

  return (
    <div
      style={{
        top: `${position.top - 44}px`,
        left: `${Math.max(10, Math.min(position.left - 100, window.innerWidth - 300))}px`,
      }}
      className="fixed z-50 flex items-center gap-0.5 bg-zinc-900 text-white rounded-xl shadow-2xl p-1 border border-zinc-700 select-none animate-in fade-in zoom-in-95"
    >
      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('**', '**');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
        title="Bold (Ctrl+B)"
      >
        <Bold className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('*', '*');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
        title="Italic (Ctrl+I)"
      >
        <Italic className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('<u>', '</u>');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
        title="Underline (Ctrl+U)"
      >
        <Underline className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('~~', '~~');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
        title="Strikethrough"
      >
        <Strikethrough className="w-3.5 h-3.5" />
      </button>

      <div className="w-[1px] h-4 bg-zinc-700 my-auto mx-0.5" />

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('`', '`');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
        title="Inline Code"
      >
        <Code className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('$', '$');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition"
        title="Math Equation"
      >
        <Binary className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onFormat('<mark>', '</mark>');
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-amber-400 hover:text-amber-300 transition"
        title="Highlight"
      >
        <Highlighter className="w-3.5 h-3.5" />
      </button>

      <div className="w-[1px] h-4 bg-zinc-700 my-auto mx-0.5" />

      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onLink();
        }}
        className="p-1.5 rounded-lg hover:bg-zinc-800 text-blue-400 hover:text-blue-300 transition"
        title="Wikilink [[Note]] (Ctrl+K)"
      >
        <Link className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
