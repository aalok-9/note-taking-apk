﻿import React, { useState, useEffect } from 'react';
import { Smile, Image as ImageIcon, Plus, Maximize2, Minimize2 } from 'lucide-react';
import { Note, Block, BlockType } from '../../types';
import { BlockItem } from './BlockItem';
import { SlashMenu } from './SlashMenu';
import { WikilinkAutocomplete } from './WikilinkAutocomplete';
import { FloatingToolbar } from './FloatingToolbar';
import { generateId } from '../../domain/markdown';

interface BlockEditorProps {
  note: Note;
  allNotes: Note[];
  onUpdate: (fields: Partial<Note>, immediate?: boolean) => void;
  onNavigateToNote?: (noteId: string) => void;
}

const EMOJI_PRESETS = ['📝', '📚', '💡', '⚖️', '📊', '🔍', '📈', '🎯', '📑', '🔬', '🛡️', '⚡', '✨'];

export const BlockEditor: React.FC<BlockEditorProps> = ({
  note,
  allNotes,
  onUpdate,
  onNavigateToNote,
}) => {
  const [focusedBlockIndex, setFocusedBlockIndex] = useState<number | null>(null);
  const [isEmojiPickerOpen, setIsEmojiPickerOpen] = useState(false);
  const [isFullWidth, setIsFullWidth] = useState(false);

  const [slashMenuState, setSlashMenuState] = useState<{
    isOpen: boolean;
    position: { top: number; left: number };
    blockIndex: number;
  }>({
    isOpen: false,
    position: { top: 0, left: 0 },
    blockIndex: 0,
  });

  const [wikilinkState, setWikilinkState] = useState<{
    isOpen: boolean;
    position: { top: number; left: number };
    blockIndex: number;
    query: string;
  }>({
    isOpen: false,
    position: { top: 0, left: 0 },
    blockIndex: 0,
    query: '',
  });

  const [selectionState, setSelectionState] = useState<{
    isVisible: boolean;
    position: { top: number; left: number };
    blockIndex: number;
  }>({
    isVisible: false,
    position: { top: 0, left: 0 },
    blockIndex: 0,
  });

  // Text selection for floating toolbar
  useEffect(() => {
    const handleSelectionChange = () => {
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed && selection.toString().trim()) {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          setSelectionState({
            isVisible: true,
            position: { top: rect.top + window.scrollY, left: rect.left + rect.width / 2 + window.scrollX },
            blockIndex: 0,
          });
          return;
        }
      }
      setSelectionState((prev) => (prev.isVisible ? { ...prev, isVisible: false } : prev));
    };

    document.addEventListener('selectionchange', handleSelectionChange);
    return () => document.removeEventListener('selectionchange', handleSelectionChange);
  }, []);

  const blocks: Block[] = note.blocks && note.blocks.length > 0
    ? note.blocks
    : [{ id: generateId(), type: 'paragraph' as BlockType, content: '' }];

  const handleUpdateBlock = (index: number, updatedBlock: Block) => {
    const newBlocks = [...blocks];
    newBlocks[index] = updatedBlock;
    onUpdate({ blocks: newBlocks });
  };

  const handleDeleteBlock = (index: number) => {
    if (blocks.length <= 1) {
      onUpdate({ blocks: [{ id: generateId(), type: 'paragraph' as BlockType, content: '' }] });
      return;
    }
    const newBlocks = blocks.filter((_, i) => i !== index);
    onUpdate({ blocks: newBlocks });
    setFocusedBlockIndex(Math.max(0, index - 1));
  };

  const handleInsertAfter = (index: number, type: BlockType = 'paragraph') => {
    const newBlock: Block = {
      id: generateId(),
      type,
      content: '',
      data: type === 'table' ? {
        columns: [
          { id: 'c1', title: 'Item', type: 'text', width: 180 },
          { id: 'c2', title: 'Value', type: 'number', width: 140 },
        ],
        rows: [{ id: 'r1', cells: { c1: 'Sample Row', c2: 100 } }],
        summaryType: 'count',
      } : undefined,
    };
    const newBlocks = [...blocks];
    newBlocks.splice(index + 1, 0, newBlock);
    onUpdate({ blocks: newBlocks });
    setFocusedBlockIndex(index + 1);
  };

  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const newBlocks = [...blocks];
    const [moved] = newBlocks.splice(index, 1);
    newBlocks.splice(index - 1, 0, moved);
    onUpdate({ blocks: newBlocks });
    setFocusedBlockIndex(index - 1);
  };

  const handleMoveDown = (index: number) => {
    if (index >= blocks.length - 1) return;
    const newBlocks = [...blocks];
    const [moved] = newBlocks.splice(index, 1);
    newBlocks.splice(index + 1, 0, moved);
    onUpdate({ blocks: newBlocks });
    setFocusedBlockIndex(index + 1);
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLTextAreaElement | HTMLInputElement>,
    block: Block,
    index: number
  ) => {
    // Enter key: insert new block
    if (e.key === 'Enter' && !e.shiftKey && block.type !== 'code') {
      e.preventDefault();
      handleInsertAfter(index, block.type === 'checklist' ? 'checklist' : 'paragraph');
    }
    // Backspace on empty block: delete and focus previous
    else if (e.key === 'Backspace' && !block.content && blocks.length > 1) {
      e.preventDefault();
      handleDeleteBlock(index);
    }
    // Arrow Up at top of block
    else if (e.key === 'ArrowUp' && index > 0) {
      const target = e.currentTarget as HTMLTextAreaElement;
      if (target.selectionStart === 0 && target.selectionEnd === 0) {
        setFocusedBlockIndex(index - 1);
      }
    }
    // Arrow Down at bottom of block
    else if (e.key === 'ArrowDown' && index < blocks.length - 1) {
      const target = e.currentTarget as HTMLTextAreaElement;
      if (target.selectionStart === target.value.length) {
        setFocusedBlockIndex(index + 1);
      }
    }
  };

  const handleSlashSelect = (type: BlockType) => {
    const idx = slashMenuState.blockIndex;
    const currentBlock = blocks[idx];
    const updatedBlock: Block = {
      ...currentBlock,
      type,
      content: currentBlock.content === '/' ? '' : currentBlock.content.replace('/', ''),
      data: type === 'table' ? {
        columns: [
          { id: 'c1', title: 'Column 1', type: 'text', width: 180 },
          { id: 'c2', title: 'Column 2', type: 'number', width: 140 },
        ],
        rows: [{ id: 'r1', cells: { c1: 'Row 1', c2: 50 } }],
      } : type === 'callout' ? {
        icon: '💡',
        type: 'tip',
        text: 'Callout note text...',
      } : undefined,
    };
    handleUpdateBlock(idx, updatedBlock);
    setSlashMenuState((prev) => ({ ...prev, isOpen: false }));
    setFocusedBlockIndex(idx);
  };

  const handleWikilinkSelect = (noteTitle: string) => {
    const idx = wikilinkState.blockIndex;
    const currentBlock = blocks[idx];
    const lastIndex = currentBlock.content.lastIndexOf('[[');
    const newContent = currentBlock.content.slice(0, lastIndex) + `[[${noteTitle}]] `;
    handleUpdateBlock(idx, { ...currentBlock, content: newContent });
    setWikilinkState((prev) => ({ ...prev, isOpen: false }));
    setFocusedBlockIndex(idx);
  };

  const handleFormatText = (prefix: string, suffix: string = prefix) => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const selectedText = selection.toString();
    if (!selectedText) return;

    const activeEl = document.activeElement as HTMLTextAreaElement;
    if (activeEl && activeEl.tagName === 'TEXTAREA') {
      const start = activeEl.selectionStart;
      const end = activeEl.selectionEnd;
      const val = activeEl.value;
      const replacement = `${prefix}${selectedText}${suffix}`;
      activeEl.value = val.substring(0, start) + replacement + val.substring(end);
      activeEl.dispatchEvent(new Event('input', { bubbles: true }));
    }
  };

  const handleNavigateWikilink = (targetTitle: string) => {
    const matched = allNotes.find(
      (n) => n.title.toLowerCase() === targetTitle.toLowerCase() && !n.inTrash
    );
    if (matched && onNavigateToNote) {
      onNavigateToNote(matched.id);
    }
  };

  return (
    <div className={`mx-auto w-full px-8 py-10 select-text transition-all duration-200 ${isFullWidth ? 'max-w-6xl' : 'max-w-4xl'}`}>
      {/* Note Header & Title Area */}
      <div className="mb-8 space-y-4">
        {/* Emoji & Cover Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsEmojiPickerOpen(!isEmojiPickerOpen)}
              className="text-3xl p-1.5 rounded-2xl hover:bg-zinc-100 dark:hover:bg-zinc-800 transition"
              title="Change Icon"
            >
              {note.icon || '📝'}
            </button>

            {isEmojiPickerOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute z-30 p-2 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-2xl shadow-2xl flex gap-1.5 animate-in fade-in zoom-in-95"
              >
                {EMOJI_PRESETS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => {
                      onUpdate({ icon: emoji });
                      setIsEmojiPickerOpen(false);
                    }}
                    className="p-1 text-xl hover:scale-125 transition"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => setIsFullWidth(!isFullWidth)}
            className="p-1.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition"
            title={isFullWidth ? 'Standard Width' : 'Full Width'}
          >
            {isFullWidth ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>

        {/* Note Title */}
        <input
          type="text"
          value={note.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          placeholder="Untitled Note"
          className="w-full text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-900 dark:text-zinc-100 bg-transparent border-none outline-none placeholder-zinc-300 dark:placeholder-zinc-700"
        />

        {/* Tags row */}
        {note.tags && note.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {note.tags.map((t) => (
              <span
                key={t}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/50 dark:border-emerald-900/40"
              >
                #{t}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Blocks List */}
      <div className="space-y-1">
        {blocks.map((block, index) => (
          <BlockItem
            key={block.id}
            block={block}
            index={index}
            totalBlocks={blocks.length}
            autoFocus={focusedBlockIndex === index}
            onUpdate={(updated) => handleUpdateBlock(index, updated)}
            onDelete={() => handleDeleteBlock(index)}
            onInsertAfter={(type) => handleInsertAfter(index, type)}
            onMoveUp={() => handleMoveUp(index)}
            onMoveDown={() => handleMoveDown(index)}
            onKeyDown={(e, b) => handleKeyDown(e, b, index)}
            onTriggerSlash={(pos) =>
              setSlashMenuState({ isOpen: true, position: pos, blockIndex: index })
            }
            onTriggerWikilink={(pos, query) =>
              setWikilinkState({ isOpen: true, position: pos, blockIndex: index, query })
            }
            onNavigateToNote={handleNavigateWikilink}
          />
        ))}
      </div>

      {/* Bottom Click-to-Add-Block Area */}
      <div
        onClick={() => handleInsertAfter(blocks.length - 1)}
        className="h-32 mt-6 cursor-text flex items-center justify-center text-xs text-zinc-300 dark:text-zinc-700 hover:text-zinc-400 dark:hover:text-zinc-600 transition-colors"
      >
        <span className="flex items-center gap-1">
          <Plus className="w-3.5 h-3.5" /> Click anywhere to continue writing or press Enter...
        </span>
      </div>

      {/* Slash Menu */}
      <SlashMenu
        isOpen={slashMenuState.isOpen}
        position={slashMenuState.position}
        onSelect={handleSlashSelect}
        onClose={() => setSlashMenuState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Wikilink Autocomplete */}
      <WikilinkAutocomplete
        isOpen={wikilinkState.isOpen}
        position={wikilinkState.position}
        query={wikilinkState.query}
        notes={allNotes}
        onSelect={handleWikilinkSelect}
        onClose={() => setWikilinkState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Floating Rich-Text Toolbar */}
      <FloatingToolbar
        isVisible={selectionState.isVisible}
        position={selectionState.position}
        onFormat={handleFormatText}
        onLink={() => handleFormatText('[[', ']]')}
      />
    </div>
  );
};
