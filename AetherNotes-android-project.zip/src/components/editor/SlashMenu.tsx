﻿import React, { useState, useEffect } from 'react';
import {
  Heading1,
  Heading2,
  Heading3,
  Type,
  List,
  ListOrdered,
  CheckSquare,
  ChevronRightSquare,
  Quote,
  AlertCircle,
  Code,
  Table,
  Minus,
  Binary,
  Mic,
  Bookmark
} from 'lucide-react';
import { BlockType } from '../../types';

interface SlashMenuProps {
  isOpen: boolean;
  position: { top: number; left: number };
  onSelect: (type: BlockType) => void;
  onClose: () => void;
}

interface CommandItem {
  type: BlockType;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: 'Basic' | 'Lists' | 'Advanced' | 'Media';
}

const COMMANDS: CommandItem[] = [
  {
    type: 'paragraph',
    title: 'Text',
    description: 'Plain text with rich formatting',
    icon: <Type className="w-4 h-4 text-zinc-500" />,
    category: 'Basic'
  },
  {
    type: 'heading-1',
    title: 'Heading 1',
    description: 'Large primary section heading',
    icon: <Heading1 className="w-4 h-4 text-blue-500" />,
    category: 'Basic'
  },
  {
    type: 'heading-2',
    title: 'Heading 2',
    description: 'Medium subsection heading',
    icon: <Heading2 className="w-4 h-4 text-emerald-500" />,
    category: 'Basic'
  },
  {
    type: 'heading-3',
    title: 'Heading 3',
    description: 'Small subsection heading',
    icon: <Heading3 className="w-4 h-4 text-amber-500" />,
    category: 'Basic'
  },
  {
    type: 'checklist',
    title: 'To-do / Checklist',
    description: 'Track tasks with interactive checkboxes',
    icon: <CheckSquare className="w-4 h-4 text-emerald-600" />,
    category: 'Lists'
  },
  {
    type: 'bullet-list',
    title: 'Bulleted List',
    description: 'Create a bulleted list',
    icon: <List className="w-4 h-4 text-zinc-500" />,
    category: 'Lists'
  },
  {
    type: 'numbered-list',
    title: 'Numbered List',
    description: 'Create an ordered sequence',
    icon: <ListOrdered className="w-4 h-4 text-zinc-500" />,
    category: 'Lists'
  },
  {
    type: 'toggle',
    title: 'Toggle List',
    description: 'Collapsible accordion block',
    icon: <ChevronRightSquare className="w-4 h-4 text-purple-500" />,
    category: 'Lists'
  },
  {
    type: 'quote',
    title: 'Quote',
    description: 'Capture a quote or citation',
    icon: <Quote className="w-4 h-4 text-zinc-400" />,
    category: 'Advanced'
  },
  {
    type: 'callout',
    title: 'Callout Box',
    description: 'Highlight key insights and warnings',
    icon: <AlertCircle className="w-4 h-4 text-amber-500" />,
    category: 'Advanced'
  },
  {
    type: 'code',
    title: 'Code Block',
    description: 'Code snippet with syntax highlighting',
    icon: <Code className="w-4 h-4 text-indigo-500" />,
    category: 'Advanced'
  },
  {
    type: 'table',
    title: 'Database Table',
    description: 'Interactive table with formulas & types',
    icon: <Table className="w-4 h-4 text-teal-500" />,
    category: 'Advanced'
  },
  {
    type: 'equation',
    title: 'Math Equation',
    description: 'LaTeX mathematical expression',
    icon: <Binary className="w-4 h-4 text-purple-600" />,
    category: 'Advanced'
  },
  {
    type: 'audio',
    title: 'Audio Note',
    description: 'Record voice note directly into document',
    icon: <Mic className="w-4 h-4 text-rose-500" />,
    category: 'Media'
  },
  {
    type: 'divider',
    title: 'Divider',
    description: 'Visually separate content sections',
    icon: <Minus className="w-4 h-4 text-zinc-400" />,
    category: 'Basic'
  }
];

export const SlashMenu: React.FC<SlashMenuProps> = ({
  isOpen,
  position,
  onSelect,
  onClose,
}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [filterQuery, setFilterQuery] = useState('');

  const filteredCommands = COMMANDS.filter((cmd) =>
    cmd.title.toLowerCase().includes(filterQuery.toLowerCase()) ||
    cmd.description.toLowerCase().includes(filterQuery.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [filterQuery]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredCommands.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % Math.max(1, filteredCommands.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filteredCommands[selectedIndex]) {
          onSelect(filteredCommands[selectedIndex].type);
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, filteredCommands, onSelect, onClose]);

  if (!isOpen) return null;

  return (
    <div
      style={{
        top: `${position.top}px`,
        left: `${Math.min(position.left, window.innerWidth - 320)}px`,
      }}
      className="fixed z-50 w-72 max-h-80 overflow-y-auto bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl p-1.5 custom-scrollbar animate-in fade-in zoom-in-95"
    >
      <div className="px-2.5 py-1.5 border-b border-zinc-100 dark:border-zinc-800 mb-1">
        <input
          type="text"
          autoFocus
          value={filterQuery}
          onChange={(e) => setFilterQuery(e.target.value)}
          placeholder="Filter block types..."
          className="w-full text-xs bg-transparent border-none outline-none text-zinc-900 dark:text-zinc-100 placeholder-zinc-400"
        />
      </div>

      {filteredCommands.length === 0 ? (
        <div className="p-3 text-center text-xs text-zinc-400">No matching blocks</div>
      ) : (
        <div className="space-y-0.5">
          {filteredCommands.map((cmd, idx) => {
            const isSelected = idx === selectedIndex;
            return (
              <button
                key={cmd.type}
                onClick={() => onSelect(cmd.type)}
                onMouseEnter={() => setSelectedIndex(idx)}
                className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-xl text-left transition ${
                  isSelected
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200'
                    : 'hover:bg-zinc-100 dark:hover:bg-zinc-800/60 text-zinc-800 dark:text-zinc-200'
                }`}
              >
                <div className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 shrink-0">
                  {cmd.icon}
                </div>
                <div className="truncate flex-1">
                  <div className="text-xs font-semibold">{cmd.title}</div>
                  <div className="text-[10px] text-zinc-400 truncate">{cmd.description}</div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
