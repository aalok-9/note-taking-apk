﻿import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Note,
  CanvasData,
  CanvasStroke,
  CanvasShape,
  CanvasTool,
  PaperTemplateType,
  PaperTint,
  Point,
  CanvasText
} from '../../types';
import { CanvasToolbar } from './CanvasToolbar';
import { PaperBackground } from './PaperBackground';
import { generateId } from '../../domain/markdown';
import { showToast } from '../common/Toast';

interface DigitalPaperProps {
  note: Note;
  onUpdate: (fields: Partial<Note>, immediate?: boolean) => void;
}

export const DigitalPaper: React.FC<DigitalPaperProps> = ({
  note,
  onUpdate,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const canvasData: CanvasData = note.canvasData || {
    strokes: [],
    shapes: [],
    texts: [],
    images: [],
    paperConfig: {
      template: 'ruled',
      tint: 'light',
      lineSpacing: 28,
      gridSize: 24,
      showMargin: true,
      orientation: 'portrait',
    },
    viewport: { zoom: 1, panX: 0, panY: 0 },
  };

  const [tool, setTool] = useState<CanvasTool>('pen');
  const [color, setColor] = useState<string>('#0f172a');
  const [strokeWidth, setStrokeWidth] = useState<number>(3);
  const [template, setTemplate] = useState<PaperTemplateType>(canvasData.paperConfig.template);
  const [tint, setTint] = useState<PaperTint>(canvasData.paperConfig.tint);
  const [zoom, setZoom] = useState<number>(canvasData.viewport?.zoom || 1);

  // Drawing and interaction state
  const isDrawingRef = useRef(false);
  const currentPointsRef = useRef<Point[]>([]);
  const startShapePointRef = useRef<Point | null>(null);
  const [history, setHistory] = useState<CanvasStroke[][]>([]);
  const [selectedStrokeIds, setSelectedStrokeIds] = useState<string[]>([]);
  const [textInputPos, setTextInputPos] = useState<{ x: number; y: number } | null>(null);
  const [textInputValue, setTextInputValue] = useState('');

  const CANVAS_WIDTH = 1800;
  const CANVAS_HEIGHT = 2400;

  // Redraw all strokes on canvas with high-DPI scaling
  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.scale(dpr, dpr);

    // 1. Draw Highlighters first (multiply blend)
    for (const stroke of canvasData.strokes.filter((s) => s.isHighlighter)) {
      drawStroke(ctx, stroke, selectedStrokeIds.includes(stroke.id));
    }

    // 2. Draw Shapes
    for (const shape of canvasData.shapes) {
      drawShape(ctx, shape);
    }

    // 3. Draw Pen / Pencil Strokes
    for (const stroke of canvasData.strokes.filter((s) => !s.isHighlighter)) {
      drawStroke(ctx, stroke, selectedStrokeIds.includes(stroke.id));
    }

    // 4. Draw Text elements
    for (const text of canvasData.texts) {
      ctx.fillStyle = text.color;
      ctx.font = `${text.fontSize}px ${text.fontFamily || 'Inter'}`;
      ctx.fillText(text.text, text.x, text.y);
    }

    ctx.restore();
  }, [canvasData, selectedStrokeIds]);

  // Handle canvas sizing with high-DPI
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = CANVAS_WIDTH * dpr;
    canvas.height = CANVAS_HEIGHT * dpr;
    redraw();
  }, [redraw]);

  // Pointer event handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;
    const pressure = e.pressure || 0.5;

    isDrawingRef.current = true;

    if (tool === 'text') {
      setTextInputPos({ x, y });
      setTextInputValue('');
      isDrawingRef.current = false;
      return;
    }

    if (tool === 'eraser-stroke') {
      const filtered = canvasData.strokes.filter((s) => !isPointNearStroke({ x, y }, s, 15));
      if (filtered.length !== canvasData.strokes.length) {
        onUpdate({
          canvasData: {
            ...canvasData,
            strokes: filtered,
          },
        });
      }
      return;
    }

    if (tool === 'lasso') {
      currentPointsRef.current = [{ x, y }];
      return;
    }

    if (tool.startsWith('shape-')) {
      startShapePointRef.current = { x, y };
      return;
    }

    if (tool === 'pen' || tool === 'highlighter' || tool === 'pencil') {
      currentPointsRef.current = [{ x, y, pressure }];
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;
    const pressure = e.pressure || 0.5;

    if (tool === 'eraser-stroke') {
      const filtered = canvasData.strokes.filter((s) => !isPointNearStroke({ x, y }, s, 15));
      if (filtered.length !== canvasData.strokes.length) {
        onUpdate({
          canvasData: {
            ...canvasData,
            strokes: filtered,
          },
        });
      }
      return;
    }

    if (tool === 'lasso') {
      currentPointsRef.current.push({ x, y });
      // Draw lasso boundary feedback
      redraw();
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const dpr = window.devicePixelRatio || 1;
        ctx.save();
        ctx.scale(dpr, dpr);
        ctx.strokeStyle = '#6366f1';
        ctx.setLineDash([5, 5]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(currentPointsRef.current[0].x, currentPointsRef.current[0].y);
        for (let i = 1; i < currentPointsRef.current.length; i++) {
          ctx.lineTo(currentPointsRef.current[i].x, currentPointsRef.current[i].y);
        }
        ctx.stroke();
        ctx.restore();
      }
      return;
    }

    if (tool === 'pen' || tool === 'highlighter' || tool === 'pencil') {
      currentPointsRef.current.push({ x, y, pressure });
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const dpr = window.devicePixelRatio || 1;
        const tempStroke: CanvasStroke = {
          id: 'temp',
          tool,
          points: currentPointsRef.current,
          color,
          width: strokeWidth,
          opacity: tool === 'highlighter' ? 0.35 : 1,
          isHighlighter: tool === 'highlighter',
        };
        redraw();
        ctx.save();
        ctx.scale(dpr, dpr);
        drawStroke(ctx, tempStroke, false);
        ctx.restore();
      }
    }
  };

  const handlePointerUp = () => {
    if (!isDrawingRef.current) return;
    isDrawingRef.current = false;

    if (tool === 'lasso') {
      // Find strokes contained within lasso bounding box
      const pts = currentPointsRef.current;
      if (pts.length > 2) {
        const minX = Math.min(...pts.map((p) => p.x));
        const maxX = Math.max(...pts.map((p) => p.x));
        const minY = Math.min(...pts.map((p) => p.y));
        const maxY = Math.max(...pts.map((p) => p.y));

        const selected = canvasData.strokes
          .filter((s) => s.points.some((p) => p.x >= minX && p.x <= maxX && p.y >= minY && p.y <= maxY))
          .map((s) => s.id);

        setSelectedStrokeIds(selected);
      }
      currentPointsRef.current = [];
      redraw();
      return;
    }

    if (tool === 'pen' || tool === 'highlighter' || tool === 'pencil') {
      if (currentPointsRef.current.length > 1) {
        const newStroke: CanvasStroke = {
          id: generateId(),
          tool,
          points: [...currentPointsRef.current],
          color,
          width: strokeWidth,
          opacity: tool === 'highlighter' ? 0.35 : 1,
          isHighlighter: tool === 'highlighter',
        };

        setHistory((prev) => [...prev, canvasData.strokes]);
        onUpdate({
          canvasData: {
            ...canvasData,
            strokes: [...canvasData.strokes, newStroke],
          },
        });
      }
      currentPointsRef.current = [];
    } else if (tool.startsWith('shape-') && startShapePointRef.current) {
      const endPoint = currentPointsRef.current[currentPointsRef.current.length - 1] || startShapePointRef.current;
      const type = tool.replace('shape-', '') as any;
      const x = Math.min(startShapePointRef.current.x, endPoint.x);
      const y = Math.min(startShapePointRef.current.y, endPoint.y);
      const width = Math.abs(endPoint.x - startShapePointRef.current.x);
      const height = Math.abs(endPoint.y - startShapePointRef.current.y);

      if (width > 5 || height > 5) {
        const newShape: CanvasShape = {
          id: generateId(),
          type,
          x,
          y,
          width: Math.max(20, width),
          height: Math.max(20, height),
          strokeColor: color,
          strokeWidth,
          opacity: 1,
        };
        onUpdate({
          canvasData: {
            ...canvasData,
            shapes: [...canvasData.shapes, newShape],
          },
        });
      }
      startShapePointRef.current = null;
    }
  };

  const handleSaveText = () => {
    if (textInputPos && textInputValue.trim()) {
      const newText: CanvasText = {
        id: generateId(),
        x: textInputPos.x,
        y: textInputPos.y,
        text: textInputValue.trim(),
        fontSize: 16,
        fontFamily: 'Inter',
        color,
      };
      onUpdate({
        canvasData: {
          ...canvasData,
          texts: [...canvasData.texts, newText],
        },
      });
    }
    setTextInputPos(null);
    setTextInputValue('');
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const previousStrokes = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    onUpdate({
      canvasData: {
        ...canvasData,
        strokes: previousStrokes,
      },
    });
  };

  const handleClear = () => {
    if (window.confirm('Clear all drawings and shapes on this canvas sheet?')) {
      setHistory((prev) => [...prev, canvasData.strokes]);
      onUpdate({
        canvasData: {
          ...canvasData,
          strokes: [],
          shapes: [],
          texts: [],
        },
      });
      setSelectedStrokeIds([]);
      showToast('Canvas cleared', 'info');
    }
  };

  const handleExportPng = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `${note.title || 'Drawing'}_Sketch.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    showToast('Exported canvas as PNG image', 'success');
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-auto bg-zinc-200/70 dark:bg-zinc-950 flex flex-col items-center select-none custom-scrollbar p-6"
    >
      {/* Floating Canvas Toolbar */}
      <CanvasToolbar
        tool={tool}
        setTool={setTool}
        color={color}
        setColor={setColor}
        strokeWidth={strokeWidth}
        setStrokeWidth={setStrokeWidth}
        template={template}
        setTemplate={(t) => {
          setTemplate(t);
          onUpdate({ canvasData: { ...canvasData, paperConfig: { ...canvasData.paperConfig, template: t } } });
        }}
        tint={tint}
        setTint={(t) => {
          setTint(t);
          onUpdate({ canvasData: { ...canvasData, paperConfig: { ...canvasData.paperConfig, tint: t } } });
        }}
        zoom={zoom}
        setZoom={setZoom}
        onClear={handleClear}
        onUndo={handleUndo}
        canUndo={history.length > 0 || canvasData.strokes.length > 0}
      />

      {/* Main Digital Canvas Sheet */}
      <div
        style={{
          width: `${CANVAS_WIDTH * zoom}px`,
          height: `${CANVAS_HEIGHT * zoom}px`,
          transformOrigin: 'top center',
        }}
        className="relative my-4 rounded-2xl shadow-2xl overflow-hidden border border-zinc-300 dark:border-zinc-800 transition-all duration-75"
      >
        {/* Paper Background with Template Grid/Lines */}
        <PaperBackground
          paperConfig={{
            ...canvasData.paperConfig,
            template,
            tint,
          }}
          width={CANVAS_WIDTH * zoom}
          height={CANVAS_HEIGHT * zoom}
        />

        {/* Drawing Canvas */}
        <canvas
          ref={canvasRef}
          style={{
            width: `${CANVAS_WIDTH * zoom}px`,
            height: `${CANVAS_HEIGHT * zoom}px`,
          }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="absolute inset-0 touch-none cursor-crosshair"
        />

        {/* Inline Text Box Input */}
        {textInputPos && (
          <div
            style={{
              left: `${textInputPos.x * zoom}px`,
              top: `${textInputPos.y * zoom}px`,
            }}
            className="absolute z-20 flex items-center gap-1.5 p-1 bg-white dark:bg-zinc-800 border border-emerald-500 rounded-xl shadow-xl"
          >
            <input
              type="text"
              autoFocus
              value={textInputValue}
              onChange={(e) => setTextInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSaveText();
                if (e.key === 'Escape') setTextInputPos(null);
              }}
              placeholder="Type note..."
              className="text-xs px-2 py-1 bg-transparent text-zinc-900 dark:text-zinc-100 outline-none w-48"
            />
            <button
              onClick={handleSaveText}
              className="px-2.5 py-1 text-xs bg-emerald-500 text-white rounded-lg font-semibold hover:bg-emerald-600"
            >
              Add
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper: Vector stroke smoothing and rendering
function drawStroke(ctx: CanvasRenderingContext2D, stroke: CanvasStroke, isSelected: boolean) {
  const points = stroke.points;
  if (!points || points.length === 0) return;

  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (isSelected) {
    ctx.shadowColor = '#6366f1';
    ctx.shadowBlur = 8;
  }

  if (stroke.isHighlighter) {
    ctx.globalAlpha = stroke.opacity || 0.35;
    ctx.strokeStyle = stroke.color;
    ctx.lineWidth = (stroke.width || 20) * 1.8;
  } else {
    ctx.globalAlpha = stroke.opacity || 1;
    ctx.strokeStyle = stroke.color;
    ctx.lineWidth = stroke.width || 3;
  }

  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);

  if (points.length === 1) {
    ctx.lineTo(points[0].x + 0.1, points[0].y + 0.1);
  } else {
    for (let i = 1; i < points.length - 1; i++) {
      const xc = (points[i].x + points[i + 1].x) / 2;
      const yc = (points[i].y + points[i + 1].y) / 2;
      ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
    }
    const last = points[points.length - 1];
    ctx.lineTo(last.x, last.y);
  }

  ctx.stroke();
  ctx.restore();
}

// Helper: Draw Geometric Shape
function drawShape(ctx: CanvasRenderingContext2D, shape: CanvasShape) {
  ctx.save();
  ctx.strokeStyle = shape.strokeColor;
  ctx.lineWidth = shape.strokeWidth;
  ctx.globalAlpha = shape.opacity || 1;

  if (shape.fillColor) {
    ctx.fillStyle = shape.fillColor;
  }

  ctx.beginPath();

  if (shape.type === 'rectangle') {
    ctx.rect(shape.x, shape.y, shape.width, shape.height);
    if (shape.fillColor) ctx.fill();
    ctx.stroke();
  } else if (shape.type === 'ellipse') {
    ctx.ellipse(
      shape.x + shape.width / 2,
      shape.y + shape.height / 2,
      shape.width / 2,
      shape.height / 2,
      0,
      0,
      2 * Math.PI
    );
    if (shape.fillColor) ctx.fill();
    ctx.stroke();
  } else if (shape.type === 'arrow') {
    const fromX = shape.x;
    const fromY = shape.y;
    const toX = shape.x + shape.width;
    const toY = shape.y + shape.height;
    const headlen = 12;
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.lineTo(toX - headlen * Math.cos(angle - Math.PI / 6), toY - headlen * Math.sin(angle - Math.PI / 6));
    ctx.moveTo(toX, toY);
    ctx.lineTo(toX - headlen * Math.cos(angle + Math.PI / 6), toY - headlen * Math.sin(angle + Math.PI / 6));
    ctx.stroke();
  }

  ctx.restore();
}

// Helper: Check if point is near stroke
function isPointNearStroke(pt: Point, stroke: CanvasStroke, threshold: number): boolean {
  for (const p of stroke.points) {
    const dx = p.x - pt.x;
    const dy = p.y - pt.y;
    if (Math.sqrt(dx * dx + dy * dy) <= threshold) {
      return true;
    }
  }
  return false;
}
