﻿import React from 'react';
import { PaperConfig, PaperTemplateType, PaperTint } from '../../types';

interface PaperBackgroundProps {
  paperConfig: PaperConfig;
  width: number;
  height: number;
}

export const PaperBackground: React.FC<PaperBackgroundProps> = ({
  paperConfig,
  width,
  height,
}) => {
  const { template, tint, lineSpacing = 28, gridSize = 24, showMargin = true } = paperConfig;

  // Background tint color
  const bgColors: Record<PaperTint, string> = {
    light: '#fdfcfb',
    cream: '#fbf7ee',
    sepia: '#f4ecd8',
    dark: '#1e1e24',
    navy: '#0f172a',
  };

  const lineColors: Record<PaperTint, string> = {
    light: '#e2e8f0',
    cream: '#e7ddc8',
    sepia: '#dfd2b5',
    dark: '#2e2e38',
    navy: '#1e293b',
  };

  const marginColors: Record<PaperTint, string> = {
    light: '#fca5a5',
    cream: '#f87171',
    sepia: '#ef4444',
    dark: '#7f1d1d',
    navy: '#ef4444',
  };

  const bgColor = bgColors[tint] || bgColors.light;
  const lineColor = lineColors[tint] || lineColors.light;
  const marginColor = marginColors[tint] || marginColors.light;

  return (
    <svg
      width={width}
      height={height}
      className="absolute inset-0 pointer-events-none"
      style={{ backgroundColor: bgColor }}
    >
      <defs>
        {/* Ruled lines pattern */}
        <pattern
          id="ruled-pattern"
          width={width}
          height={lineSpacing}
          patternUnits="userSpaceOnUse"
        >
          <line
            x1="0"
            y1={lineSpacing}
            x2={width}
            y2={lineSpacing}
            stroke={lineColor}
            strokeWidth="1"
          />
        </pattern>

        {/* Grid pattern */}
        <pattern
          id="grid-pattern"
          width={gridSize}
          height={gridSize}
          patternUnits="userSpaceOnUse"
        >
          <path
            d={`M ${gridSize} 0 L 0 0 0 ${gridSize}`}
            fill="none"
            stroke={lineColor}
            strokeWidth="0.8"
          />
        </pattern>

        {/* Dotted pattern */}
        <pattern
          id="dotted-pattern"
          width={gridSize}
          height={gridSize}
          patternUnits="userSpaceOnUse"
        >
          <circle cx={gridSize / 2} cy={gridSize / 2} r="1" fill={lineColor} />
        </pattern>
      </defs>

      {/* Pattern fill */}
      {(template === 'ruled' || template === 'narrow-ruled' || template === 'college-ruled' || template === 'cornell') && (
        <rect width={width} height={height} fill="url(#ruled-pattern)" />
      )}

      {(template === 'grid' || template === 'graph' || template === 'custom-grid') && (
        <rect width={width} height={height} fill="url(#grid-pattern)" />
      )}

      {template === 'dotted' && (
        <rect width={width} height={height} fill="url(#dotted-pattern)" />
      )}

      {/* Left Margin Line */}
      {showMargin && (template === 'ruled' || template === 'college-ruled') && (
        <line
          x1="90"
          y1="0"
          x2="90"
          y2={height}
          stroke={marginColor}
          strokeWidth="1.5"
          strokeDasharray="none"
        />
      )}

      {/* Cornell Notes Structure */}
      {template === 'cornell' && (
        <g>
          {/* Header row */}
          <line x1="0" y1="80" x2={width} y2="80" stroke={lineColor} strokeWidth="2" />
          {/* Cue column (left) */}
          <line x1="220" y1="80" x2="220" y2={height - 140} stroke={lineColor} strokeWidth="2" />
          {/* Summary footer (bottom) */}
          <line x1="0" y1={height - 140} x2={width} y2={height - 140} stroke={lineColor} strokeWidth="2" />
        </g>
      )}
    </svg>
  );
};
