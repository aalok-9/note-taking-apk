﻿import React from 'react';
import {
  Pen,
  Highlighter,
  Eraser,
  Lasso,
  Square,
  Circle,
  Triangle,
  MoveRight,
  Minus,
  Type,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Palette,
  LayoutTemplate,
  Trash2
} from 'lucide-react';
import { CanvasTool, PaperTemplateType, PaperTint } from '../../types';
import { ColorPicker } from '../common/ColorPicker';

interface CanvasToolbarProps {
  tool: CanvasTool;
  setTool: (tool: CanvasTool) => void;
  color: string;
  setColor: (color: string) => void;
  strokeWidth: number;
  setStrokeWidth: (width: number) => void;
  template: PaperTemplateType;
  setTemplate: (tpl: PaperTemplateType) => void;
  tint: PaperTint;
  setTint: (tint: PaperTint) => void;
  zoom: number;
  setZoom: (zoom: number | ((prev: number) => number)) => void;
  onClear: () => void;
  onUndo: () => void;
  canUndo: boolean;
}

export const CanvasToolbar: React.FC<CanvasToolbarProps> = ({
  tool,
  setTool,
  color,
  setColor,
  strokeWidth,
  setStrokeWidth,
  template,
  setTemplate,
  tint,
  setTint,
  zoom,
  setZoom,
  onClear,
  onUndo,
  canUndo,
}) => {
  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1.5 p-1.5 rounded-2xl bg-white/95 dark:bg-zinc-900/95 border border-zinc-200/80 dark:border-zinc-800 shadow-2xl backdrop-blur-md select-none">
      {/* Primary Drawing Tools */}
      <div className="flex items-center gap-0.5 pr-1.5 border-r border-zinc-200 dark:border-zinc-800">
        <button
          type="button"
          onClick={() => setTool('pen')}
          className={`p-2 rounded-xl transition ${
            tool === 'pen'
              ? 'bg-emerald-500 text-white shadow-xs'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Pen (Pressure Sensitive)"
        >
          <Pen className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setTool('highlighter')}
          className={`p-2 rounded-xl transition ${
            tool === 'highlighter'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Highlighter (Semi-transparent)"
        >
          <Highlighter className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setTool('eraser-stroke')}
          className={`p-2 rounded-xl transition ${
            tool === 'eraser-stroke' || tool === 'eraser-pixel'
              ? 'bg-zinc-800 text-white dark:bg-zinc-100 dark:text-zinc-900 shadow-xs'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Stroke Eraser"
        >
          <Eraser className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setTool('lasso')}
          className={`p-2 rounded-xl transition ${
            tool === 'lasso'
              ? 'bg-indigo-500 text-white shadow-xs'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Lasso Selection (Move & Edit Strokes)"
        >
          <Lasso className="w-4 h-4" />
        </button>
      </div>

      {/* Shapes Group */}
      <div className="flex items-center gap-0.5 pr-1.5 border-r border-zinc-200 dark:border-zinc-800">
        <button
          type="button"
          onClick={() => setTool('shape-rectangle')}
          className={`p-2 rounded-xl transition ${
            tool === 'shape-rectangle'
              ? 'bg-emerald-500 text-white'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Rectangle"
        >
          <Square className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setTool('shape-ellipse')}
          className={`p-2 rounded-xl transition ${
            tool === 'shape-ellipse'
              ? 'bg-emerald-500 text-white'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Ellipse / Circle"
        >
          <Circle className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setTool('shape-arrow')}
          className={`p-2 rounded-xl transition ${
            tool === 'shape-arrow'
              ? 'bg-emerald-500 text-white'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Arrow"
        >
          <MoveRight className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => setTool('text')}
          className={`p-2 rounded-xl transition ${
            tool === 'text'
              ? 'bg-emerald-500 text-white'
              : 'hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300'
          }`}
          title="Text Box"
        >
          <Type className="w-4 h-4" />
        </button>
      </div>

      {/* Color Palette & Stroke Size */}
      <div className="flex items-center gap-2 pr-1.5 border-r border-zinc-200 dark:border-zinc-800">
        <ColorPicker
          selectedColor={color}
          onChange={setColor}
          presetColors={[
            '#0f172a',
            '#059669',
            '#2563eb',
            '#dc2626',
            '#d97706',
            '#7c3aed',
            '#ffffff',
          ]}
        />

        <div className="flex items-center gap-1 text-xs text-zinc-500 font-medium pl-1">
          <input
            type="range"
            min={1}
            max={tool === 'highlighter' ? 40 : 20}
            value={strokeWidth}
            onChange={(e) => setStrokeWidth(Number(e.target.value))}
            className="w-16 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
          <span className="w-4 text-center font-mono text-[10px]">{strokeWidth}</span>
        </div>
      </div>

      {/* Paper Template Selector */}
      <div className="flex items-center gap-1.5 pr-1.5 border-r border-zinc-200 dark:border-zinc-800 text-xs">
        <select
          value={template}
          onChange={(e) => setTemplate(e.target.value as PaperTemplateType)}
          className="bg-zinc-100 dark:bg-zinc-800 rounded-xl px-2.5 py-1.5 font-medium text-zinc-700 dark:text-zinc-200 outline-none border-none cursor-pointer"
        >
          <option value="blank">Blank Paper</option>
          <option value="ruled">Ruled Lines</option>
          <option value="narrow-ruled">Narrow Ruled</option>
          <option value="college-ruled">College Ruled</option>
          <option value="grid">Grid Paper</option>
          <option value="dotted">Dotted Grid</option>
          <option value="graph">Graph Paper</option>
          <option value="cornell">Cornell Study Notes</option>
          <option value="checklist-planner">Checklist Planner</option>
          <option value="daily-journal">Daily Journal</option>
        </select>

        <select
          value={tint}
          onChange={(e) => setTint(e.target.value as PaperTint)}
          className="bg-zinc-100 dark:bg-zinc-800 rounded-xl px-2 py-1.5 font-medium text-zinc-700 dark:text-zinc-200 outline-none border-none cursor-pointer capitalize"
        >
          <option value="light">Light White</option>
          <option value="cream">Warm Ivory</option>
          <option value="sepia">Vintage Sepia</option>
          <option value="dark">Dark Slate</option>
          <option value="navy">Navy Blue</option>
        </select>
      </div>

      {/* Zoom & Undo & Clear */}
      <div className="flex items-center gap-0.5">
        <button
          type="button"
          onClick={() => setZoom((prev) => Math.max(0.2, Number((prev - 0.1).toFixed(1))))}
          className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500"
          title="Zoom Out"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <span className="text-[11px] font-mono font-semibold w-10 text-center text-zinc-600 dark:text-zinc-300">
          {Math.round(zoom * 100)}%
        </span>
        <button
          type="button"
          onClick={() => setZoom((prev) => Math.min(3.0, Number((prev + 0.1).toFixed(1))))}
          className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500"
          title="Zoom In"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>

        <div className="w-[1px] h-4 bg-zinc-200 dark:bg-zinc-800 mx-0.5" />

        <button
          type="button"
          onClick={onUndo}
          disabled={!canUndo}
          className="p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 disabled:opacity-30"
          title="Undo (Ctrl+Z)"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={onClear}
          className="p-1.5 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-950/50 text-zinc-500 hover:text-rose-600"
          title="Clear Canvas"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
