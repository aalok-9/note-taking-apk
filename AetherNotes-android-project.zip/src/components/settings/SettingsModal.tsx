﻿import React, { useState, useRef } from 'react';
import {
  Settings,
  Palette,
  Type,
  Layout,
  HardDrive,
  Keyboard,
  ShieldCheck,
  Download,
  Upload,
  RotateCcw,
  Trash2,
  Check,
  PenTool,
  Info
} from 'lucide-react';
import { Modal } from '../common/Modal';
import { useTheme } from '../../hooks/useTheme';
import { useWorkspace } from '../../hooks/useWorkspace';
import { PortabilityService } from '../../services/portability';
import { AppSettings, PaperTemplateType, PaperTint } from '../../types';
import { showToast } from '../common/Toast';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { settings, updateSettings } = useTheme();
  const { workspace, folders, notebooks, notes, refreshData } = useWorkspace();
  const [activeTab, setActiveTab] = useState<'appearance' | 'editor' | 'paper' | 'storage' | 'shortcuts' | 'privacy'>('appearance');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleExportBackup = async () => {
    await PortabilityService.exportWorkspaceZip(workspace, folders, notebooks, notes);
    showToast('Workspace backup downloaded (.zip)', 'success');
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const res = await PortabilityService.importWorkspaceZip(file);
    if (res.success) {
      showToast(res.message, 'success');
      await refreshData();
      onClose();
    } else {
      showToast(res.message, 'error');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      maxWidth="3xl"
      title={
        <span className="flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-500" />
          Application Settings & Preferences
        </span>
      }
    >
      <div className="grid grid-cols-4 gap-6 h-[480px] select-none text-xs">
        {/* Left Category Navigation */}
        <div className="col-span-1 border-r border-zinc-200 dark:border-zinc-800 pr-3 space-y-1 font-medium text-zinc-600 dark:text-zinc-400">
          <button
            onClick={() => setActiveTab('appearance')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition text-left ${
              activeTab === 'appearance'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <Palette className="w-4 h-4" /> Appearance
          </button>

          <button
            onClick={() => setActiveTab('editor')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition text-left ${
              activeTab === 'editor'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <Type className="w-4 h-4" /> Editor & Type
          </button>

          <button
            onClick={() => setActiveTab('paper')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition text-left ${
              activeTab === 'paper'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <PenTool className="w-4 h-4" /> Digital Paper
          </button>

          <button
            onClick={() => setActiveTab('storage')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition text-left ${
              activeTab === 'storage'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <HardDrive className="w-4 h-4" /> Backup & Storage
          </button>

          <button
            onClick={() => setActiveTab('shortcuts')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition text-left ${
              activeTab === 'shortcuts'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <Keyboard className="w-4 h-4" /> Shortcuts
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition text-left ${
              activeTab === 'privacy'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> Privacy & Local
          </button>
        </div>

        {/* Right Settings Content */}
        <div className="col-span-3 overflow-y-auto pr-2 custom-scrollbar space-y-6">
          {/* APPEARANCE */}
          {activeTab === 'appearance' && (
            <div className="space-y-5">
              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Color Theme
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'light', label: 'Light Clean', desc: 'Crisp white' },
                    { id: 'dark', label: 'Dark Studio', desc: 'Deep zinc' },
                    { id: 'oled', label: 'OLED Pure', desc: 'Midnight black' },
                    { id: 'sepia', label: 'Warm Sepia', desc: 'Paper reader' },
                  ].map((th) => (
                    <button
                      key={th.id}
                      onClick={() => updateSettings({ theme: th.id as any })}
                      className={`p-3 rounded-xl border text-left transition ${
                        settings.theme === th.id
                          ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                          : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-xs text-zinc-900 dark:text-zinc-100">
                        {th.label}
                      </div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">{th.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Accent Color
                </label>
                <div className="flex gap-2">
                  {[
                    { id: 'green', color: '#10b981', label: 'Emerald' },
                    { id: 'indigo', color: '#6366f1', label: 'Indigo' },
                    { id: 'rose', color: '#f43f5e', label: 'Rose' },
                    { id: 'amber', color: '#f59e0b', label: 'Amber' },
                    { id: 'cyan', color: '#06b6d4', label: 'Cyan' },
                    { id: 'violet', color: '#8b5cf6', label: 'Violet' },
                  ].map((acc) => (
                    <button
                      key={acc.id}
                      onClick={() => updateSettings({ accentColor: acc.id as any })}
                      style={{ backgroundColor: acc.color }}
                      className={`w-7 h-7 rounded-full transition-transform ${
                        settings.accentColor === acc.id
                          ? 'scale-125 ring-2 ring-emerald-500 ring-offset-2 dark:ring-offset-zinc-900'
                          : 'hover:scale-110'
                      }`}
                      title={acc.label}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Interface Spacing / Density
                </label>
                <div className="flex gap-2">
                  {['compact', 'normal', 'comfortable'].map((d) => (
                    <button
                      key={d}
                      onClick={() => updateSettings({ density: d as any })}
                      className={`px-3 py-1.5 rounded-lg border capitalize ${
                        settings.density === d
                          ? 'bg-emerald-500 text-white font-semibold'
                          : 'border-zinc-200 dark:border-zinc-800'
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* EDITOR */}
          {activeTab === 'editor' && (
            <div className="space-y-5">
              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Typography Font Family
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'sans', label: 'Inter Sans', font: 'font-sans' },
                    { id: 'serif', label: 'Merriweather Serif', font: 'font-serif' },
                    { id: 'mono', label: 'JetBrains Mono', font: 'font-mono' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => updateSettings({ fontFamily: f.id as any })}
                      className={`p-3 rounded-xl border text-left ${f.font} ${
                        settings.fontFamily === f.id
                          ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                          : 'border-zinc-200 dark:border-zinc-800'
                      }`}
                    >
                      <div className="font-bold text-xs">{f.label}</div>
                      <div className="text-[10px] text-zinc-400 mt-1">The quick brown fox jumps</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Editor Font Sizing
                </label>
                <div className="flex gap-2">
                  {['compact', 'normal', 'relaxed'].map((fs) => (
                    <button
                      key={fs}
                      onClick={() => updateSettings({ fontSize: fs as any })}
                      className={`px-3 py-1.5 rounded-lg border capitalize ${
                        settings.fontSize === fs
                          ? 'bg-emerald-500 text-white font-semibold'
                          : 'border-zinc-200 dark:border-zinc-800'
                      }`}
                    >
                      {fs}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* DIGITAL PAPER */}
          {activeTab === 'paper' && (
            <div className="space-y-5">
              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Default Paper Template
                </label>
                <select
                  value={settings.defaultPaperTemplate}
                  onChange={(e) =>
                    updateSettings({ defaultPaperTemplate: e.target.value as PaperTemplateType })
                  }
                  className="w-full p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none font-medium text-xs"
                >
                  <option value="ruled">Ruled Paper</option>
                  <option value="grid">Grid Paper</option>
                  <option value="dotted">Dotted Grid</option>
                  <option value="cornell">Cornell Study Template</option>
                  <option value="blank">Blank White</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-zinc-900 dark:text-zinc-100 block mb-2">
                  Default Paper Tint
                </label>
                <select
                  value={settings.defaultPaperTint}
                  onChange={(e) =>
                    updateSettings({ defaultPaperTint: e.target.value as PaperTint })
                  }
                  className="w-full p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none font-medium text-xs capitalize"
                >
                  <option value="light">Light White</option>
                  <option value="cream">Warm Ivory</option>
                  <option value="sepia">Vintage Sepia</option>
                  <option value="dark">Dark Slate</option>
                </select>
              </div>
            </div>
          )}

          {/* STORAGE & BACKUP */}
          {activeTab === 'storage' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100">
                      Workspace Full Backup (.zip)
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">
                      Export your entire workspace containing all notes, canvas sketches, tables,
                      and manifest.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleExportBackup}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-xs shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export Backup
                  </button>
                </div>

                <div className="border-t border-zinc-200 dark:border-zinc-800 pt-3 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100">
                      Restore Workspace Package
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">
                      Import a previously exported AetherNotes .zip backup archive.
                    </p>
                  </div>
                  <div>
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept=".zip"
                      onChange={handleImportBackup}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold text-xs transition"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      Restore ZIP
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SHORTCUTS */}
          {activeTab === 'shortcuts' && (
            <div className="space-y-2">
              <h4 className="font-bold text-zinc-900 dark:text-zinc-100 mb-3">
                Keyboard Shortcuts Cheat Sheet
              </h4>
              <div className="space-y-1.5">
                {[
                  { key: 'Ctrl + N', desc: 'Create a new note instantly' },
                  { key: 'Ctrl + P / Cmd + K', desc: 'Open Command Palette' },
                  { key: 'Ctrl + Shift + F', desc: 'Global search across all notes' },
                  { key: 'Ctrl + Shift + N', desc: 'Quick note capture' },
                  { key: '[[ + Note Title', desc: 'Link to another note (Wikilink)' },
                  { key: '/ (Slash)', desc: 'Open block command menu' },
                  { key: 'Ctrl + B / Ctrl + I', desc: 'Bold / Italic text formatting' },
                  { key: 'Ctrl + Z / Ctrl + Y', desc: 'Undo / Redo edits' },
                ].map((sc) => (
                  <div
                    key={sc.key}
                    className="flex items-center justify-between p-2 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-100 dark:border-zinc-800"
                  >
                    <span className="text-zinc-700 dark:text-zinc-300">{sc.desc}</span>
                    <kbd className="px-2 py-0.5 rounded bg-zinc-200 dark:bg-zinc-700 text-[10px] font-mono font-bold text-zinc-800 dark:text-zinc-200">
                      {sc.key}
                    </kbd>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* PRIVACY & LOCAL ARCHITECTURE */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  100% Local-First & Private
                </div>
                <p className="text-xs text-emerald-900/80 dark:text-emerald-200/80 leading-relaxed">
                  Your notes, sketches, formulas, and attachments are stored 100% locally on your
                  device in an open IndexedDB / JSON format. No user registration is needed, zero
                  telemetry is sent, and zero external cloud servers are required.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[11px] text-zinc-400 space-y-1">
                <div>Format Specification: <strong className="text-zinc-200">AetherWorkspace v1.0.0</strong></div>
                <div>Storage Engine: <strong className="text-zinc-200">IndexedDB + Dexie + Local File API</strong></div>
                <div>Encryption Ready: <strong className="text-zinc-200">Yes (AES-GCM compatible)</strong></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};
