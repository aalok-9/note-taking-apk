﻿import { Workspace, Folder, Note } from '../types';
import { generateId } from '../domain/markdown';

export const SAMPLE_WORKSPACE: Workspace = {
  id: 'ws_ca_studies',
  name: 'CA Studies Workspace',
  description: 'Comprehensive study workspace for Chartered Accountancy Intermediate examination preparation.',
  icon: '📚',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  formatVersion: 1
};

export const SAMPLE_FOLDERS: Folder[] = [
  {
    id: 'fld_taxation',
    workspaceId: 'ws_ca_studies',
    name: 'Taxation (Direct & Indirect)',
    icon: '📊',
    color: '#10b981',
    order: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'fld_audit',
    workspaceId: 'ws_ca_studies',
    name: 'Audit & Assurance',
    icon: '🔍',
    color: '#6366f1',
    order: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'fld_fm',
    workspaceId: 'ws_ca_studies',
    name: 'Financial Management',
    icon: '📈',
    color: '#f59e0b',
    order: 2,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'fld_sm',
    workspaceId: 'ws_ca_studies',
    name: 'Strategic Management',
    icon: '🎯',
    color: '#ec4899',
    order: 3,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'fld_accounting',
    workspaceId: 'ws_ca_studies',
    name: 'Advanced Accounting',
    icon: '📑',
    color: '#06b6d4',
    order: 4,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const SAMPLE_NOTES: Note[] = [
  {
    id: 'note_tax_rates',
    workspaceId: 'ws_ca_studies',
    folderId: 'fld_taxation',
    title: 'Taxation — Corporate Tax Rates & Deductions',
    icon: '🏛️',
    viewMode: 'editor',
    isFavorite: true,
    isPinned: true,
    tags: ['Taxation', 'DirectTax', 'CAInter', 'Section115BAA'],
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
    blocks: [
      {
        id: generateId(),
        type: 'heading-1',
        content: 'Corporate Tax Regime Summary (FY 2025-26)'
      },
      {
        id: generateId(),
        type: 'callout',
        content: '',
        data: {
          icon: '💡',
          type: 'tip',
          text: 'Under Section 115BAA, domestic companies can opt for a concessional basic tax rate of 22% (effective rate 25.168% with 10% surcharge and 4% cess) provided no specified exemptions/deductions are claimed.'
        }
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'Comparative Tax Rate Matrix'
      },
      {
        id: generateId(),
        type: 'table',
        content: '',
        data: {
          columns: [
            { id: 'sec', title: 'Section Code', type: 'text', width: 140 },
            { id: 'entity', title: 'Entity Type', type: 'text', width: 180 },
            { id: 'rate', title: 'Base Tax Rate (%)', type: 'number', width: 150 },
            { id: 'surcharge', title: 'Surcharge Rate (%)', type: 'number', width: 150 },
            { id: 'effRate', title: 'Effective Rate (%)', type: 'number', width: 160 }
          ],
          rows: [
            { id: 'r1', cells: { sec: 'Sec 115BAA', entity: 'Domestic Co (Any)', rate: 22, surcharge: 10, effRate: 25.17 } },
            { id: 'r2', cells: { sec: 'Sec 115BAB', entity: 'New Manufacturing Co', rate: 15, surcharge: 10, effRate: 17.16 } },
            { id: 'r3', cells: { sec: 'Regular Regime', entity: 'Turnover <= 400 Cr', rate: 25, surcharge: 7, effRate: 27.82 } },
            { id: 'r4', cells: { sec: 'Regular Regime', entity: 'Turnover > 400 Cr', rate: 30, surcharge: 12, effRate: 34.94 } }
          ],
          summaryType: 'count'
        }
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'GST Input Tax Credit (ITC) Verification Checklist'
      },
      {
        id: generateId(),
        type: 'checklist',
        checked: true,
        content: 'Possession of tax invoice or debit note issued by supplier (Sec 16(2)(a))',
        meta: { priority: 'high' }
      },
      {
        id: generateId(),
        type: 'checklist',
        checked: true,
        content: 'Receipt of goods or services verified against delivery challan (Sec 16(2)(b))',
        meta: { priority: 'high' }
      },
      {
        id: generateId(),
        type: 'checklist',
        checked: false,
        content: 'Supplier has actually paid tax to the Government (GSTR-2B reconciliation)',
        meta: { dueDate: new Date(Date.now() + 86400000 * 2).toISOString(), priority: 'high' }
      },
      {
        id: generateId(),
        type: 'checklist',
        checked: false,
        content: 'Recipient has filed monthly return in Form GSTR-3B',
        meta: { dueDate: new Date(Date.now() + 86400000 * 5).toISOString(), priority: 'medium' }
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'Related Audit & Financial Linkages'
      },
      {
        id: generateId(),
        type: 'paragraph',
        content: 'Tax provisions must be cross-verified during statutory audit as outlined in [[Audit — SA 200 & SA 500 Audit Evidence Framework]] and factored into cash flow forecasting in [[Financial Management — Capital Budgeting & NPV Calculations]].'
      }
    ]
  },
  {
    id: 'note_audit_sa',
    workspaceId: 'ws_ca_studies',
    folderId: 'fld_audit',
    title: 'Audit — SA 200 & SA 500 Audit Evidence Framework',
    icon: '🔍',
    viewMode: 'editor',
    isFavorite: true,
    isPinned: true,
    tags: ['Audit', 'SA200', 'SA500', 'CAInter', 'AuditEvidence'],
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
    blocks: [
      {
        id: generateId(),
        type: 'heading-1',
        content: 'Standard on Auditing (SA) Core Principles'
      },
      {
        id: generateId(),
        type: 'callout',
        content: '',
        data: {
          icon: '🛡️',
          type: 'info',
          text: 'SA 200 establishes the overall objectives of the independent auditor: obtaining reasonable assurance about whether financial statements are free from material misstatement whether due to fraud or error.'
        }
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'SA 500: Audit Evidence Requirements'
      },
      {
        id: generateId(),
        type: 'bullet-list',
        content: 'Sufficiency is the measure of the quantity of audit evidence.'
      },
      {
        id: generateId(),
        type: 'bullet-list',
        content: 'Appropriateness is the measure of the quality (relevance and reliability) of audit evidence.'
      },
      {
        id: generateId(),
        type: 'quote',
        content: 'External evidence obtained directly by the auditor (e.g. bank confirmation) is more reliable than internal evidence generated by the entity.'
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'Audit Sampling Python Simulation Model'
      },
      {
        id: generateId(),
        type: 'code',
        content: '',
        data: {
          language: 'python',
          code: `# Systematic Random Sampling for Substantive Testing
import random

def calculate_sample_interval(population_value, materiality_threshold):
    sampling_interval = materiality_threshold / 3.0  # factor of safety
    sample_size = int(population_value / sampling_interval)
    return sampling_interval, sample_size

pop_val = 50_000_000  # Total ledger value: $50M
materiality = 1_250_000 # Performance materiality: $1.25M
interval, size = calculate_sample_interval(pop_val, materiality)
print(f"Sample Size: {size} items, Interval: {interval:,.2f}")`
        }
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'Cross-Disciplinary Connections'
      },
      {
        id: generateId(),
        type: 'paragraph',
        content: 'When evaluating audit risks in strategic management decisions, cross-reference [[Strategic Management — Business Policy Framework]] and verify statutory tax liabilities per [[Taxation — Corporate Tax Rates & Deductions]].'
      }
    ]
  },
  {
    id: 'note_fm_npv',
    workspaceId: 'ws_ca_studies',
    folderId: 'fld_fm',
    title: 'Financial Management — Capital Budgeting & NPV Calculations',
    icon: '📈',
    viewMode: 'editor',
    tags: ['FinancialManagement', 'NPV', 'IRR', 'CAInter'],
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
    blocks: [
      {
        id: generateId(),
        type: 'heading-1',
        content: 'Capital Budgeting Evaluation Metrics'
      },
      {
        id: generateId(),
        type: 'equation',
        content: 'NPV = \\sum_{t=1}^{n} \\frac{CF_t}{(1 + k)^t} - C_0'
      },
      {
        id: generateId(),
        type: 'paragraph',
        content: 'Where $CF_t$ is the net cash flow at period $t$, $k$ is the cost of capital / hurdle rate, and $C_0$ is the initial investment outlay.'
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'Discounted Cash Flow (DCF) Schedule'
      },
      {
        id: generateId(),
        type: 'table',
        content: '',
        data: {
          columns: [
            { id: 'year', title: 'Year (t)', type: 'text', width: 100 },
            { id: 'cashflow', title: 'Cash Flow (₹ Lacs)', type: 'number', width: 160 },
            { id: 'df', title: 'Discount Factor (12%)', type: 'number', width: 180 },
            { id: 'pv', title: 'Present Value (₹ Lacs)', type: 'number', width: 180 }
          ],
          rows: [
            { id: 'y0', cells: { year: '0', cashflow: -100.0, df: 1.000, pv: -100.0 } },
            { id: 'y1', cells: { year: '1', cashflow: 35.0, df: 0.893, pv: 31.25 } },
            { id: 'y2', cells: { year: '2', cashflow: 45.0, df: 0.797, pv: 35.87 } },
            { id: 'y3', cells: { year: '3', cashflow: 50.0, df: 0.712, pv: 35.60 } }
          ],
          summaryType: 'sum'
        }
      },
      {
        id: generateId(),
        type: 'callout',
        content: '',
        data: {
          icon: '✅',
          type: 'success',
          text: 'Project NPV is positive (₹ 2.72 Lacs > 0). Therefore, the capital expenditure project is financially viable.'
        }
      }
    ]
  },
  {
    id: 'note_sm_framework',
    workspaceId: 'ws_ca_studies',
    folderId: 'fld_sm',
    title: 'Strategic Management — Business Policy Framework',
    icon: '🎯',
    viewMode: 'editor',
    tags: ['StrategicManagement', 'PortersFiveForces', 'SWOT', 'CAInter'],
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
    blocks: [
      {
        id: generateId(),
        type: 'heading-1',
        content: "Porter's 5 Competitive Forces Model"
      },
      {
        id: generateId(),
        type: 'numbered-list',
        content: 'Threat of New Entrants (barriers to entry, capital requirements)'
      },
      {
        id: generateId(),
        type: 'numbered-list',
        content: 'Bargaining Power of Buyers (customer concentration, switching costs)'
      },
      {
        id: generateId(),
        type: 'numbered-list',
        content: 'Bargaining Power of Suppliers (input differentiation, supplier dominance)'
      },
      {
        id: generateId(),
        type: 'numbered-list',
        content: 'Threat of Substitute Products or Services'
      },
      {
        id: generateId(),
        type: 'numbered-list',
        content: 'Rivalry Among Existing Competitors in the Industry'
      },
      {
        id: generateId(),
        type: 'heading-2',
        content: 'Strategic Alignment Links'
      },
      {
        id: generateId(),
        type: 'paragraph',
        content: 'Industry positioning affects capital expenditure decisions analyzed in [[Financial Management — Capital Budgeting & NPV Calculations]] and statutory compliance evaluated in [[Audit — SA 200 & SA 500 Audit Evidence Framework]].'
      }
    ]
  },
  {
    id: 'note_canvas_tax_diagram',
    workspaceId: 'ws_ca_studies',
    folderId: 'fld_taxation',
    title: 'Tax Computation Flowchart & Digital Sketch',
    icon: '🎨',
    viewMode: 'canvas',
    tags: ['Taxation', 'Flowchart', 'DigitalPaper', 'CornellNotes'],
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date().toISOString(),
    version: 1,
    blocks: [],
    canvasData: {
      strokes: [
        {
          id: 'str_1',
          tool: 'pen',
          color: '#10b981',
          width: 3,
          opacity: 1,
          points: [
            { x: 120, y: 150 }, { x: 140, y: 150 }, { x: 180, y: 150 }, { x: 220, y: 150 }, { x: 260, y: 150 }
          ]
        },
        {
          id: 'str_2',
          tool: 'highlighter',
          color: '#fef08a',
          width: 24,
          opacity: 0.5,
          isHighlighter: true,
          points: [
            { x: 110, y: 220 }, { x: 180, y: 220 }, { x: 280, y: 220 }
          ]
        }
      ],
      shapes: [
        {
          id: 'shp_1',
          type: 'rectangle',
          x: 100,
          y: 100,
          width: 260,
          height: 90,
          strokeColor: '#059669',
          fillColor: '#ecfdf5',
          strokeWidth: 2,
          opacity: 1
        },
        {
          id: 'shp_2',
          type: 'rectangle',
          x: 100,
          y: 250,
          width: 260,
          height: 90,
          strokeColor: '#2563eb',
          fillColor: '#eff6ff',
          strokeWidth: 2,
          opacity: 1
        },
        {
          id: 'shp_3',
          type: 'arrow',
          x: 230,
          y: 190,
          width: 0,
          height: 60,
          strokeColor: '#475569',
          strokeWidth: 3,
          opacity: 1
        }
      ],
      texts: [
        {
          id: 'txt_1',
          x: 120,
          y: 135,
          text: 'Gross Total Income (GTI)',
          fontSize: 16,
          fontFamily: 'Inter',
          color: '#065f46'
        },
        {
          id: 'txt_2',
          x: 120,
          y: 285,
          text: 'Less: Deductions (Ch VI-A)',
          fontSize: 16,
          fontFamily: 'Inter',
          color: '#1e40af'
        }
      ],
      images: [],
      paperConfig: {
        template: 'cornell',
        tint: 'cream',
        lineSpacing: 28,
        gridSize: 24,
        showMargin: true,
        orientation: 'portrait'
      },
      viewport: {
        zoom: 1,
        panX: 0,
        panY: 0
      }
    }
  }
];

export async function initializeSampleWorkspace() {
  const { StorageService } = await import('../data/db');
  
  const existingWorkspaces = await StorageService.getWorkspaces();
  if (existingWorkspaces.length === 0) {
    await StorageService.saveWorkspace(SAMPLE_WORKSPACE);
    for (const folder of SAMPLE_FOLDERS) {
      await StorageService.saveFolder(folder);
    }
    for (const note of SAMPLE_NOTES) {
      await StorageService.saveNote(note, true);
    }
  }
}
