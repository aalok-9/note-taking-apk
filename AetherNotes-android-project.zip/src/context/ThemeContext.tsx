﻿import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppSettings } from '../types';
import { StorageService, DEFAULT_SETTINGS } from '../data/db';

export interface ThemeContextType {
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => Promise<void>;
}

const ThemeContext = createContext<ThemeContextType | null>(null);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  const applyTheme = (s: AppSettings) => {
    const root = document.documentElement;
    root.classList.remove('dark', 'theme-oled', 'theme-sepia');

    if (s.theme === 'dark') {
      root.classList.add('dark');
    } else if (s.theme === 'oled') {
      root.classList.add('dark', 'theme-oled');
    } else if (s.theme === 'sepia') {
      root.classList.add('theme-sepia');
    } else if (s.theme === 'system') {
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        root.classList.add('dark');
      }
    }

    root.setAttribute('data-accent', s.accentColor || 'green');
    root.setAttribute('data-density', s.density || 'normal');
    root.setAttribute('data-font', s.fontFamily || 'sans');
  };

  useEffect(() => {
    StorageService.getSettings().then((s) => {
      setSettings(s);
      applyTheme(s);
    });
  }, []);

  const updateSettings = async (newSettings: Partial<AppSettings>) => {
    const updated = await StorageService.saveSettings(newSettings);
    setSettings(updated);
    applyTheme(updated);
  };

  return (
    <ThemeContext.Provider value={{ settings, updateSettings }}>
      {children}
    </ThemeContext.Provider>
  );
};

export function useThemeContext(): ThemeContextType {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useThemeContext must be used within a ThemeProvider');
  }
  return context;
}
