﻿import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { Workspace, Folder, Notebook, Note, ViewMode, Block } from '../types';
import { StorageService } from '../data/db';
import { initializeSampleWorkspace, SAMPLE_WORKSPACE } from '../sample/caStudiesWorkspace';
import { generateId } from '../domain/markdown';

export type MainViewType = 'note' | 'graph' | 'tasks' | 'trash';

export interface WorkspaceContextType {
  workspace: Workspace;
  folders: Folder[];
  notebooks: Notebook[];
  notes: Note[];
  activeNote: Note | undefined;
  activeNoteId: string | null;
  setActiveNoteId: (id: string | null) => void;
  mainView: MainViewType;
  setMainView: (view: MainViewType) => void;
  selectedFolderId: string | null;
  setSelectedFolderId: (id: string | null) => void;
  selectedTag: string | null;
  setSelectedTag: (tag: string | null) => void;
  filterFavorites: boolean;
  setFilterFavorites: (fav: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  saveStatus: 'saved' | 'saving' | 'unsaved';
  isTabletMode: boolean;
  setIsTabletMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  isNoteListOpen: boolean;
  setIsNoteListOpen: (val: boolean | ((prev: boolean) => boolean)) => void;
  updateActiveNote: (updatedFields: Partial<Note>, immediate?: boolean) => void;
  createNote: (options?: {
    title?: string;
    folderId?: string;
    viewMode?: ViewMode;
    initialBlocks?: Block[];
    tags?: string[];
  }) => Promise<Note>;
  deleteNote: (noteId: string, permanent?: boolean) => Promise<void>;
  restoreNote: (noteId: string) => Promise<void>;
  emptyTrash: () => Promise<void>;
  duplicateNote: (noteId: string) => Promise<Note | undefined>;
  createFolder: (name: string, color?: string, icon?: string) => Promise<Folder>;
  deleteFolder: (folderId: string) => Promise<void>;
  toggleFavorite: (noteId: string) => void;
  togglePin: (noteId: string) => void;
  refreshData: () => Promise<void>;
}

const WorkspaceContext = createContext<WorkspaceContextType | null>(null);

export const WorkspaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [workspace, setWorkspace] = useState<Workspace>(SAMPLE_WORKSPACE);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [notebooks, setNotebooks] = useState<Notebook[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);

  // Navigation & Filtering
  const [mainView, setMainView] = useState<MainViewType>('note');
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [filterFavorites, setFilterFavorites] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Tablet & Touch studio mode
  const [isTabletMode, setIsTabletMode] = useState<boolean>(() => {
    return window.innerWidth <= 1024 || 'ontouchstart' in window;
  });
  const [isNoteListOpen, setIsNoteListOpen] = useState<boolean>(true);

  // Save status indicator
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const saveTimeoutRef = useRef<any>(null);

  // Refresh data from database
  const refreshData = useCallback(async () => {
    await initializeSampleWorkspace();
    const ws = await StorageService.getActiveWorkspace();
    if (ws) {
      setWorkspace(ws);
      const flds = await StorageService.getFolders(ws.id);
      setFolders(flds);
      const nts = await StorageService.getNotes(ws.id);
      setNotes(nts);

      if (!activeNoteId && nts.length > 0) {
        const firstActive = nts.find((n) => !n.inTrash);
        if (firstActive) setActiveNoteId(firstActive.id);
      }
    }
  }, [activeNoteId]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Active note object
  const activeNote = notes.find((n) => n.id === activeNoteId);

  // Debounced auto-save active note
  const updateActiveNote = useCallback(
    (updatedFields: Partial<Note>, immediate = false) => {
      if (!activeNoteId) return;

      setSaveStatus('unsaved');

      setNotes((prevNotes) =>
        prevNotes.map((n) => {
          if (n.id === activeNoteId) {
            return {
              ...n,
              ...updatedFields,
              updatedAt: new Date().toISOString(),
            };
          }
          return n;
        })
      );

      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }

      const performSave = async () => {
        setSaveStatus('saving');
        const currentNote = notes.find((n) => n.id === activeNoteId);
        if (currentNote) {
          const toSave = { ...currentNote, ...updatedFields };
          await StorageService.saveNote(toSave, false);
          setSaveStatus('saved');
        }
      };

      if (immediate) {
        performSave();
      } else {
        saveTimeoutRef.current = setTimeout(performSave, 350);
      }
    },
    [activeNoteId, notes]
  );

  // Create Note
  const createNote = async (options?: {
    title?: string;
    folderId?: string;
    viewMode?: ViewMode;
    initialBlocks?: Block[];
    tags?: string[];
  }) => {
    const newNote: Note = {
      id: generateId(),
      workspaceId: workspace.id,
      folderId: options?.folderId || selectedFolderId || undefined,
      title: options?.title || '',
      viewMode: options?.viewMode || 'editor',
      blocks: options?.initialBlocks || [
        { id: generateId(), type: 'heading-1', content: options?.title || '' },
        { id: generateId(), type: 'paragraph', content: '' },
      ],
      tags: options?.tags || (selectedTag ? [selectedTag] : []),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1,
      inTrash: false,
    };

    if (options?.viewMode === 'canvas') {
      newNote.canvasData = {
        strokes: [],
        shapes: [],
        texts: [],
        images: [],
        paperConfig: {
          template: 'ruled',
          tint: 'light',
          lineSpacing: 28,
          gridSize: 24,
          showMargin: true,
          orientation: 'portrait',
        },
        viewport: { zoom: 1, panX: 0, panY: 0 },
      };
    }

    await StorageService.saveNote(newNote, true);
    setNotes((prev) => [newNote, ...prev]);
    setActiveNoteId(newNote.id);
    setMainView('note');
    return newNote;
  };

  // Delete Note
  const deleteNote = async (noteId: string, permanent = false) => {
    await StorageService.deleteNote(noteId, permanent);
    if (permanent) {
      setNotes((prev) => prev.filter((n) => n.id !== noteId));
    } else {
      setNotes((prev) =>
        prev.map((n) =>
          n.id === noteId ? { ...n, inTrash: true, trashDate: new Date().toISOString() } : n
        )
      );
    }

    if (activeNoteId === noteId) {
      const remaining = notes.filter((n) => n.id !== noteId && !n.inTrash);
      setActiveNoteId(remaining.length > 0 ? remaining[0].id : null);
    }
  };

  // Restore Note
  const restoreNote = async (noteId: string) => {
    await StorageService.restoreNote(noteId);
    setNotes((prev) =>
      prev.map((n) => (n.id === noteId ? { ...n, inTrash: false, trashDate: undefined } : n))
    );
    setActiveNoteId(noteId);
    setMainView('note');
  };

  // Empty Trash
  const emptyTrash = async () => {
    await StorageService.emptyTrash(workspace.id);
    setNotes((prev) => prev.filter((n) => !n.inTrash));
  };

  // Duplicate Note
  const duplicateNote = async (noteId: string) => {
    const duplicated = await StorageService.duplicateNote(noteId);
    if (duplicated) {
      setNotes((prev) => [duplicated, ...prev]);
      setActiveNoteId(duplicated.id);
      setMainView('note');
    }
    return duplicated;
  };

  // Create Folder
  const createFolder = async (name: string, color?: string, icon?: string) => {
    const newFolder: Folder = {
      id: generateId(),
      workspaceId: workspace.id,
      name,
      color: color || '#10b981',
      icon: icon || '📁',
      order: folders.length,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await StorageService.saveFolder(newFolder);
    setFolders((prev) => [...prev, newFolder]);
    setSelectedFolderId(newFolder.id);
    return newFolder;
  };

  // Delete Folder
  const deleteFolder = async (folderId: string) => {
    await StorageService.deleteFolder(folderId);
    setFolders((prev) => prev.filter((f) => f.id !== folderId));
    if (selectedFolderId === folderId) {
      setSelectedFolderId(null);
    }
  };

  // Toggle favorite
  const toggleFavorite = (noteId: string) => {
    const note = notes.find((n) => n.id === noteId);
    if (note) {
      updateActiveNote({ isFavorite: !note.isFavorite }, true);
    }
  };

  // Toggle pin
  const togglePin = (noteId: string) => {
    const note = notes.find((n) => n.id === noteId);
    if (note) {
      updateActiveNote({ isPinned: !note.isPinned }, true);
    }
  };

  return (
    <WorkspaceContext.Provider
      value={{
        workspace,
        folders,
        notebooks,
        notes,
        activeNote,
        activeNoteId,
        setActiveNoteId,
        mainView,
        setMainView,
        selectedFolderId,
        setSelectedFolderId,
        selectedTag,
        setSelectedTag,
        filterFavorites,
        setFilterFavorites,
        searchQuery,
        setSearchQuery,
        saveStatus,
        isTabletMode,
        setIsTabletMode,
        isNoteListOpen,
        setIsNoteListOpen,
        updateActiveNote,
        createNote,
        deleteNote,
        restoreNote,
        emptyTrash,
        duplicateNote,
        createFolder,
        deleteFolder,
        toggleFavorite,
        togglePin,
        refreshData,
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  );
};

export function useWorkspaceContext(): WorkspaceContextType {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error('useWorkspaceContext must be used within a WorkspaceProvider');
  }
  return context;
}
