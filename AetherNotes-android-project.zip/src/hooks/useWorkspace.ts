﻿export { useWorkspaceContext as useWorkspace } from '../context/WorkspaceContext';
export type { MainViewType } from '../context/WorkspaceContext';
