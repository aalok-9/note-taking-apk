﻿import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { NoteList } from './components/layout/NoteList';
import { Navbar } from './components/layout/Navbar';
import { InspectorPanel } from './components/layout/InspectorPanel';
import { MobileNav } from './components/layout/MobileNav';
import { BlockEditor } from './components/editor/BlockEditor';
import { DigitalPaper } from './components/canvas/DigitalPaper';
import { PdfAnnotator } from './components/pdf/PdfAnnotator';
import { GraphView } from './components/graph/GraphView';
import { TaskPlanner } from './components/tasks/TaskPlanner';
import { TrashView } from './components/layout/TrashView';
import { SearchModal } from './components/search/SearchModal';
import { CommandPalette } from './components/command/CommandPalette';
import { QuickCaptureModal } from './components/capture/QuickCaptureModal';
import { VersionHistoryModal } from './components/history/VersionHistoryModal';
import { SettingsModal } from './components/settings/SettingsModal';
import { ToastContainer } from './components/common/Toast';
import { useWorkspace } from './hooks/useWorkspace';
import { useTheme } from './hooks/useTheme';

export const App: React.FC = () => {
  const {
    notes,
    activeNote,
    setActiveNoteId,
    mainView,
    setMainView,
    updateActiveNote,
    createNote,
    isTabletMode,
    isNoteListOpen,
    setIsNoteListOpen,
  } = useWorkspace();

  const { settings } = useTheme();

  // Modal open states
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+N or Cmd+N: New note
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n' && !e.shiftKey) {
        e.preventDefault();
        createNote({ title: 'Untitled Note', viewMode: 'editor' });
      }
      // Ctrl+Shift+N: Quick Capture
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        setIsQuickCaptureOpen(true);
      }
      // Ctrl+P or Cmd+P or Ctrl+Shift+P or Cmd+K: Command palette
      else if (
        ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') ||
        ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')
      ) {
        e.preventDefault();
        setIsCommandOpen((prev) => !prev);
      }
      // Ctrl+Shift+F: Global Search
      else if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [createNote]);

  return (
    <div
      className={`flex h-screen w-screen overflow-hidden bg-zinc-100 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans antialiased ${
        isTabletMode ? 'tablet-mode text-base' : ''
      }`}
    >
      {/* Toast Notifications */}
      <ToastContainer />

      {/* Left Sidebar */}
      <Sidebar
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenCommandPalette={() => setIsCommandOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Note List pane (collapsible) */}
      {mainView === 'note' && isNoteListOpen && (
        <div className={`${isTabletMode ? 'fixed z-30 inset-y-0 left-0 md:relative' : ''}`}>
          <NoteList />
        </div>
      )}

      {/* Main Center Stage Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-white dark:bg-zinc-900">
        {/* Top Navbar */}
        <Navbar
          onToggleMobileSidebar={() => setIsMobileSidebarOpen((prev) => !prev)}
          isInspectorOpen={isInspectorOpen}
          onToggleInspector={() => setIsInspectorOpen((prev) => !prev)}
          onOpenHistory={() => setIsHistoryOpen(true)}
        />

        {/* Dynamic Viewport */}
        <main className="flex-1 overflow-y-auto relative custom-scrollbar flex">
          <div className="flex-1 h-full overflow-y-auto custom-scrollbar">
            {mainView === 'graph' && <GraphView />}
            {mainView === 'tasks' && <TaskPlanner />}
            {mainView === 'trash' && <TrashView />}

            {mainView === 'note' && activeNote && (
              <>
                {activeNote.viewMode === 'editor' && (
                  <BlockEditor
                    note={activeNote}
                    allNotes={notes}
                    onUpdate={updateActiveNote}
                    onNavigateToNote={(id) => {
                      setActiveNoteId(id);
                      setMainView('note');
                    }}
                  />
                )}

                {activeNote.viewMode === 'canvas' && (
                  <DigitalPaper note={activeNote} onUpdate={updateActiveNote} />
                )}

                {activeNote.viewMode === 'pdf' && (
                  <PdfAnnotator note={activeNote} onUpdate={updateActiveNote} />
                )}
              </>
            )}

            {mainView === 'note' && !activeNote && (
              <div className="h-full flex items-center justify-center text-zinc-400 text-sm">
                Select or create a note to begin writing.
              </div>
            )}
          </div>

          {/* Collapsible Inspector Panel (Backlinks, Outline, Tags) */}
          {mainView === 'note' && activeNote && isInspectorOpen && !isTabletMode && (
            <InspectorPanel />
          )}
        </main>

        {/* Mobile Navigation Bar */}
        <MobileNav
          onToggleSidebar={() => setIsMobileSidebarOpen((prev) => !prev)}
          onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      </div>

      {/* Search Modal */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />

      {/* Command Palette */}
      <CommandPalette
        isOpen={isCommandOpen}
        onClose={() => setIsCommandOpen(false)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Quick Capture Modal */}
      <QuickCaptureModal
        isOpen={isQuickCaptureOpen}
        onClose={() => setIsQuickCaptureOpen(false)}
      />

      {/* Version History Modal */}
      <VersionHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
      />

      {/* Comprehensive Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
};
