﻿export type ViewMode = 'editor' | 'canvas' | 'pdf';

export type BlockType =
  | 'paragraph'
  | 'heading-1'
  | 'heading-2'
  | 'heading-3'
  | 'bullet-list'
  | 'numbered-list'
  | 'checklist'
  | 'toggle'
  | 'quote'
  | 'callout'
  | 'code'
  | 'table'
  | 'divider'
  | 'equation'
  | 'image'
  | 'audio'
  | 'file'
  | 'bookmark'
  | 'page-link'
  | 'date-mention';

export interface TableCell {
  id: string;
  value: string | number | boolean;
}

export interface TableColumn {
  id: string;
  title: string;
  type: 'text' | 'number' | 'checkbox' | 'date' | 'select' | 'url' | 'formula';
  width?: number;
  options?: string[];
  formula?: string;
}

export interface TableRow {
  id: string;
  cells: Record<string, string | number | boolean>;
}

export interface TableBlockData {
  columns: TableColumn[];
  rows: TableRow[];
  summaryType?: 'sum' | 'avg' | 'count' | 'checked' | 'none';
}

export interface CalloutBlockData {
  icon: string;
  type: 'info' | 'warning' | 'success' | 'tip' | 'note';
  text: string;
}

export interface AudioBlockData {
  url?: string;
  blobId?: string;
  duration?: number;
  recordedAt?: string;
  title?: string;
}

export interface CodeBlockData {
  code: string;
  language: string;
}

export interface Block {
  id: string;
  type: BlockType;
  content: string;
  checked?: boolean;
  collapsed?: boolean;
  children?: any[];
  data?: TableBlockData | CalloutBlockData | AudioBlockData | CodeBlockData | any;
  meta?: {
    dueDate?: string;
    priority?: 'low' | 'medium' | 'high';
    completedAt?: string;
    align?: 'left' | 'center' | 'right';
    color?: string;
    bgColor?: string;
  };
}

export type CanvasTool =
  | 'select'
  | 'pen'
  | 'fountain'
  | 'pencil'
  | 'highlighter'
  | 'eraser-stroke'
  | 'eraser-pixel'
  | 'lasso'
  | 'shape-rectangle'
  | 'shape-ellipse'
  | 'shape-triangle'
  | 'shape-line'
  | 'shape-arrow'
  | 'shape-star'
  | 'text'
  | 'image';

export interface Point {
  x: number;
  y: number;
  pressure?: number;
}

export interface CanvasStroke {
  id: string;
  tool: CanvasTool;
  points: Point[];
  color: string;
  width: number;
  opacity: number;
  isHighlighter?: boolean;
}

export interface CanvasShape {
  id: string;
  type: 'rectangle' | 'ellipse' | 'triangle' | 'line' | 'arrow' | 'star';
  x: number;
  y: number;
  width: number;
  height: number;
  strokeColor: string;
  fillColor?: string;
  strokeWidth: number;
  opacity: number;
}

export interface CanvasText {
  id: string;
  x: number;
  y: number;
  text: string;
  fontSize: number;
  fontFamily: string;
  color: string;
  width?: number;
}

export interface CanvasImage {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  dataUrl: string;
}

export type PaperTemplateType =
  | 'blank'
  | 'ruled'
  | 'narrow-ruled'
  | 'college-ruled'
  | 'grid'
  | 'dotted'
  | 'graph'
  | 'cornell'
  | 'checklist-planner'
  | 'daily-journal'
  | 'custom-grid';

export type PaperTint = 'light' | 'cream' | 'dark' | 'sepia' | 'navy';

export interface PaperConfig {
  template: PaperTemplateType;
  tint: PaperTint;
  lineSpacing: number;
  gridSize: number;
  showMargin?: boolean;
  orientation?: 'portrait' | 'landscape';
}

export interface CanvasData {
  strokes: CanvasStroke[];
  shapes: CanvasShape[];
  texts: CanvasText[];
  images: CanvasImage[];
  paperConfig: PaperConfig;
  viewport: {
    zoom: number;
    panX: number;
    panY: number;
  };
}

export interface PdfAnnotation {
  id: string;
  page: number;
  type: 'highlight' | 'underline' | 'stroke' | 'text' | 'comment' | 'shape';
  color: string;
  points?: Point[];
  rect?: { x: number; y: number; width: number; height: number };
  text?: string;
  comment?: string;
  author?: string;
  createdAt: string;
}

export interface PdfData {
  url?: string;
  filename: string;
  fileSize?: number;
  totalPages: number;
  annotations: PdfAnnotation[];
  currentPage?: number;
}

export interface Note {
  id: string;
  workspaceId: string;
  folderId?: string;
  notebookId?: string;
  title: string;
  icon?: string;
  coverImage?: string;
  viewMode: ViewMode;
  blocks: Block[];
  canvasData?: CanvasData;
  pdfData?: PdfData;
  tags: string[];
  isFavorite?: boolean;
  isPinned?: boolean;
  isArchived?: boolean;
  inTrash?: boolean;
  trashDate?: string;
  createdAt: string;
  updatedAt: string;
  version: number;
  wordCount?: number;
}

export interface NoteRevision {
  id: string;
  noteId: string;
  title: string;
  blocks: Block[];
  canvasData?: CanvasData;
  tags: string[];
  createdAt: string;
  description?: string;
}

export interface Folder {
  id: string;
  workspaceId: string;
  parentId?: string;
  name: string;
  icon?: string;
  color?: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface Notebook {
  id: string;
  workspaceId: string;
  folderId?: string;
  name: string;
  icon?: string;
  color?: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface Workspace {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  createdAt: string;
  updatedAt: string;
  formatVersion: number;
}

export interface Attachment {
  id: string;
  noteId: string;
  name: string;
  type: string;
  size: number;
  dataUrl?: string;
  blobId?: string;
  createdAt: string;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'oled' | 'sepia' | 'system';
  accentColor: 'green' | 'indigo' | 'rose' | 'amber' | 'cyan' | 'slate' | 'violet';
  fontSize: 'compact' | 'normal' | 'relaxed';
  fontFamily: 'sans' | 'serif' | 'mono';
  density: 'compact' | 'normal' | 'comfortable';
  autoSaveInterval: number;
  defaultViewMode: ViewMode;
  defaultPaperTemplate: PaperTemplateType;
  defaultPaperTint: PaperTint;
  soundEffects: boolean;
  spellCheck: boolean;
  graphPhysics: boolean;
  autoBackups: boolean;
  backupIntervalHours: number;
}

export interface BacklinkItem {
  noteId: string;
  noteTitle: string;
  preview: string;
  isLinked: boolean;
}

export interface GraphNode {
  id: string;
  title: string;
  folderId?: string;
  tags: string[];
  val: number;
  color?: string;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
}

export interface GraphLink {
  source: string | GraphNode;
  target: string | GraphNode;
}

export interface GraphData {
  nodes: GraphNode[];
  links: GraphLink[];
}

export interface SearchResult {
  note: Note;
  score: number;
  matchedField: 'title' | 'content' | 'tags' | 'folder';
  snippets: string[];
}

export interface TaskItem {
  id: string;
  noteId: string;
  noteTitle: string;
  text: string;
  checked: boolean;
  dueDate?: string;
  priority?: 'low' | 'medium' | 'high';
  completedAt?: string;
  blockId: string;
}
